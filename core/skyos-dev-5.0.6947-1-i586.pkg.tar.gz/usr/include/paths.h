#ifndef _PATHS_H
#define _PATHS_H
#define _PATH_CONSOLE "/dev/console"
#define _PATH_TTY     "/dev/tty"
#define _PATH_DEVNULL "/dev/null"
#define _PATH_TMP     "/tmp/"
#define _PATH_VARRUN  "/var/run/"
#define _PATH_VARDB   "/var/db/"
#define _PATH_BSHELL  "/usr/bin/sh"
#define _PATH_DEFPATH "/usr/bin:/bin"
#endif
