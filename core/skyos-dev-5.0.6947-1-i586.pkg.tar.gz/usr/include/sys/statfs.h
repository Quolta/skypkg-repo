#ifndef _STATFS_H_
#define _STATFS_H_


#ifdef __cplusplus
extern "C" {
#endif


struct statfs {
	long f_type;
	long f_bsize;
	long f_blocks;
	long f_bfree;
	long f_bavail;
	long f_files;
	long f_ffree;
	long f_namelen;
	long f_fsid; 
	long f_spare[5];
	
};

int statfs (const char *__path, struct statfs *__buf);
int fstatfs (int __fd, struct statfs *__buf); 

typedef struct sVolumeInformation
{
	unsigned int  uiMaxNameLength;
	unsigned int uiFilesystemBlockSize;
	unsigned long long ullVolumeSize;
	unsigned long long ullVolumeFree;
	unsigned char ucVolumeName[256];
	unsigned char ucFileSystem[256];
} sVolumeInformation;

// #include "skyos/types.h"

unsigned int SystemGetVolumeInformation(unsigned char *pID, sVolumeInformation *pInfo, unsigned int uiInfoStructureSize);

#ifdef __cplusplus
}
#endif


#endif
