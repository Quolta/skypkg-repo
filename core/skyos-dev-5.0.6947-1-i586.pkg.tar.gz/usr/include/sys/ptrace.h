#ifndef	_PTRACE_H
#define	_PTRACE_H


enum __ptrace_request
{
  PTRACE_TRACEME = 0,
  PTRACE_PEEKTEXT,
  PTRACE_PEEKDATA,
  PTRACE_PEEKUSER,
  PTRACE_POKETEXT,
  PTRACE_POKEDATA,
  PTRACE_POKEUSER,
  PTRACE_CONT,
  PTRACE_KILL,
  PTRACE_SINGLESTEP,
  PTRACE_ATTACH,
  PTRACE_DETACH,
  PTRACE_GETREGS = 12,
  PTRACE_SETREGS,
  PTRACE_GETFPREGS = 14,
  PTRACE_SETFPREGS,
  PTRACE_READDATA = 16,
  PTRACE_WRITEDATA,
  PTRACE_READTEXT = 18,
  PTRACE_WRITETEXT,
  PTRACE_GETFPAREGS = 20,
  PTRACE_SETFPAREGS,
  PTRACE_SYSCALL
};

#define PT_READ_U PTRACE_PEEKUSER
#define PT_TRACE_ME PTRACE_TRACEME
#define PT_READ_I PTRACE_PEEKTEXT
#define PT_READ_D PTRACE_PEEKDATA
#define PT_WRITE_I PTRACE_POKETEXT
#define PT_WRITE_D PTRACE_POKEDATA
#define PT_WRITE_U PTRACE_POKEUSER
#define PT_CONTINUE PTRACE_CONT
#define PT_KILL PTRACE_KILL
#define PT_WRITE_U PTRACE_POKEUSER
#define PT_CONTINUE PTRACE_CONT
#define PT_ATTACH PTRACE_ATTACH
#define PT_DETACH PTRACE_DETACH

#define PT_STEP PTRACE_SINGLESTEP
#define PT_GETREGS PTRACE_GETREGS
#define PT_SETREGS PTRACE_SETREGS
#define PT_GETFPREGS PTRACE_GETFPREGS
#define PT_SETFPREGS PTRACE_SETFPREGS
#define PT_ATTACH PTRACE_ATTACH
#define PT_DETACH PTRACE_DETACH
#define PT_GETFPXREGS -1
#define PT_SETFPXREGS -2
#define PT_SYSCALL PTRACE_SYSCALL 

typedef struct sSystemCall
{
	unsigned long  syscall_para1_ebx;
	unsigned long  syscall_para2_ecx;
	unsigned long  syscall_para3_edx;
	unsigned long  syscall_para4_esi;
	unsigned long  syscall_para5_edi;
    unsigned long  ebx;
    unsigned long  ecx;
    unsigned long  edx;
    unsigned long  esi;
    unsigned long  edi;
    unsigned long  ebp;
    unsigned long  eax;
    unsigned short ds, __dsu;
    unsigned short es, __esu;
    unsigned short fs, __fsu;
    unsigned short gs, __gsu;
    unsigned long  orig_eax;
    unsigned long  eip;
    unsigned short cs, __csu;
    unsigned long  eflags;
    unsigned long  esp;
    unsigned short ss, __ssu;
} sSystemCall;

typedef struct sVM86Regs
{
	long    syscall_para1_ebx;
	long    syscall_para2_ecx;
	long    syscall_para3_edx;
	long    syscall_para4_esi;
	long    syscall_para5_edi;
    long 	ebx;
    long 	ecx;
    long 	edx;
    long 	esi;
    long 	edi;
    long 	ebp;
    long 	eax;
    long 	__null_ds;
    long 	__null_es;
    long 	__null_fs;
    long 	__null_gs;
    long 	orig_eax;
    long 	eip;
    unsigned short cs, __csh;
    long 	eflags;
    long 	esp;
    unsigned short ss, __ssh;
	
    unsigned short es, __esh;
    unsigned short ds, __dsh;
    unsigned short fs, __fsh;
    unsigned short gs, __gsh;
} sVM86Regs;

#define SYSCALL_PARA1_EBX 0
#define SYSCALL_PARA2_ECX 1 
#define SYSCALL_PARA3_EDX 2
#define SYSCALL_PARA4_ESI 3
#define SYSCALL_PARA5_EDI 4
#define SYSCALL_EBX 5
#define SYSCALL_ECX 6
#define SYSCALL_EDX 7
#define SYSCALL_ESI 8
#define SYSCALL_EDI 9
#define SYSCALL_EBP 10
#define SYSCALL_EAX 11
#define SYSCALL_DS 12
#define SYSCALL_ES 13
#define SYSCALL_FS 14
#define SYSCALL_GS 15
#define SYSCALL_ORIG_EAX 16
#define SYSCALL_EIP 17
#define SYSCALL_CS 18
#define SYSCALL_EFLAGS 19
#define SYSCALL_ESP  20
#define SYSCALL_SS 21

#define SYSCALL_SIZE 22

#ifndef KERNEL

#define EBX			0
#define ECX			1
#define EDX			2
#define ESI			3
#define EDI			4
#define EBP			5
#define EAX			6
#define DS			7
#define ES			8
#define FS			9
#define GS			10
#define ORIG_EAX	11
#define EIP			12
#define CS			13
#define EFL			14
#define UESP		15
#define SS			16 

#endif

typedef struct {
	unsigned int cwd;
	unsigned int swd;
	unsigned int twd;
	unsigned int fip;
	unsigned int fcs;
	unsigned int foo;
	unsigned int fos;
	unsigned int st_space[20];  /* 8 FP registers, 10 bytes each */
} elf_fpregset_t;

typedef struct {
	unsigned short cwd;
	unsigned short swd;
	unsigned short twd;
	unsigned short fop;
	unsigned int fip;
	unsigned int fcs;
	unsigned int foo;
	unsigned int fos;
	unsigned int mxcsr;
	unsigned int reserved;
	unsigned int st_space[32];   /* 8 FP registers, 16 bytes each */
	unsigned int xmm_space[32];  /* 8 XMM registers, 16 bytes each */
	unsigned int padding[56];
} elf_fpxregset_t;


struct user_regs_struct 
{
	long ebx, ecx, edx, esi, edi, ebp, eax;
	unsigned short ds, __ds, es, __es;
	unsigned short fs, __fs, gs, __gs;
	long orig_eax, eip;
	unsigned short cs, __cs;
	long eflags, esp;
	unsigned short ss, __ss;
};


 

typedef unsigned int elf_greg_t;

#define ELF_NGREG (sizeof(struct user_regs_struct) / sizeof(elf_greg_t))
typedef elf_greg_t elf_gregset_t[ELF_NGREG];

struct user {
	struct user_regs_struct regs;
    unsigned int u_debugreg[8];
};

#endif
