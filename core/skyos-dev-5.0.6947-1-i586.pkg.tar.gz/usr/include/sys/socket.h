#ifndef _SYS_SOCKET_H
#define _SYS_SOCKET_H

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>

/* Socket address family */
typedef unsigned short sa_family_t;
typedef unsigned int   socklen_t;

/* Address families */
#define AF_UNSPEC       0
#define AF_UNIX         1
#define AF_LOCAL        AF_UNIX
#define AF_INET         2
#define AF_IPX          4
#define AF_APPLETALK    5
#define AF_INET6        10

#define PF_UNSPEC       AF_UNSPEC
#define PF_UNIX         AF_UNIX
#define PF_LOCAL        AF_LOCAL
#define PF_INET         AF_INET
#define PF_INET6        AF_INET6

/* Socket types */
#define SOCK_STREAM     1
#define SOCK_DGRAM      2
#define SOCK_RAW        3
#define SOCK_RDM        4
#define SOCK_SEQPACKET  5

/* Shutdown modes */
#define SHUT_RD         0
#define SHUT_WR         1
#define SHUT_RDWR       2

/* Message flags */
#define MSG_OOB         0x01
#define MSG_PEEK        0x02
#define MSG_DONTROUTE   0x04
#define MSG_DONTWAIT    0x40
#define MSG_NOSIGNAL    0x4000
#define MSG_WAITALL     0x100

/* Generic socket address */
struct sockaddr {
    sa_family_t sa_family;
    char        sa_data[14];
};

/* Socket storage (large enough for any address type) */
struct sockaddr_storage {
    sa_family_t ss_family;
    char        __ss_pad1[6];
    long        __ss_align;
    char        __ss_pad2[112];
};

/* Message header for sendmsg/recvmsg */
struct msghdr {
    void         *msg_name;
    socklen_t     msg_namelen;
    struct iovec *msg_iov;
    int           msg_iovlen;
    void         *msg_control;
    socklen_t     msg_controllen;
    int           msg_flags;
};

/* Linger structure */
struct linger {
    int l_onoff;
    int l_linger;
};

/* BSD socket API */
int     socket(int domain, int type, int protocol);
int     bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
int     listen(int sockfd, int backlog);
int     accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen);
int     connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
ssize_t send(int sockfd, const void *buf, size_t len, int flags);
ssize_t recv(int sockfd, void *buf, size_t len, int flags);
ssize_t sendto(int sockfd, const void *buf, size_t len, int flags,
               const struct sockaddr *dest_addr, socklen_t addrlen);
ssize_t recvfrom(int sockfd, void *buf, size_t len, int flags,
                 struct sockaddr *src_addr, socklen_t *addrlen);
int     setsockopt(int sockfd, int level, int optname,
                   const void *optval, socklen_t optlen);
int     getsockopt(int sockfd, int level, int optname,
                   void *optval, socklen_t *optlen);
int     getsockname(int sockfd, struct sockaddr *addr, socklen_t *addrlen);
int     getpeername(int sockfd, struct sockaddr *addr, socklen_t *addrlen);
int     shutdown(int sockfd, int how);
ssize_t sendmsg(int sockfd, const struct msghdr *msg, int flags);
ssize_t recvmsg(int sockfd, struct msghdr *msg, int flags);
int     socketpair(int domain, int type, int protocol, int sv[2]);

/* cmsghdr — control message header for sendmsg/recvmsg ancillary data */
struct cmsghdr {
    socklen_t cmsg_len;
    int       cmsg_level;
    int       cmsg_type;
    /* followed by unsigned char cmsg_data[]; */
};

/* CMSG macros */
#define CMSG_ALIGN(len) (((len) + sizeof(long) - 1) & ~(sizeof(long) - 1))
#define CMSG_SPACE(len) (CMSG_ALIGN(sizeof(struct cmsghdr)) + CMSG_ALIGN(len))
#define CMSG_LEN(len)   (CMSG_ALIGN(sizeof(struct cmsghdr)) + (len))
#define CMSG_DATA(cmsg)  ((unsigned char *)(cmsg) + CMSG_ALIGN(sizeof(struct cmsghdr)))
#define CMSG_FIRSTHDR(mhdr) \
    ((mhdr)->msg_controllen >= sizeof(struct cmsghdr) ? \
     (struct cmsghdr *)(mhdr)->msg_control : (struct cmsghdr *)0)
#define CMSG_NXTHDR(mhdr, cmsg) \
    (((unsigned char *)(cmsg) + CMSG_ALIGN((cmsg)->cmsg_len) + \
      CMSG_ALIGN(sizeof(struct cmsghdr)) > \
      (unsigned char *)(mhdr)->msg_control + (mhdr)->msg_controllen) ? \
     (struct cmsghdr *)0 : \
     (struct cmsghdr *)((unsigned char *)(cmsg) + CMSG_ALIGN((cmsg)->cmsg_len)))

/* SCM_RIGHTS — pass file descriptors over Unix sockets (stub, SkyOS doesn't support it) */
#define SOL_SOCKET_LEVEL  1
#define SCM_RIGHTS        1

/* Additional MSG flags */
#ifndef MSG_TRUNC
#define MSG_TRUNC     0x20
#endif
#ifndef MSG_CTRUNC
#define MSG_CTRUNC    0x08
#endif
#ifndef MSG_CMSG_CLOEXEC
#define MSG_CMSG_CLOEXEC 0
#endif

#ifdef __cplusplus
}
#endif

#endif /* _SYS_SOCKET_H */
