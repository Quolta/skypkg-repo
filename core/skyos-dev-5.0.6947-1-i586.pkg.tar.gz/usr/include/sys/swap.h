#ifndef _SYS_SWAP_H
#define _SYS_SWAP_H
/* SkyOS has no swap — stub */
#endif
