#ifndef __INC_SELECT_H_
#define __INC_SELECT_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef KERNEL
#include "sys/time.h"
#endif

#define FD_SETSIZE 64

typedef	long	fd_mask;
#  define	NFDBITS	(sizeof (fd_mask) * NBBY)	/* bits per mask */
typedef struct fd_set {
  unsigned char fds_bits [((FD_SETSIZE) + 7) / 8];
} fd_set;

#define FD_SET(n, p)    ((p)->fds_bits[(n) / 8] |= (1 << ((n) & 7)))
#define FD_CLR(n, p)	((p)->fds_bits[(n) / 8] &= ~(1 << ((n) & 7)))
#define FD_ISSET(n, p)	((p)->fds_bits[(n) / 8] & (1 << ((n) & 7)))
#define FD_ZERO(p)	memset ((void *)(p), 0, sizeof (*(p)))
 

#  define	NBBY	8		/* number of bits in a byte */
struct timeval;

int select(int nfds, fd_set* readfds, fd_set* writefds, fd_set* exceptfds, const struct timeval* timeout);

#ifdef __cplusplus
}
#endif

#endif
