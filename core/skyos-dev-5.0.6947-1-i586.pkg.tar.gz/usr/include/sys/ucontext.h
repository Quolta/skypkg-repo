#ifndef _SYS_UCONTEXT_H
#define _SYS_UCONTEXT_H
/* SkyOS: no ucontext support — stub for TCC */
typedef struct { int dummy; } ucontext_t;
typedef struct { int dummy; } mcontext_t;
#endif
