#ifndef _SYS_MOUNT_H
#define _SYS_MOUNT_H
#define MS_RDONLY    1
#define MS_NOSUID    2
#define MS_NODEV     4
#define MS_NOEXEC    8
#define MS_REMOUNT   32
#define MNT_FORCE    1
#define MNT_DETACH   2
#endif
