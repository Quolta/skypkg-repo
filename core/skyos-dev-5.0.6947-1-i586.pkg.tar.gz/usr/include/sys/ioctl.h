#ifndef _INC_IOCTLS_H_
#define _INC_IOCTLS_H_

#ifdef __cplusplus
extern "C" {
#endif

#define FIONREAD    _IOR('f', 127, unsigned long) /* get # bytes to read */
#define FIONBIO     _IOW('f', 126, unsigned long) /* set/clear non-blocking i/o */
#define FIOASYNC    _IOW('f', 125, unsigned long) /* set/clear async i/o */
#define	TIOCOUTQ	_IOR('t', 115, int)	/* output queue size */ 

#define _IOC_NONE		0
#define _IOC_READ		1
#define _IOC_WRITE		2 

#define _IOC_NRMASK			0x000003ff
#define _IOC_NRSHIFT		0
#define _IOC_TYPEMASK		0x0000fc00
#define _IOC_TYPESHIFT		10
#define _IOC_SIZEMASK		0x3fff0000
#define _IOC_SIZESHIFT		16
#define _IOC_DIRMASK		0xc0000000
#define _IOC_DIRSHIFT		30

#define _IOC(dir,type,nr,size)		\
	((((type)<<_IOC_TYPESHIFT)&_IOC_TYPEMASK) | (((nr)<<_IOC_NRSHIFT)&_IOC_NRMASK) | \
	(((dir)<<_IOC_DIRSHIFT)&_IOC_DIRMASK)   |	(((size)<<_IOC_SIZESHIFT)&_IOC_SIZEMASK)) 

#define _IO(type,nr)			_IOC(_IOC_NONE,(type),(nr),0)
#define _IOR(type,nr,size)		_IOC(_IOC_READ,(type),(nr),sizeof(size))
#define _IOW(type,nr,size)		_IOC(_IOC_WRITE,(type),(nr),sizeof(size))
#define _IOWR(type,nr,size)		_IOC(_IOC_WRITE|_IOC_READ,(type),(nr),sizeof(size))


#define _IOC_TYPE( value )  (((value)&_IOC_TYPEMASK)>>_IOC_TYPESHIFT)
#define _IOC_NR( value )  (((value)&_IOC_NRMASK)>>_IOC_NRSHIFT)
#define _IOC_DIR( value )  (((value)&_IOC_DIRMASK)>>_IOC_DIRSHIFT)
#define _IOC_SIZE( value ) (((value)&_IOC_SIZEMASK)>>_IOC_SIZESHIFT)
 

/* modem lines */
#define TIOCM_LE	0x001
#define TIOCM_DTR	0x002
#define TIOCM_RTS	0x004
#define TIOCM_ST	0x008
#define TIOCM_SR	0x010
#define TIOCM_CTS	0x020
#define TIOCM_CAR	0x040
#define TIOCM_RNG	0x080
#define TIOCM_DSR	0x100
#define TIOCM_CD	TIOCM_CAR
#define TIOCM_RI	TIOCM_RNG 

#define TIOCMGET	0x5415 
#define TIOCMSET	0x5416

int ioctl(int fd, unsigned int uiCmd, void* pArg);

#ifdef __cplusplus
}
#endif

#endif

