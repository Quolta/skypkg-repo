/* SkyOS sys/sysctl.h stub — no sysctl on SkyOS */
#ifndef _SYS_SYSCTL_H
#define _SYS_SYSCTL_H
#endif
