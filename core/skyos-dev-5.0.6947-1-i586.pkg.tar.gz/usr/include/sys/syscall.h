#ifndef _SYS_SYSCALL_H
#define _SYS_SYSCALL_H

/* SkyOS stub: no Linux syscall numbers available */

#endif /* _SYS_SYSCALL_H */
