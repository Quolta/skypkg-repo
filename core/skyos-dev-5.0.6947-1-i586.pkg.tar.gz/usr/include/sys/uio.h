/*
 * SkyOS sys/uio.h — readv/writev declarations
 * struct iovec is already defined in stdio.h (SkyOS ships it there).
 * This header only provides the scatter/gather I/O function prototypes.
 */
#ifndef _SYS_UIO_H
#define _SYS_UIO_H

#include <sys/types.h>
#include <stdio.h>  /* struct iovec is defined here on SkyOS */

#ifdef __cplusplus
extern "C" {
#endif

ssize_t readv(int fd, const struct iovec *iov, int iovcnt);
ssize_t writev(int fd, const struct iovec *iov, int iovcnt);

#ifdef __cplusplus
}
#endif

#endif /* _SYS_UIO_H */
