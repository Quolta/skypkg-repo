#ifndef __INC_SIGSTACK_H__
#define __INC_SIGSTACK_H__

struct sigstack
{
    void *ss_sp;
    int ss_onstack;
};

typedef struct sigaltstack
{
    void *ss_sp;
    int ss_flags;
    int  ss_size;
} stack_t;

enum
{
  SS_ONSTACK = 1,
#define SS_ONSTACK	SS_ONSTACK
  SS_DISABLE
#define SS_DISABLE	SS_DISABLE
};

/* Minimum stack size for a signal handler.  */
#define MINSIGSTKSZ	2048
/* System default stack size.  */
#define SIGSTKSZ	8192

#define SA_ONSTACK 8

int sigaltstack (const struct sigaltstack *stack, struct sigaltstack *oldstack);


#endif
