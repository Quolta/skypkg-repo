#ifndef _INC_LIBNET_H_
#define _INC_LIBNET_H_

#include "skyos/types.h"
#include "../source/include/dd_com.h"

typedef struct sPPPDevice
{
	char    pSerialDevice[255];
	DDCOM_SET_PARAM pSerialParam; 
	char    pUserName[255];
	char    pPassword[255];
	char    pTelephone[255];
	char    pNifName[255];
	unsigned int     uiIP_Local;
	unsigned int     uiIP_Server;
	unsigned int     uiIP_DnsPrimary;
	unsigned int     uiIP_DnsSecondary;
} sPPPDevice;

typedef struct sNetworkInterface
{
	char ucDevice[255];
	char ucNameShort[255];
	char ucNameLong[4096];
	char bLoopBack;
	char bPPP;
	char bSlip;
} sNetworkInterface;

HRESULT NetIf_Ioctl(char *pDevice,
				    unsigned int uiIoctlCode,
					void *pArg);

HRESULT DnsResolve(char *pServer,
				   char *sLookupName,
				   unsigned int *puiIPAddress);

HRESULT SerialConfigure(char *pDevice,
						unsigned int  uiBaud,
						char ucParity,
						char ucDatabit,
						char ucStopbit);

HRESULT NetIf_StartDevice(char *pDevice,
					      char *pIP,
					      char *pNetMask,
					      char *pGateway,
					      unsigned int uiFlags);

HRESULT NetIf_GetDeviceHardwareAddress(char *pDevice,
									   char *pucHardwareAddress,
									   int  iMaxLength,
									   int  *piLength);

#endif

