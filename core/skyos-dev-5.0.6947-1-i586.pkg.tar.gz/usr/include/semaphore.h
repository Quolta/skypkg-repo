/*
 * SkyOS semaphore.h
 * sem_t is already defined in pthread.h as { int iSem; } (kernel handle).
 * This header declares the POSIX semaphore function prototypes.
 * Actual implementation is in SkyOS's libpthread.so.
 */
#ifndef _SEMAPHORE_H
#define _SEMAPHORE_H

#include <pthread.h>  /* provides sem_t */

#ifdef __cplusplus
extern "C" {
#endif

#define SEM_FAILED ((sem_t *)-1)

#ifndef SEM_VALUE_MAX
#define SEM_VALUE_MAX 32767
#endif

int sem_init(sem_t *sem, int pshared, unsigned int value);
int sem_destroy(sem_t *sem);
int sem_post(sem_t *sem);
int sem_wait(sem_t *sem);
int sem_trywait(sem_t *sem);
int sem_getvalue(sem_t *sem, int *sval);

#ifdef __cplusplus
}
#endif

#endif /* _SEMAPHORE_H */
