#ifndef _SIGNAL_H_
#define _SIGNAL_H_

#include "_ansi.h"
#include <sys/siginfo.h>
#include <sys/sigstack.h>
#include <sys/signal.h>

_BEGIN_STD_C

typedef int	sig_atomic_t;		/* Atomic entity type (ANSI) */

#define SIG_DFL ((_sig_func_ptr)0)	/* Default action */
#define SIG_IGN ((_sig_func_ptr)1)	/* Ignore action */
#define SIG_ERR ((_sig_func_ptr)-1)	/* Error return */

struct _reent;

_sig_func_ptr _EXFUN(_signal_r, (struct _reent *, int, _sig_func_ptr));
int	_EXFUN(_raise_r, (struct _reent *, int));

#ifndef _REENT_ONLY
_sig_func_ptr _EXFUN(signal, (int, _sig_func_ptr));
int	_EXFUN(raise, (int));
#endif

#define SA_NOCLDSTOP	1
#define SA_SIGINFO      4
#define SA_SHIRQ		0x04000000
#define SA_STACK		0x08000000
#define SA_RESTART		0x10000000
#define SA_INTERRUPT	0x20000000
#define SA_NOMASK		0x40000000
#define SA_NODEFER		SA_NOMASK
#define SA_ONESHOT		0x80000000
#define SA_RESETHAND	SA_ONESHOT
 
typedef struct sigcontext
{
    unsigned short gs, __gsh;
    unsigned short fs, __fsh;
    unsigned short es, __esh;
    unsigned short ds, __dsh;
    unsigned long  edi;
    unsigned long  esi;
    unsigned long  ebp;
    unsigned long  esp;
    unsigned long  ebx;
    unsigned long  edx;
    unsigned long  ecx;
    unsigned long  eax;
    unsigned long  trapno;
    unsigned long  err;
    unsigned long  eip;
    unsigned short cs, __csh;
    unsigned long  eflags;
    unsigned long  user_esp;
    unsigned short ss, __ssh;
} sigcontext;

int kill (int __pid, int __sig);
_END_STD_C

#endif /* _SIGNAL_H_ */
