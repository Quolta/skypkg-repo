/*
 * SkyOS ifaddrs.h stub
 * SkyOS has no getifaddrs/freeifaddrs.
 * Provides the struct so code compiles; runtime stubs return -1.
 */
#ifndef _IFADDRS_H
#define _IFADDRS_H

#include <sys/socket.h>

struct ifaddrs {
    struct ifaddrs  *ifa_next;
    char            *ifa_name;
    unsigned int     ifa_flags;
    struct sockaddr *ifa_addr;
    struct sockaddr *ifa_netmask;
    struct sockaddr *ifa_broadaddr;
    void            *ifa_data;
};

static inline int getifaddrs(struct ifaddrs **ifap) {
    (void)ifap;
    return -1;
}

static inline void freeifaddrs(struct ifaddrs *ifa) {
    (void)ifa;
}

#endif /* _IFADDRS_H */
