#ifndef __LIBHTTP_H_
#define __LIBHTTP_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
#include <stdlib.h>
#include <skyos/libskyos.h>
#include <ctype.h>

typedef unsigned int (*tHttp_ProgressCallback)(struct sHttpRequest *pRequest, void *pCookie);

enum
{
	PROXY_TYPE_HTTP = 0,
	PROXY_TYPE_SOCKS5
};

#define E_HTTP_UNABLE_TO_CREATE_FILE		_HRESULT_TYPEDEF_(0x81000100L)
#define E_HTTP_UNABLE_TO_GET_DOCUMENT	    _HRESULT_TYPEDEF_(0x81000101L)
#define E_HTTP_UNABLE_TO_RESOLVE		    _HRESULT_TYPEDEF_(0x81000102L)

enum
{
	HTTP_DESTINATION_MEMORY = 0,
	HTTP_DESTINATION_FILE
};

typedef struct sProxyConfiguration
{
	int bConfigured;
	char ucServer[4096];
	char ucUsername[255];
	char ucPassword[255];
	unsigned int  uiPort;
	unsigned int  uiType;
	unsigned int  uiReserved[16];
} sProxyConfiguration;

typedef struct sHttpRequest
{
	int iDestinationType;
	char *pUrl;
	char *pDestinationFile;
	tHttp_ProgressCallback fpProgressFunction;
	void *pProgressCookie;

	char  *pMemory;
    unsigned int uiMemorySize;
	int iFD;
	void *vpHandle;
	unsigned int uiLastServerErrorCode;
	sProxyConfiguration pProxy;
} sHttpRequest;

 HRESULT Http_Init(void);
 HRESULT Http_RequestNew(sHttpRequest **ppRequest);
 HRESULT Http_RequestSetUrl(sHttpRequest *pRequest, 
									 char *pUrl);
 HRESULT Http_RequestSetProxy(sHttpRequest *pRequest, 
									   sProxyConfiguration *pProxy);
 HRESULT Http_RequestSetDestinationType(sHttpRequest *pRequest, 
												 int enumDestinationType);
 HRESULT Http_RequestSetDestinationFile(sHttpRequest *pRequest, 
												 char *pFile);
 HRESULT Http_RequestSetProgressFunction(sHttpRequest *pRequest, 
												  tHttp_ProgressCallback pFunction,
												  void *pCookie);
 HRESULT Http_RequestGetDocument(sHttpRequest *pRequest, 
										  char **ppData,
										  unsigned int *puiSize);
 HRESULT Http_RequestGetLastResponseCode(sHttpRequest *pRequest, 
												unsigned int *puiCode);
 HRESULT Http_RequestDo(sHttpRequest *pRequest);
 HRESULT Proxy_GetConfiguration(char *pUser,
										 unsigned int uiFlags, 
										 sProxyConfiguration **ppProxy);
 HRESULT Proxy_FreeConfiguration(sProxyConfiguration *pProxy);
 HRESULT Http_RequestFreeDocument(sHttpRequest *hRequest);
 HRESULT Http_RequestFree(sHttpRequest *hRequest);

#ifdef __cplusplus
}
#endif
#endif