#ifndef	__INC_ISSPlugin_H__
#define	__INC_ISSPlugin_H__

#include <os/Object.h>
#include <iss/ISSInput.h>
#include <iss/ISSOutput.h>
#include <iss/ISSCodec.h>

namespace SkyGI
{
class ISSCodec;

class ISSPlugin : public Object
{
public:
	ISSPlugin();
	virtual ~ISSPlugin();

	virtual bool			HasInput();
	virtual ISSInput*		CreateInput();

	virtual bool			HasOutput();
	virtual ISSOutput*		CreateOutput();

	virtual bool			HasCodec();
	virtual ISSCodec*		CreateCodec();


	void    SetPath(const String& szPath);
	String  GetPath();

private:
	class Private;
	Private *m;
} ;
}

#endif
