#ifndef	__INC_ISSMixer_H__
#define	__INC_ISSMixer_H__

#include <os/Object.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <iss/ISSInput.h>
#include <iss/ISSPlugin.h>

namespace SkyGI
{

class ISSMixer;

class ISSMixerChannel : public Object
{
public:
	ISSMixerChannel(ISSMixer *pMixer, const String& szChannelName, const String& szGroupName, int iChannelIndex, bool bStereo);

	float GetVolume();
	void  SetVolume(float fVolume);
	int   GetChannelIndex()
	{
		return m_iChannelIndex;
	}

	ISSMixer *GetMixer()
	{
		return m_pMixer;
	}

	String GetName()
	{
		return m_szChannelName;
	}

	String GetGroup()
	{
		return m_szGroupName;
	}

private:
	ISSMixer* m_pMixer;
	int		m_iChannelIndex;

	String	m_szChannelName;
	String  m_szGroupName;

};

class ISSMixer : public Object
{
public:
	ISSMixer(const String& szDeviceName, const String& szDevice, int iChannels);

	static int CountMixers();

	String GetDeviceName()
	{
		return m_szDeviceName;
	}

	String GetDevice()
	{
		return m_szDevice;
	}

	int    CountChannels()
	{
		return m_iChannels;
	}

	ISSMixerChannel* GetChannel(int iIndex);


private:
	String m_szDeviceName;
	String m_szDevice;
	int    m_iChannels;

};

}


#endif
