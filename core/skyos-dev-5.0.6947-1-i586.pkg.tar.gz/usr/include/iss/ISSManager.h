#ifndef	__INC_ISSManager_H__
#define	__INC_ISSManager_H__

#include <os/Object.h>
#include <os/PluginManager.h>
#include <iss/ISSPlugin.h>

namespace SkyGI
{

class ISSManager : public Object
{
public:
	ISSManager();
	~ISSManager();

	static ISSManager* GetInstance();
	ISSPlugin*		   GetPlugin(int iIndex);

	ISSCodec*		   GetCodec(ISSStream* pStream, ISSFormat *pCodecFormat, ISSFormat *pOutputFormat, bool bEncode = false);
	ISSInput*		   GetInput(const String& szInputPluginName);
	ISSOutput*		   GetOutput(const String& szInputPluginName);

	ISSOutput*		   GetDefaultAudioOutputDevice();
	ISSOutput*		   GetDefaultVideoOutputDevice();

private:
	static ISSManager* pISSManagerInstance;
	void _PluginLoaded(Plugin *pPlugin, const String &szPath);

	class Private;
	Private *m;
} ;
}

#endif
