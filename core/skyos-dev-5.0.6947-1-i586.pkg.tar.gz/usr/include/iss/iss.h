#ifndef _INC_ISS_
#define _INC_ISS_

#ifdef __cplusplus
#endif

/* 
   Old C API
*/

#ifdef __cplusplus
extern "C" {
#endif

#define PLAY_FILE_FLAG_SYNCHRON		0x00000001
#define PLAY_FILE_FLAG_LOOP    		0x00000002

typedef long long isstime ;
typedef unsigned long long isssize;

#define PACKET_DATA_PLANES	4
#include "skyos/types.h"
#include "skygi/skygi.h"

/*
   ISS driver specific
*/
enum
{
	ISS_DEV_CMD_GET_OUTPUT_BUFFER = 0x00001000,
	ISS_DEV_CMD_RESET,
	ISS_DEV_CMD_SET_SAMPLE_RATE,
	ISS_DEV_CMD_SET_STEREO,
	ISS_DEV_CMD_SET_FORMAT,
	ISS_DEV_CMD_GET_DEVICE_NAME,
	ISS_DEV_CMD_GET_OUTPUT_USAGE,
	ISS_DEV_CMD_MIXER_GET_NAME,
	ISS_DEV_CMD_MIXER_GET_CHANNELS,
	ISS_DEV_CMD_MIXER_GET_CHANNEL,
	ISS_DEV_CMD_MIXER_SET_CHANNEL,
	ISS_DEV_CMD_MIXER_GET_DESC

};

enum
{
	ISS_MIXER_GET_CHANNEL_INFO_BY_INDEX=0,
	ISS_MIXER_GET_CHANNEL_INFO_BY_TYPE
};

#define ISS_SUPPORTED_STREAM_TYPE_VIDEO		0x00000001
#define ISS_SUPPORTED_STREAM_TYPE_AUDIO		0x00000002

#define ISS_FORMAT_U8		0x00000008
#define ISS_FORMAT_S16_LE	0x00000010
#define ISS_FORMAT_S16_BE	0x00000020
#define ISS_FORMAT_S8		0x00000040
#define ISS_FORMAT_U16_LE	0x00000080
#define ISS_FORMAT_U16_BE	0x00000100

#define SOUND_MIXER_NRDEVICES	25
#define SOUND_MIXER_VOLUME	0
#define SOUND_MIXER_BASS	1
#define SOUND_MIXER_TREBLE	2
#define SOUND_MIXER_SYNTH	3
#define SOUND_MIXER_PCM		4
#define SOUND_MIXER_SPEAKER	5
#define SOUND_MIXER_LINE	6
#define SOUND_MIXER_MIC		7
#define SOUND_MIXER_CD		8
#define SOUND_MIXER_IMIX	9	/*  Recording monitor  */
#define SOUND_MIXER_ALTPCM	10
#define SOUND_MIXER_RECLEV	11	/* Recording level */
#define SOUND_MIXER_IGAIN	12	/* Input gain */
#define SOUND_MIXER_OGAIN	13	/* Output gain */
#define SOUND_MIXER_LINE1	14	/* Input source 1  (aux1) */
#define SOUND_MIXER_LINE2	15	/* Input source 2  (aux2) */
#define SOUND_MIXER_LINE3	16	/* Input source 3  (line) */
#define SOUND_MIXER_DIGITAL1	17	/* Digital (input) 1 */
#define SOUND_MIXER_DIGITAL2	18	/* Digital (input) 2 */
#define SOUND_MIXER_DIGITAL3	19	/* Digital (input) 3 */
#define SOUND_MIXER_PHONEIN	20	/* Phone input */
#define SOUND_MIXER_PHONEOUT	21	/* Phone output */
#define SOUND_MIXER_VIDEO	22	/* Video/TV (audio) in */
#define SOUND_MIXER_RADIO	23	/* Radio in */
#define SOUND_MIXER_MONITOR	24	/* Monitor (usually mic) volume */
#define SOUND_ONOFF_MIN		28
#define SOUND_ONOFF_MAX		30
#define SOUND_MIXER_NONE	31
#define SOUND_MIXER_ENHANCE	SOUND_MIXER_NONE
#define SOUND_MIXER_MUTE	SOUND_MIXER_NONE
#define SOUND_MIXER_LOUD	SOUND_MIXER_NONE

#define SOUND_MASK_VOLUME	(1 << SOUND_MIXER_VOLUME)
#define SOUND_MASK_BASS		(1 << SOUND_MIXER_BASS)
#define SOUND_MASK_TREBLE	(1 << SOUND_MIXER_TREBLE)
#define SOUND_MASK_SYNTH	(1 << SOUND_MIXER_SYNTH)
#define SOUND_MASK_PCM		(1 << SOUND_MIXER_PCM)
#define SOUND_MASK_SPEAKER	(1 << SOUND_MIXER_SPEAKER)
#define SOUND_MASK_LINE		(1 << SOUND_MIXER_LINE)
#define SOUND_MASK_MIC		(1 << SOUND_MIXER_MIC)
#define SOUND_MASK_CD		(1 << SOUND_MIXER_CD)
#define SOUND_MASK_IMIX		(1 << SOUND_MIXER_IMIX)
#define SOUND_MASK_ALTPCM	(1 << SOUND_MIXER_ALTPCM)
#define SOUND_MASK_RECLEV	(1 << SOUND_MIXER_RECLEV)
#define SOUND_MASK_IGAIN	(1 << SOUND_MIXER_IGAIN)
#define SOUND_MASK_OGAIN	(1 << SOUND_MIXER_OGAIN)
#define SOUND_MASK_LINE1	(1 << SOUND_MIXER_LINE1)
#define SOUND_MASK_LINE2	(1 << SOUND_MIXER_LINE2)
#define SOUND_MASK_LINE3	(1 << SOUND_MIXER_LINE3)
#define SOUND_MASK_DIGITAL1	(1 << SOUND_MIXER_DIGITAL1)
#define SOUND_MASK_DIGITAL2	(1 << SOUND_MIXER_DIGITAL2)
#define SOUND_MASK_DIGITAL3	(1 << SOUND_MIXER_DIGITAL3)
#define SOUND_MASK_PHONEIN	(1 << SOUND_MIXER_PHONEIN)
#define SOUND_MASK_PHONEOUT	(1 << SOUND_MIXER_PHONEOUT)
#define SOUND_MASK_RADIO	(1 << SOUND_MIXER_RADIO)
#define SOUND_MASK_VIDEO	(1 << SOUND_MIXER_VIDEO)
#define SOUND_MASK_MONITOR	(1 << SOUND_MIXER_MONITOR)

/* Obsolete macros */
#define SOUND_MASK_MUTE		(1 << SOUND_MIXER_MUTE)
#define SOUND_MASK_ENHANCE	(1 << SOUND_MIXER_ENHANCE)
#define SOUND_MASK_LOUD		(1 << SOUND_MIXER_LOUD)

#define ISS_MIXER_CHANNEL_MASTER_VOLUME		SOUND_MIXER_VOLUME
#define ISS_MIXER_CHANNEL_BASS				SOUND_MIXER_BASS
#define ISS_MIXER_CHANNEL_TREBLE			SOUND_MIXER_TREBLE

/*
  LibISS and Service
*/
#define ISS_VERSION 0x00010001

#define MAX_ISS_STREAMS		 		   128
#define MAX_STREAM_PACKETS			   16
#define MAX_PLUGINS					   32
#define MAX_MIXERS		 		 	   64
#define ISS_MAX_MIXER_CHANNELS 32


struct sISSInputHandle;
struct sISSFormat;
struct sISSStream;
struct sISSConnection;

enum
{
	ISS_PLUGIN_TYPE_INPUT = 1,
	ISS_PLUGIN_TYPE_VISUALIZATION
};

typedef struct sISSPlugin
{
	unsigned int uiType;
	int bEnabled;
	char ucName[255];
	char *pDescriptionShort;
	char *pDescriptionLong;
	void *pData;
} sISSPlugin;

HRESULT ISS_InputPluginLoad(sDllHandle *pHandle, char *ucName);

typedef struct sISSDeviceCmdOutputBuffer
{
	int iFragments;
	int iFragmentsTotal;
	int iFragmentSize;
	int iBytes;
} sISSDeviceCmdOutputBuffer;

typedef struct sISSMixerChannel
{
		 char ucName[64];
		 char ucGroup[64];
		 char bStereo;
		 char bValue;
		 unsigned int  uiValue;

		 void *pCookie;
		 int (*Set)(void *, void *, unsigned int uiValue);
		 unsigned int (*Get)(void *, void *);
} sISSMixerChannel;

typedef struct sISSMixerDescription
{
		 unsigned int uiMixers;
		 sISSMixerChannel pChannels[ISS_MAX_MIXER_CHANNELS];
} sISSMixerDescription;

typedef struct sISSMixerInfo
{
		 char ucName[255];
		 char ucDevice[255];
		 unsigned int  uiChannels;
} sISSMixerInfo;

typedef struct sISSMixerChannelInfo
{
		 char ucName[64];
		 char ucGroup[64];
		 char bStereo;
		 char bValue;
		 unsigned int  uiValue;
		 unsigned int  uiChannel;
		 unsigned int  uiChannelType;
} sISSMixerChannelInfo;


typedef struct sISSSoundInfo
{
		 char ucName[255];
		 char ucDevice[255];
} sISSSoundInfo;

typedef struct sISSDataPlane
{
	char *pData;
	unsigned int uiSize;
} sISSDataPlane;

typedef struct sISSInputPacket
{
		int iStream;
		unsigned int uiID;
		long long ullTimestamp;
		void *pPrivateData;
		struct sISSInputPacket *pNext;
		struct sISSInputPacket *pPrev;
		sISSDataPlane pPlane[PACKET_DATA_PLANES];
} sISSInputPacket;

typedef struct sISSInputInterface
{
		 HRESULT (*Description)(char **ppShort, char **ppLong);
		 HRESULT (*Enabled)(void);
		 HRESULT (*OpenFile)(struct sISSInputHandle *pInputHandle);
		 HRESULT (*Close)(struct sISSInputHandle *pInputHandle);
		 HRESULT (*GetStreams)(struct sISSInputHandle *pInputHandle, unsigned int *puiStreams);
		 HRESULT (*GetStreamFormat)(struct sISSInputHandle *pInputHandle, struct sISSStream *pStream, struct sISSFormat *pFormat);
		 HRESULT (*FetchPacket)(struct sISSInputHandle *pInputHandle, sISSInputPacket **pPacket);
		 HRESULT (*DecodePacket)(struct sISSInputInterface *pInputInterface, struct sISSStream *pStream, sISSInputPacket *pInputPacket, sISSInputPacket **pDecodedPacket);
		 HRESULT (*DecodeStream)(struct sISSInputInterface *pInputInterface, struct sISSStream *pStream);
		 HRESULT (*FreePacket)(struct sISSInputInterface *pInputInterface, sISSInputPacket *pPacket);
		 HRESULT (*StreamLength)(struct sISSInputHandle *pInputHandle, unsigned int uiStreamIndex, unsigned long long *ullLength);
		 HRESULT (*StreamPos)(struct sISSInputHandle *pInputHandle, unsigned int uiStreamIndex, unsigned long long *ullPos);
		 HRESULT (*StreamSeek)(struct sISSInputHandle *pInputHandle, unsigned int uiStreamIndex, unsigned long long ullPos);

		 HRESULT (*AllocDecodePacket)(struct sISSConnection *pISS, struct sISSInputHandle *pInputHandle, struct sISSStream *pStream, char bVideo, sISSInputPacket **ppPacket);
		 HRESULT (*FreeDecodePacket)(struct sISSConnection *pISS, struct sISSInputHandle *pInputHandle, struct sISSStream *pStream, char bVideo, sISSInputPacket *pPacket);
} sISSInputInterface;


typedef struct sISSInputHandle
{
		 char ucFilename[255];
		 void *pInputPrivate;
		 sISSInputInterface *pInputInterface;
	 	void *hSemaphoreInput;

} sISSInputHandle;

		 
typedef struct sISSFormat
{
		 char bAudio;
		 char bVideo;
		 unsigned int uiChannels;
		 unsigned int uiSpeed;
		 unsigned int uiResolution;

		 unsigned int uiPixFormat;
		 unsigned int uiWidth;
		 unsigned int uiHeight;

		 float fFrameRate;

		 char ucCodec[255];

		 unsigned int uiReserved[8];
} sISSFormat;

typedef struct sISSStreamInfo
{
		 char ucStreamName[255];
		 unsigned int  uiVolume;
		 unsigned int  uiEqualizer[255];
		 unsigned int uiStreamIndex;
		 sISSFormat   pISSFormat;
} sISSStreamInfo;
 
typedef struct sISSStream
{
		 unsigned int uiStreamIndex;
		 sISSFormat   pFormat;
		 void *pPrivate;
} sISSStream;

typedef struct sSoundDevice
{
		 sISSFormat pFormat;
		 char ucDeviceFile[255];
		 unsigned int  uiStatus;
		 int fd;
		 unsigned int  uiBufferSize;

		 char *ucMixBuffer;
		 char *ucValueBuffer;
		 unsigned int  uiMasterVolume;
} sSoundDevice;



typedef struct sStream
{
		 sSoundDevice *pSoundDevice;

		 sISSFormat pFormat;
		 char ucName[255];
		 unsigned int uiHandle;

		 unsigned int uiQueuedPackets;
		 unsigned int uiVolume;
		 struct sStreamPacket *pPackets[MAX_STREAM_PACKETS+1];

		 unsigned int uiEqualizer[255];
		 unsigned int uiEqualizerPos;
		 unsigned int uiPid;
		 unsigned int uiPlayedBytes;

		 unsigned long long ullCurrentPlayTime;
		 unsigned long long ullFirstPlayTime;

		 char bEnabled;
} sStream;

typedef struct sISSConnection
{
		 unsigned int depServer;
		 unsigned int depClient;
		 unsigned int uiUsage;
} sISSConnection;

typedef struct sSoundCommandHeader
{
		 unsigned int uiType;
		 unsigned int uiSize;
		 unsigned int depClient;
} sSoundCommandHeader;



enum
{
		 ISS_COMMAND_VERSION = 1,
		 ISS_COMMAND_CONNECT,
		 ISS_COMMAND_CREATE_STREAM,
		 ISS_COMMAND_CLOSE_STREAM,
		 ISS_COMMAND_PLAY_BUFFER,
		 ISS_COMMAND_GUI,
		 ISS_COMMAND_STREAM_INFO,
		 ISS_COMMAND_LIVE_SIGN,
		 ISS_COMMAND_MIXER_GET_AVAILABLE,
		 ISS_COMAMND_MIXER_GET_VALUE,
		 ISS_COMAMND_MIXER_SET_VALUE,
		 ISS_COMMAND_SOUND_GET_AVAILABLE,
		 ISS_COMAMND_MIXER_GET_CHANNEL_INFO,
		 ISS_COMAMND_MIXER_SET_CHANNEL_INFO,
		 ISS_COMMAND_STOP_STREAM,
		 ISS_COMMAND_QUEUE_USAGE,
		 ISS_COMMAND_QUEUE_PLAY_TIME,
		 ISS_COMMAND_ABORT_STREAM,
		 ISS_COMMAND_STREAM_SET_TIME,
		 ISS_COMMAND_ENABLE_STREAM

};

typedef struct sSoundCommandVersionReply
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiVersion;
}sSoundCommandVersionReply;

typedef struct sSoundCommandConnect
{
		 sSoundCommandHeader pHeader;
		 char ucClientPipe[255];
		 unsigned int  uiRet;
		 unsigned int uiVersion;
}sSoundCommandConnect;

typedef struct sISSCommandCreateStream
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiChannels;
		 unsigned int uiSpeed;
		 unsigned int uiResolution;
		 unsigned int uiPid;
		 char ucName[255];
		 unsigned int uiHandle;
} sISSCommandCreateStream;


typedef struct sISSCommandCloseStream
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiHandle;
} sISSCommandCloseStream;

typedef struct sISSCommandEnableStream
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiHandle;
		 unsigned int uiEnable;
} sISSCommandEnableStream;


typedef struct sISSCommandStopStream
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiHandle;
} sISSCommandStopStream;

typedef struct sISSCommandQueueUsage
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiHandle;
		 HRESULT hr;
		 int iPercent;
		 int iQueued;
} sISSCommandQueueUsage;

typedef struct sISSCommandAbortStream
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiHandle;
		 HRESULT hr;
		 char bResetTime;
} sISSCommandAbortStream;


typedef struct sISSCommandQueuePlayTime
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiHandle;
		 HRESULT hr;
		 isstime ullPlayTime;
		 int iQueued;
		 int bIncludeQueueBuffer;
} sISSCommandQueuePlayTime;


typedef struct sISSCommandPlayBuffer
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiHandle;
		 unsigned int uiSize;
		 long long ullScheduledPlayTime;
		 HRESULT hr;
		 char bWait;
		 unsigned int uiID;
		 char pData[0];
} sISSCommandPlayBuffer;

typedef struct sISSCommandStreamInfo
{
		 sSoundCommandHeader pHeader;
		 sISSStreamInfo pInfo;
		 HRESULT hr;
} sISSCommandStreamInfo;

typedef struct sISSCommandMixerGetAvailable
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiCount;
		 char pData[0];
} sISSCommandMixerGetAvailable;

typedef struct sISSCommandSoundGetAvailable
{
		 sSoundCommandHeader pHeader;
		 unsigned int uiCount;
		 char pData[0];
} sISSCommandSoundGetAvailable;

typedef struct sISSCommandMixerGetChannelInfo
{
		 sSoundCommandHeader pHeader;
		 char ucDevice[255];
		 sISSMixerChannelInfo pInfo;
		 HRESULT hr;
} sISSCommandMixerGetChannelInfo;

typedef struct sISSStreamDescription
{
		 char ucName[256];
		 sISSFormat pFormat;

		 unsigned int uiFirstChannel;
		 unsigned int bSPDIF;
		 unsigned int bLiveStream;

		 unsigned int uiReserved[64];
} sISSStreamDescription;


typedef struct sISSDirectSoundHandle
{
		 char bStop;
		 HRESULT (*fpCallback)(struct sISSDirectSoundHandle* pHandle, unsigned int uiType, unsigned int para1, unsigned int para2, void *vpPara);
		 unsigned int uiBufferSize;
		 unsigned int uiStream;
		 HRESULT hr;
		 int pid;
		 sISSFormat pFormat;
		 void *fpPara;
} sISSDirectSoundHandle;


typedef struct sStreamPacket
{
		 char *pData;
		 unsigned int  uiSize;
		 sISSCommandPlayBuffer *pSourcePacket;
		 char bNotify;
		 unsigned int uiID;
		 unsigned long long ullScheduledPlayTime;
} sStreamPacket;

#define MAX_PLAYBACK_STREAMS 10
#define PLAYBACK_AUDIOSTREAM  0
#define PLAYBACK_VIDEOSTREAM  1
#define PLAYBACK_VIDEO_PACKETS (MAX_STREAM_PACKETS*8)
#define PLAYBACK_VISUALIZATION_PACKETS (MAX_STREAM_PACKETS*2)

enum
{
	ISS_PLAYBACK_STOP_REASON_NOT_STARTED,
	ISS_PLAYBACK_STOP_REASON_STILL_PLAYING,
	ISS_PLAYBACK_STOP_REASON_USER_ABORT,
	ISS_PLAYBACK_STOP_REASON_EOS,
	ISS_PLAYBACK_STOP_REASON_NOTHING_TO_PLAY,
	ISS_PLAYBACK_STOP_REASON_INTERNAL_ERROR
};

typedef struct sISSPlayBackStatistics
{
	int iVideoFramesDropped;
	int iVideoFramesFuture;
	int iVideoFramesPlayed;

	int iAudioBufferUsage;
	int iVideoBufferUsage;

	unsigned int uiLastFrameTime;
	float fLastInterpolatedFPS;
} sISSPlayBackStatistics;

typedef struct sISSPlayBack
{
	sISSConnection  *pISS;
	sISSInputHandle *pInputHandle;
	sISSStream *pStream[MAX_PLAYBACK_STREAMS];
	sISSFormat pFormat[MAX_PLAYBACK_STREAMS];
	char ucErrorText[255];

	int iPlayPID;
	int bSynchron;
	int bLoop;
	int iErrorCount;

	char bPlayVideo;
	char bPlayAudio;
	char bPlayVisualization;
	HANDLE hVideoWnd;
	GC *pGC;
	char bEnd;

	volatile int iQueuedVideoPackets;
	sISSInputPacket *pVideoPackets[PLAYBACK_VIDEO_PACKETS];

	volatile int iQueuedAudioPackets;
	sISSInputPacket *pAudioPackets;

	long long uiStartTime;
	long long uiLastVideoTime;

	int iVideoOutputX;
	int iVideoOutputY;
	int iVideoOutputWidth;
	int iVideoOutputHeight;
	void *hSemaphore;
	void *hSemaphoreVideo;

	int iVideoPlayCount;

	int semaphore_video_play;

	unsigned long long ullInitialSeekPos;

	char *ucVisualization;
	char *ucVisualizationType;
	struct sISSVisualizationHandle *pVisualizationHandle;
	volatile int bVisualizationChanged;
	volatile int bVisualizationRunning;

	char *ucName;
	unsigned int uiStopReason;
	int iVideoThreadPid;
	struct sISSTime *pISSTime;
	char bEndSoft;
	sISSConnection *pISSVideoThread;

	sISSPlayBackStatistics *pStatistics;
	isstime ullSeekPos;
	char bFireAndForget;

	void (*fpVideoCallback)(void *vpCookie, char *pData, int iWidth, int iHeight);
	void *vpVideoCallbackCookie;

	void (*fpStopCallback)(void *vpCookie);
	void *vpStopCallbackCookie;
} sISSPlayBack;

typedef struct sISSVisualization
{
	int bUsed;
	char ucName[255];
	void *vpData;
} sISSVisualization;


typedef struct sISSVisualizationInterface
{
	HRESULT (*Description)(char **ppShort, char **ppLong);
    HRESULT (*Enabled)(void);
	HRESULT (*Init)(char *ucName);
	HRESULT (*Start)(sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSPlayBack *pPlayBack, struct sISSVisualizationHandle *ppVisualizationHandle);
	HRESULT (*Render)(sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSPlayBack *pPlayBack, struct sISSVisualizationHandle *ppVisualizationHandle,	char *ucAudioData, unsigned int uiSize);
	HRESULT (*Stop)(sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSPlayBack *pPlayBack, struct sISSVisualizationHandle *ppVisualizationHandle);
	HRESULT (*GetVisualizations)(sISSVisualization **ppVisualizations);
	HRESULT (*DimensionChanged)(sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSPlayBack *pPlayBack, struct sISSVisualizationHandle *ppVisualizationHandle);
	HRESULT (*TitleChanged)(sISSPlayBack *pPlayBack, struct sISSVisualizationHandle *pVisualizationHandle, char *pNewTitle);

	sISSVisualization *pVisualizations;
	char ucName[255];
} sISSVisualizationInterface;

typedef struct sISSVisualizationHandle
{
	int iThreadID;
	
	sISSVisualizationInterface *pInterface;

	void *pPrivate;
	sISSVisualization *pVisualization;
} sISSVisualizationHandle;

enum
{
	ISS_TIME_EMITTER_SYSTEM,
	ISS_TIME_EMITTER_STREAM
};

typedef struct sISSTime
{
	isstime ullTime;
	isstime ullTimeStart;
	int iTimeEmitterStream;
	int bEmitter;
} sISSTime;


HRESULT 	ISS_DirectSound (sISSConnection *pISS, sISSDirectSoundHandle **ppHandle);
HRESULT 	ISS_DirectSoundSetBufferSize (sISSConnection *pISS, sISSDirectSoundHandle *pHandle, unsigned int uiBufferSize);
HRESULT 	ISS_DirectSoundSetFormat (sISSConnection *pISS, sISSDirectSoundHandle *pHandle, sISSFormat *pFormat);
HRESULT 	ISS_DirectSoundSetCallback (sISSConnection *pISS, sISSDirectSoundHandle *pHandle, void *fp);
HRESULT 	ISS_DirectSoundSetCallbackExt (sISSConnection *pISS, sISSDirectSoundHandle *pHandle, void *fp, void *fpPara);
HRESULT 	ISS_DirectSoundStart (sISSConnection *pISS, sISSDirectSoundHandle *pHandle);
HRESULT 	ISS_InputOpenFile (sISSConnection *pISS, char *pFileName, sISSInputHandle **ppInputHandle);
HRESULT 	ISS_InputCloseFile (sISSConnection *pISS, sISSInputHandle *pInputHandle);
HRESULT 	ISS_InputGetStreams (sISSConnection *pISS, sISSInputHandle *pInputHandle, unsigned int *puiStreams);
HRESULT 	ISS_InputGetStream (sISSConnection *pISS, sISSInputHandle *pInputHandle, unsigned int uiStreamIndex, sISSStream **ppStream);
HRESULT 	ISS_InputGetStreamFormat (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSStream *pStream, sISSFormat *pFormat);
HRESULT 	ISS_InputFetchPacket (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSInputPacket **ppPacket);
HRESULT 	ISS_InputDecodePacket (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSStream *pStream, sISSInputPacket *pPacket, sISSInputPacket *pDecodedPacket);
HRESULT 	ISS_InputFreePacket (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSInputPacket *pPacket);
sISSInputPacket * 	ISS_InputAllocPacket (unsigned int uiSize);
HRESULT 	ISS_InputInterface_DecodeStream (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSStream *pStream);
HRESULT 	ISS_InputInterface_StreamLength (sISSConnection *pISS, sISSInputHandle *pInputHandle, unsigned int uiStreamIndex, unsigned long long *ullLength);
HRESULT 	ISS_InputInterface_StreamPos (sISSConnection *pISS, sISSInputHandle *pInputHandle, unsigned int uiStreamIndex, unsigned long long *ullPos);
HRESULT 	ISS_InputInterface_Seek (sISSConnection *pISS, sISSInputHandle *pInputHandle, unsigned int uiStreamIndex, unsigned long long ullPos);
HRESULT 	ISS_InputFreeStream (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSStream *pStream);
int 	ISS_InputStreamIndex (sISSStream *pStream);
HRESULT 	ISS_InputAllocDecodePacket (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSStream *pStream, char bVideo, sISSInputPacket **ppPacket);
HRESULT 	ISS_InputFreeDecodePacket (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSStream *pStream, char bVideo, sISSInputPacket *pPacket);
HRESULT 	ISS_InputPacketDup (sISSConnection *pISS, sISSInputPacket **ppNew, sISSInputPacket *pPacket, char bReLink);
HRESULT 	ISS_Connect (sISSConnection **ppConnection);
HRESULT 	ISS_Disconnect (sISSConnection *pConnection);
sSoundCommandHeader * 	ISS_AllocPacket (sISSConnection *pISS, unsigned int uiType, unsigned int uiSize);
HRESULT 	ISS_PacketSend (int uiDataExchangePort, sSoundCommandHeader *pPacket);
int 	ISS_ServerPort (sISSConnection *pISS);
int 	ISS_ClientPort (sISSConnection *pISS);
HRESULT 	ISS_PacketReceive (sISSConnection *pISS, int uiDataExchangePort, sSoundCommandHeader **ppPacket, unsigned int uiTimeOut, unsigned int *puiSize);
HRESULT 	ISS_FreePacket (sSoundCommandHeader *pPacket);
HRESULT 	ISS_CreateBasicStream (sISSConnection *pISS, char *ucName, sISSFormat *pFormat, unsigned int *uiStreamHandle);
HRESULT 	ISS_CreateStream (sISSConnection *pISS, sISSStreamDescription *pStream, unsigned int *uiStreamHandle);
HRESULT 	ISS_StreamGetBufferUsage (sISSConnection *pISS, unsigned int uiStreamHandle, int *iPercent);
HRESULT 	ISS_QueueBuffer (sISSConnection *pISS, unsigned int uiID, unsigned int uiStreamHandle, unsigned int uiBufferSize, void *pData);
HRESULT 	ISS_QueueBufferTime(sISSConnection *pISS, unsigned int uiID, unsigned int uiStreamHandle, unsigned int uiBufferSize, void *pData, unsigned long long *pullScheduledPlayTime);
HRESULT 	ISS_QueueBufferAndWait (sISSConnection *pISS, unsigned int uiStreamHandle, unsigned int uiBufferSize, void *pData);
HRESULT 	ISS_StopStream (sISSConnection *pISS, unsigned int uiStream);
HRESULT 	ISS_WaitStream (sISSConnection *pISS, unsigned int uiStreamHandle);
HRESULT 	ISS_CloseStream (sISSConnection *pISS, unsigned int uiStream);
HRESULT 	ISS_GetStreamInformation (sISSConnection *pISS, unsigned int uiStream, sISSStreamInfo *pInfo);
HRESULT 	ISS_GetStreamPacketSize (sISSConnection *pISS, unsigned int uiStream, unsigned int *uiPacketSize);
HRESULT ISS_MixerGetChannelInfo(sISSConnection *pISS,
							    sISSMixerInfo *pMixerInfo,
								unsigned int uiGetType,
								unsigned int uiGetData,
								sISSMixerChannelInfo *pMixerChannelInfo);
HRESULT 	ISS_MixerGetAvailable (sISSConnection *pISS, unsigned int *uiMixers, sISSMixerInfo **ppMixerInfo);
HRESULT 	ISS_SoundDeviceGetAvailable (sISSConnection *pISS, unsigned int *uiDevices, sISSSoundInfo **ppSoundInfo);
HRESULT 	ISS_MixerSetChannel (sISSConnection *pISS, sISSMixerInfo *pMixerInfo, sISSMixerChannelInfo *pMixerChannelInfo);
HRESULT		ISS_PlayFile(char *ucFileName, unsigned int uiFlags);
HRESULT 	ISS_PlayBackNew (sISSConnection *pISS, char *ucFile, sISSPlayBack **ppPlayBack);
HRESULT 	ISS_PlayBackSetVideoWindow (sISSPlayBack *pPlayBack, HANDLE hWnd);
HRESULT 	ISS_PlayBackSetVideo (sISSPlayBack *pPlayBack, char bEnable);
HRESULT 	ISS_PlayBackSetAudio (sISSPlayBack *pPlayBack, char bEnable);
HRESULT 	ISS_PlayBackStart (sISSConnection *pISS, sISSPlayBack *pPlayBack);
HRESULT 	ISS_PlayBackStop (sISSPlayBack *pPlayBack);
HRESULT 	ISS_PlayBackGetErrorText (sISSPlayBack *pPlayBack, char *ucErrorText);
HRESULT 	ISS_PlayBackDestroy (sISSPlayBack *pPlayBack);
HRESULT 	ISS_PlayBackGetStream (sISSPlayBack *pPlayBack, unsigned int uiStreamID, sISSStream **ppStream);
HRESULT 	ISS_PlayBackStreamValid (sISSPlayBack *pPlayBack, unsigned int uiStreamID);
HRESULT 	ISS_PlayBackGetInputHandle (sISSPlayBack *pPlayBack, sISSInputHandle **ppInputHandle);
HRESULT 	ISS_PlayBackSetSynchron (sISSPlayBack *pPlayBack, char bSynchron);
HRESULT 	ISS_PlayBackSetVideoOutputWindow (sISSPlayBack *pPlayBack, HANDLE hWnd);
HRESULT 	ISS_PlayBackSetVideoOutputSize (sISSPlayBack *pPlayBack, int iX, int iY, int iWidth, int iHeight);
HRESULT 	ISS_PlayBackSetVisualization (sISSPlayBack *pPlayBack, int bEnable);
HRESULT 	ISS_PlayBackSetVisualizationWindow (sISSPlayBack *pPlayBack, HANDLE hWnd);
HRESULT 	ISS_PlayBackSetVisualizationPlugin (sISSPlayBack *pPlayBack, char *ucVisualization, char *ucVisualizationType);
HRESULT 	ISS_PlayBackSetVisualizationSize (sISSPlayBack *pPlayBack, int iX, int iY, int iWidth, int iHeight);
HRESULT 	ISS_PlayBackLock (sISSPlayBack *pPlayBack);
HRESULT 	ISS_PlayBackUnLock (sISSPlayBack *pPlayBack);
HRESULT 	ISS_PlayBackRenderStatistic (sISSPlayBack *pPlayBack, int *iDropped, int *iFuture, int *iPlayed, int *iBufferAudio, int *iBufferVideo);
HRESULT 	ISS_PlayBackSetInitialSeekPos (sISSPlayBack *pPlayBack, unsigned long long ullInitialSeekPos);
HRESULT 	ISS_PlayBackSetTitle (sISSPlayBack *pPlayBack, char *ucName);
HRESULT 	ISS_PlayListGetStopReason (sISSPlayBack *pPlayBack, unsigned int *uiReason);
HRESULT 	ISS_VisualizationStart (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSPlayBack *pPlayBack, sISSVisualizationHandle **ppVisualizationHandle);
HRESULT 	ISS_VisualizationStop (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSPlayBack *pPlayBack, sISSVisualizationHandle *pVisualizationHandle);
HRESULT 	ISS_VisualizationRender (sISSConnection *pISS, sISSInputHandle *pInputHandle, sISSPlayBack *pPlayBack, sISSVisualizationHandle *pVisualizationHandle, char *ucAudioData, unsigned int uiAudioDataSize);
HRESULT 	ISS_GetVisualization (unsigned int uiIndex, char *ucName);
HRESULT 	ISS_GetVisualizationType (unsigned int uiIndex, char *ucVisualizationName, char *ucName);
HRESULT 	ISS_GetVisualizationByName (char *ucVisualizationName, char *ucTypeName, sISSVisualizationInterface **ppInterface, sISSVisualization **ppVisualization);
HRESULT ISS_ColorSpaceConvert_rgb24to32(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb8tobgr8(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb15tobgr15(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb15tobgr16(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb15tobgr24(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb15tobgr32(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb16tobgr15(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb16tobgr16(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb16tobgr24(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb16tobgr32(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb32tobgr15(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb32tobgr16(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb32tobgr24(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb32tobgr32(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb24tobgr15(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb24tobgr16(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb24tobgr24(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb24tobgr32(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb16to32(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb16to24(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb16to15(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb15to32(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb15to24(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb32to15(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb15to16(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb32to16(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb32to24(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb24to15(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_rgb24to16(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_yuv2rgb(unsigned char * image, unsigned char * py,
									unsigned char * pu, unsigned char * pv,
									unsigned h_size, unsigned v_size,
									unsigned rgb_stride, unsigned y_stride, unsigned uv_stride);
HRESULT ISS_ColorSpaceConvert_bgr24torgb32(const unsigned char *src,unsigned char *dst,unsigned src_size);
HRESULT ISS_ColorSpaceConvert_Init(void);
HRESULT ISS_ColorSpaceConvert_Packet(sISSConnection *pISS,
									 sISSInputPacket *pPacket,
									 sISSInputPacket **ppConvertedPacket,
									 int iSourceWidth,
									 int iSourceHeight,
									 unsigned int uiColorSpaceSource);

HRESULT ISS_StreamTimeGetDelay(sISSConnection *pISS,
					  unsigned int uiStreamHandle,
					  isstime *pullPlayTime);
HRESULT ISS_StreamTimeGet(sISSConnection *pISS,
						unsigned int uiStreamHandle,
						isstime *pullPlayTime);
HRESULT ISS_StreamSizeToTime(sISSStream *pStream,
							 unsigned long long ullBytes,
							 isstime *pTime);
HRESULT ISS_SizeToTime(sISSFormat *pFormat,
					   isssize ullBytes,
					   isstime *pTime);

HRESULT ISS_StreamTimeToSize(sISSStream *pStream,
							 isstime pTime,
							 unsigned long long *ullBytes);
HRESULT ISS_TimeToSize(sISSFormat *pFormat,
					   isstime pTime,
					   unsigned long long *ullBytes);

unsigned int ISS_ResampleAudio( sISSFormat *pFormat, 
						   sISSFormat *pNewFormat,
						   unsigned short * pDst, 
						   unsigned short * pSrc, 
						   unsigned int uiSize);

HRESULT ISS_ResampleAudioComputeSize(sISSFormat *pFormat, 
									 sISSFormat *pNewFormat,
								     unsigned int uiSize,
									 isssize *pullNewSize);
HRESULT ISS_ResampleAudioRequired(sISSFormat *pFormat, 
							 sISSFormat *pNewFormat,
							 int *uiRequired);

extern unsigned int uiPM_VideoUsage;
extern unsigned int uiPM_AudioUsage;
extern unsigned int uiPM_Future;
extern unsigned int uiPM_Dropped;
extern unsigned int uiPM_Played;
extern unsigned int uiPM_AudioQueued;
extern unsigned int uiPM_VideoQueued;

#ifdef __cplusplus
}
#endif

#endif

