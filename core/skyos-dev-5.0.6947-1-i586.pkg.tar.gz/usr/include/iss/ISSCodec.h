#ifndef	__INC_ISSCodec_H__
#define	__INC_ISSCodec_H__

#include <os/Object.h>

namespace SkyGI
{
class ISSStream;
class ISSFormat;
class ISSPacket;

class ISSCodec : public Object
{
public:
	ISSCodec();
	~ISSCodec();

	virtual String GetName()=0;
	virtual bool Open(ISSStream* pStream, ISSFormat *pCodecFormat, ISSFormat *pOutputFormat, bool bEncode = false) = 0;
	virtual ISSPacket* AllocDecodePacket(ISSStream *pStream) = 0;
	virtual void       FreeDecodePacket(ISSStream *pStream, ISSPacket *pDecodePacket) = 0;
	virtual bool	   DecodePacket(ISSPacket *pPacket) = 0;

private:
	class Private;
	Private *m;
} ;
}

#endif
