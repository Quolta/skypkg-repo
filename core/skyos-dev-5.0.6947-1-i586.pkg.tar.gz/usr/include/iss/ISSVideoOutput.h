#ifndef	__INC_ISSVideoOutput_H__
#define	__INC_ISSVideoOutput_H__

#include <os/Object.h>
#include <gui/Window.h>

namespace SkyGI
{

class ISSPacket;
class ISSStream;
class ISSFormat;

class ISSVideoOutput
{
public:
	ISSVideoOutput();
	virtual ~ISSVideoOutput();

	virtual void DrawFrame(ISSPacket *pPacket);

	virtual void OutputFormatChanged(const ISSFormat pFormat);

private:
	class Private;
	Private *m;
} ;
}

#endif
