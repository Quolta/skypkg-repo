#ifndef	__INC_ISSSource_H__
#define	__INC_ISSSource_H__

#include <iss/ISSManager.h>
#include <iss/ISSInput.h>
#include <iss/ISSPacket.h>

namespace SkyGI
{

class ISSSource : public Object
{
public:
	ISSSource();
	~ISSSource();

	int		   Open(const String &szPath);

	void	   Dump();

	int		   GetStreamCount();
	ISSStream* GetStream(int iIndex);
	bool       FetchPacket(ISSPacket *pPacket);
	void	   FreePacket(ISSPacket *pPacket);
	long long  GetPosition();
	long long  GetSize();
	bool       Seek(long long  llPos);

	bool	   DecodePacket(ISSPacket *pPacket, ISSPacket **pDecodedPacket);


private:
	bool _CreateInputStreams(ISSInput *pPlugin);

	class Private;
	Private *m;
} ;
}

#endif
