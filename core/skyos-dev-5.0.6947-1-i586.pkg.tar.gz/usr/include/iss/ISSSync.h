#ifndef	__INC_ISSSync_H__
#define	__INC_ISSSync_H__

#include <os/Object.h>

namespace SkyGI
{
class ISSOutput;
class ISSStream;

class ISSSync : public Object
{
public:
	ISSSync();
	~ISSSync();

	bool SetTimeEmitter(ISSOutput *pOutput, ISSStream *pOutputStream);
	long long Time();
	void Set(long long llTime);
	void Invalidate();

private:
	class Private;
	Private *m;
} ;
}

#endif
