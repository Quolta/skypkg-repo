#ifndef	__INC_ISSConvert_H__
#define	__INC_ISSConvert_H__

#include <iss/ISSManager.h>
#include <gui/Point.h>
#include <gui/Color.h>

namespace SkyGI
{

class ISSConvert : public Object
{
public:
	ISSConvert();
	~ISSConvert();

	static void Init();
	static void rgb24to32(const void *src, void *dst, int src_size);
	static void rgb8tobgr8(const void *src,void *dst,int src_size);
	static void rgb15tobgr15(const void *src,void *dst,int src_size);
	static void rgb15tobgr16(const void *src,void *dst,int src_size);
	static void rgb15tobgr24(const void *src,void *dst,int src_size);
	static void rgb15tobgr32(const void *src,void *dst,int src_size);
	static void rgb16tobgr15(const void *src,void *dst,int src_size);
	static void rgb16tobgr16(const void *src,void *dst,int src_size);
	static void rgb16tobgr24(const void *src,void *dst,int src_size);
	static void rgb16tobgr32(const void *src,void *dst,int src_size);
	static void rgb32tobgr15(const void *src,void *dst,int src_size);
	static void rgb32tobgr16(const void *src,void *dst,int src_size);
	static void rgb32tobgr24(const void *src,void *dst,int src_size);
	static void rgb32tobgr32(const void *src,void *dst,int src_size);
	static void rgb24tobgr15(const void *src,void *dst,int src_size);
	static void rgb24tobgr16(const void *src,void *dst,int src_size);
	static void rgb24tobgr24(const void *src,void *dst,int src_size);
	static void rgb24tobgr32(const void *src,void *dst,int src_size);
	static void rgb16to32(const void *src,void *dst,int src_size);
	static void rgb16to24(const void *src,void *dst,int src_size);
	static void rgb16to15(const void *src,void *dst,int src_size);
	static void rgb15to32(const void *src,void *dst,int src_size);
	static void rgb15to24(const void *src,void *dst,int src_size);
	static void rgb32to15(const void *src,void *dst,int src_size);
	static void rgb15to16(const void *src,void *dst,int src_size);
	static void rgb32to16(const void *src,void *dst,int src_size);
	static void rgb32to24(const void *src,void *dst,int src_size);
	static void rgb24to15(const void *src,void *dst,int src_size);
	static void rgb24to16(const void *src,void *dst,int src_size);
	static void bgr24torgb32(const void *src, void *dst,int src_size);
	static void yuv2rgb(void * image, void* py,
			      void * pu, void * pv,
			      int h_size, int v_size,
			      int rgb_stride, int y_stride, int uv_stride);

private:
} ;
}

#endif
