#ifndef	__INC_ISSService_H__
#define	__INC_ISSService_H__

#include <iss/ISSManager.h>
#include <iss/ISSInput.h>
#include <iss/ISSPacket.h>
#include <os/DesktopCommunication.h>
#include <os/DataExchangePort.h>

namespace SkyGI
{

class ISSServicePacket
{
public:
	ISSServicePacket(int iType, int iSize);
	~ISSServicePacket();

	void* Data() { return m_vpData; }
	int   Size() { return m_iSize; }
	void  Clear();
	bool  SetSize(int iSize);

private:
	void *m_vpData;
	int   m_iSize;

};

class ISSServiceConnection
{
public:
	ISSServiceConnection()
	{
		pServicePort = pLocalPort = NULL;
	}

	~ISSServiceConnection()
	{
	}


	DataExchangePort *pServicePort;
	DataExchangePort *pLocalPort;

};

class ISSMixer;
class ISSMixerChannel;

class ISSService : public Object
{
public:
	ISSService();
	~ISSService();

	bool Connect();

	int  CreateStream(const String& szStreamName, ISSFormat *pFormat);
	bool DestroyStream(int iStreamIndex);
	bool Send(ISSServicePacket& pPacket);
	bool Receive(ISSServicePacket &pPacket, int iTimeOut);

	bool WritePacket(int iStreamIndex, ISSPacket *pPacket);

	float GetBufferUsage(int iStreamIndex);
	long long GetTime(int iStreamIndex);
	long long GetBufferedTime(int iStreamIndex);

	void      SetTime(int iStreamIndex, long long llTime);

	bool  WaitForStream(int iStreamIndex);

	bool Abort(int iStreamIndex);

	bool Enable(int iStreamIndex);
	bool Disable(int iStreamIndex);

	ISSStream *GetStream(int iStreamIndex);

	int CountMixers();

	ISSMixer *			GetMixer(int iIndex, const String szMixerName = "");
	ISSMixerChannel*	GetMixerChannel(ISSMixer *pMixer, int iChannelIndex);
	int					GetMixerChannelVolume(ISSMixerChannel *pChannel);
	int					SetMixerChannelVolume(ISSMixerChannel *pChannel, int iVolume);


private:
	ISSServiceConnection *_GetConnection();

	class Private;
	Private *m;
} ;
}

#endif
