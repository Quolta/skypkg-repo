#ifndef	__INC_ISSInput_H__
#define	__INC_ISSInput_H__

#include <os/Object.h>

namespace SkyGI
{

class ISSPacket;
class ISSStream;
class ISSFormat;

class ISSInput 
{
public:
	ISSInput();
	virtual ~ISSInput();

	virtual String GetName()=0;
	virtual bool Open(const String& szPath) = 0;
	virtual int  GetStreamCount() = 0;
	virtual bool OpenStream(int iIndex, ISSStream *pStream) = 0;
	virtual bool FetchPacket(ISSPacket *pPacket) = 0;
	virtual void FreePacket(ISSPacket *pPacket) = 0;
	virtual long long GetPosition() {return 0;};
	virtual long long GetSize() {return 0;};
	virtual bool      Seek(long long  llPos) { return false;}
	virtual bool	IsStream()				{ return false; }



private:
	class Private;
	Private *m;
} ;
}

#endif
