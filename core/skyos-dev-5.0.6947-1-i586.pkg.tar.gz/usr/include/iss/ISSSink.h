#ifndef	__INC_ISSSink_H__
#define	__INC_ISSSink_H__

#include <iss/ISSManager.h>
#include <iss/ISSOutput.h>
#include <iss/ISSPacket.h>

namespace SkyGI
{

class ISSSink : public Object
{
public:
	ISSSink();
	~ISSSink();

	int		   Open(const String &szPath);
	int		   OpenDefaultAudioOutputDevice();
	int		   OpenDefaultVideoOutputDevice();

	ISSStream* CreateStream(ISSStream *pInputStream, const String& szStreamName);
	bool	   WritePacket(ISSStream *pStream, ISSPacket *pPacket);

	float	   GetBufferUsage(ISSStream *pStream);
	void	   Dump();

private:
	class Private;
	Private *m;
} ;
}

#endif
