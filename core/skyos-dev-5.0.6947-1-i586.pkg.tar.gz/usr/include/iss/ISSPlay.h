#ifndef	__INC_ISSPlay_H__
#define	__INC_ISSPlay_H__

#include "iss/ISSManager.h"
#include "iss/ISSSource.h"
#include "iss/ISSStream.h"
#include "iss/ISSPacket.h"
#include "iss/ISSSink.h"
#include "iss/ISSVideoOutput.h"
#include "iss/ISSSync.h"
#include <os/Object.h>

namespace SkyGI
{
class ISSStream;
class ISSFormat;
class ISSPacket;

class ISSPlay : public Object
{
public:
	ISSPlay();
	~ISSPlay();

	bool Open(const String& szFileName);
	bool Play();
	bool Stop();
	bool Pause();
	bool Wait();
	bool IsPlaying();
	void Invalidate();
	bool IsEOF();
	void SetEOF(bool bEOF);
	bool IsValid();
	bool Close();

	void EnableAudioOutput(bool bEnable);
	void EnableVideoOutput(bool bEnable);

	virtual ISSOutput* OpenAudioOutputDevice(ISSInput *pInput, ISSStream *pInputStream);
	virtual ISSOutput* OpenVideoOutputDevice(ISSInput *pInput, ISSStream *pInputStream);

	ISSSource* GetSource();

	ISSStream* GetAudioInputStream();
	ISSStream* GetVideoInputStream();

	ISSStream* GetAudioOutputStream();
	ISSStream* GetVideoOutputStream();

	bool	SetVideoOutputInterface(ISSVideoOutput *pInterface);

	long long GetSyncTime();

	bool    Seek(long long ullPos);
	long long GetSize();
	long long GetPos();

private:
	int _PlayThread();
	static int _PlayThreadEntry(ISSPlay *pPlay);

	class Private;
	Private *m;
} ;
}

#endif
