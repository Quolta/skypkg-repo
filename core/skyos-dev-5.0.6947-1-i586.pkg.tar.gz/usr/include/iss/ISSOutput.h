#ifndef	__INC_ISSOutput_H__
#define	__INC_ISSOutput_H__

#include <os/Object.h>

namespace SkyGI
{

class ISSPacket;
class ISSStream;
class ISSFormat;
class ISSVideoOutput;
class ISSSync;

class ISSOutput 
{
public:
	ISSOutput();
	virtual ~ISSOutput();

	virtual String GetName()=0;
	virtual bool Open(const String& szPath) = 0;
	virtual bool Close() = 0;

	virtual int   GetSupportedStreamCount() = 0;
	virtual ISSStream* CreateStream(ISSStream *pInputStream, const String& szStreamName)=0;
	virtual bool  WritePacket(ISSStream* pStream, ISSPacket *pPacket) = 0;
	virtual float GetBufferUsage(ISSStream *pStream) = 0;
	virtual bool  SetVideoOutput(ISSVideoOutput* pInterface){return false;};
	virtual long long GetTime(ISSStream *pStream)=0;
	virtual long long GetBufferedTime(ISSStream *pStream)=0;
	virtual bool  Flush(){return false;};
	virtual void  SetSync(ISSSync *pSync){};
	virtual void  SetTime(ISSStream* pStream, long long llTime)=0;
	virtual bool  Clear(ISSStream *pStream){ return false;};
	virtual bool  EnableStream(ISSStream *pStream){ return true;};
	virtual bool  DisableStream(ISSStream *pStream){ return true;};

private:
	class Private;
	Private *m;
} ;
}

#endif
