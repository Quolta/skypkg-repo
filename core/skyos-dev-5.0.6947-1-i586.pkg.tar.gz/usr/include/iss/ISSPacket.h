#ifndef	__INC_ISSPacket_H__
#define	__INC_ISSPacket_H__

#include <iss/ISSManager.h>
#include <gui/Point.h>
#include <gui/Color.h>
namespace SkyGI
{

class ISSPacket : public Object
{
public:
	ISSPacket();
	ISSPacket(int iDataSize);
	ISSPacket(ISSPacket *pPacket);
	~ISSPacket();

	ISSStream* GetStream()
	{
		return m_pStream;
	}

	void Dump();

	int					m_iStream;
	ISSStream*			m_pStream;
	void*				m_pPrivate;
	unsigned long long  m_ullTimeStamp;
	bool				m_bKeepData;

	struct sPlane
	{
		int   iSize;
		void *vpData;
	} m_pPlane[4];

	ISSPacket* ConvertVideo(Colorspace nNewColorSpace, ISSPacket *pSource, const Point& pSourceSize, Colorspace nSourceColorSpace);

private:
	class Private;
	Private *m;
} ;
}

#endif
