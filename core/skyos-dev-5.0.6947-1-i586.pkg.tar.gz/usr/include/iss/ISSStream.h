#ifndef	__INC_ISSStream_H__
#define	__INC_ISSStream_H__

#include <os/Object.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <iss/ISSInput.h>
#include <iss/ISSPlugin.h>

namespace SkyGI
{
class ISSPacket;
class ISSPlugin;
class ISSCodec;

class ISSFormat : public Object
{
public:
	ISSFormat()
	{
		bVideo = false;
		bAudio = false;

		fBitRate = 0;
		pAudio.fSampleRate   = 0;
		pAudio.iChannels     = 0;
		pAudio.iBitsPerSample = 0;

		pVideo.fFrameRate    = 0.0;
		pVideo.pSize         = Point(0,0);
		pVideo.nColorSpace   = COLORSPACE_UNDEFINED;
		szCodec = "";
	}

	void Dump()
	{
		printf("Type    : %s\n", (bAudio)?"Audio":"Video");
		printf("BitRate : %.f\n", fBitRate);
		printf("Codec   : %s\n", szCodec.c_str());
		if (bAudio)
		{
			printf("   SampleRate    : %.f\n", pAudio.fSampleRate);
			printf("   Channels      : %d\n", pAudio.iChannels);
			printf("   BitsPerSample : %d\n", pAudio.iBitsPerSample);
		}
		if (bVideo)
		{
			printf("   FrameRate     : %.f\n", pVideo.fFrameRate);
			printf("   Size          : %dx%d\n", pVideo.pSize.x, pVideo.pSize.y);
			printf("   Colorspace    : %s\n", Color::GetColorspaceString(pVideo.nColorSpace).c_str());
		}
	}


	bool		 bVideo;
	bool		 bAudio;

	float		 fBitRate;
	struct sAudio
	{
		float fSampleRate;
		int   iChannels;
		int   iBitsPerSample;
	} pAudio;

	struct sVideo
	{
		float      fFrameRate;
		Point      pSize;
		Colorspace nColorSpace;
	} pVideo;
	
	String		 szCodec;
	
};

class ISSStream : public Object
{
public:
	ISSStream()
	{
		m_iStreamIndex   = 0;
		m_pPrivate       = NULL;
		m_pDecodedPacket = NULL;
		m_pInput		 = NULL;
		m_pCodec		 = NULL;
	}

	ISSStream(ISSStream *pStream)
	{
		m_iStreamIndex   = 0;
		m_pPrivate       = NULL;
		m_pDecodedPacket = NULL;
		m_pInput		 = NULL;
		m_pCodec		 = NULL;

		m_pFormat = pStream->m_pFormat;
	}
	~ISSStream()
	{
		if (m_pDecodedPacket && m_pCodec)
			m_pCodec->FreeDecodePacket(this, m_pDecodedPacket);
		m_pDecodedPacket = NULL;

	}

	bool SetCodec(ISSCodec *pCodec);
	void Dump();

	ISSFormat		m_pFormat;
	int				m_iStreamIndex;
	void*			m_pPrivate;
	ISSInput*		m_pInput;
	ISSCodec*		m_pCodec;
	ISSPacket*		m_pDecodedPacket;

	String			m_szName;
	float			m_fVolume;
	unsigned int    m_puiEqualizerData[255];

private:
	class Private;
	Private *m;
} ;
}

#endif
