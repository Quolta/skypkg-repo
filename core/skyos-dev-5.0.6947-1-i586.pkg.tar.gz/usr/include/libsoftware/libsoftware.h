#ifndef _INC_LIBSOFTWARE_
#define _INC_LIBSOFTWARE_

typedef struct sSoftwareIter
{
	DIR *d;

	char ucPackageName[4096];
	char ucPathSIF[4096];
	char ucPathThumb[4096];
} sSoftwareIter;

typedef struct sSoftwareHandle
{
	char *ucRoot;
} sSoftwareHandle;

typedef struct sSoftwareDescription
{
	char *pName;
	char *pSourceName;
	char *pVersionString;
	char *pLicense;
	char *pDescriptionShort;
	char *pDescriptionLong;
	char *pCategory;
	char *pInstallationPath;

	DIB *hDIBThumb;
	char *ucPathThumb;
} sSoftwareDescription;

#endif
