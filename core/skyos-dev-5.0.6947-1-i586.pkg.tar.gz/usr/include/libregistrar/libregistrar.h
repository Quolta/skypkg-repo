#ifndef _LIBREGISTRAR_H
#define _LIBREGISTRAR_H

#ifdef __cplusplus
extern "C" {
#endif

HRESULT Registrar_Identify(char *pFilePath, int bWait);
HRESULT Registrar_GetMimeTypeByExtension(char *pExtension, HANDLE *hMimeType);
HRESULT Registrar_GetMimeType(char *pMimeType, HANDLE *hMimeType);
HRESULT Registrar_GetMime(HANDLE hMimeType, 
						  char **ppMimeType);
HRESULT Registrar_GetMimeTypeByIndex(int iIndex, HANDLE *hMimeType);
HRESULT Registrar_GetIconPath(HANDLE hMimeType, char **ppIconPath);
HRESULT Registrar_FreeMimeType(HANDLE hMimeType);
HRESULT Registrar_GetHandler(HANDLE hMimeType,
							 char **ppHandler,
							 char **ppDescription,
							 int iIndex);
HRESULT Registrar_GetExtension(HANDLE hMimeType,
							 char **ppExtension,
							 int iIndex);	

HRESULT Registrar_RemoveExtension(HANDLE hMimeType,
							      char *pExtension);
HRESULT Registrar_RemoveHandler(HANDLE hMimeType,
							      char *pExecutable);
HRESULT Registrar_AddMimeType(char *pMimeType);
HRESULT Registrar_RemoveMimeType(char *pMimeType);
HRESULT Registrar_AddExtension(HANDLE hMimeType,
							   char *pExtension);
HRESULT Registrar_SetIconPath(HANDLE hMimeType,
							  char *pIconPath);
HRESULT Registrar_AddHandler(HANDLE hMimeType,
							 char *pExecutable,
							 char *pDescription);

#ifdef __cplusplus
}
#endif


#endif 


