#ifndef _INC_LIBINDEXFEEDER_H_
#define _INC_LIBINDEXFEEDER_H_

typedef	HRESULT (*fpCallback)(HANDLE hSearch, void *pCookie, char *ucFile, 
							  unsigned int uiDevice, 
							  unsigned long long ullVnode);

HRESULT Index_SearchAlloc(HANDLE *hSearch);
HRESULT Index_SearchSetContent(HANDLE hSearch, char *pContent);
HRESULT Index_SearchSetQuery(HANDLE hSearch, char *pQuery);
HRESULT Index_SearchSetCookie(HANDLE hSearch, void *pCookie);
HRESULT Index_SearchSetCallback(HANDLE hSearch, void *pCallback);
HRESULT Index_SearchExecute(HANDLE hSearch);



#endif

