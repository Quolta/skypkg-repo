#ifndef _INC_LIBGESTURE_
#define _INC_LIBGESTURE_

typedef struct sGesture
{
	char ucName[255];
	char ucFileName[255];
	char pStroke[255];
	int uiAction;
	char ucActionData[4096];
} sGesture;

#endif
