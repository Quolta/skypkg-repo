#ifndef __POLL_H
#define __POLL_H

#include "sys/poll.h"

#endif /* _SYS_POLL_H */
