#ifndef _MNTENT_H
#define _MNTENT_H
#include <stdio.h>
struct mntent {
    char *mnt_fsname;
    char *mnt_dir;
    char *mnt_type;
    char *mnt_opts;
    int mnt_freq;
    int mnt_passno;
};
#define MOUNTED "/etc/mtab"
#define MNTTAB  "/etc/fstab"
static inline FILE *setmntent(const char *f, const char *t) { (void)f; (void)t; return NULL; }
static inline struct mntent *getmntent(FILE *fp) { (void)fp; return NULL; }
static inline int endmntent(FILE *fp) { (void)fp; return 1; }
#endif
