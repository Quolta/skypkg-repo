#ifndef _SOCKIOS_H_
#define _SOCKIOS_H_


#define FIOSETOWN 	0x89000001
#define SIOCSPGRP	0x89000002
#define FIOGETOWN	0x89000003
#define SIOCGPGRP	0x89000004
#define SIOCATMARK	0x89000005
#define SIOCGSTAMP	0x89000006		/* Get stamp */


#define SIOCGIFNAME		0x89300000		/* get iface name		*/
#define SIOCGIFINDEX		0x89300001		/* name -> if_index mapping	*/
#define SIOGIFINDEX		SIOCGIFINDEX		/* misprint compatibility :-)	*/
#define SIOCSIFLINK		0x89300002		/* set iface channel		*/
#define SIOCGIFCONF		0x89300003
#define SIOCGIFCOUNT		0x89300004		/* get number of devices */

/* Commands handled by each interface	*/
#define SIOCGIFFLAGS		0x89300013		/* get flags			*/
#define SIOCSIFFLAGS		0x89300014		/* set flags			*/
#define SIOCGIFADDR		0x89300015		/* get PA address		*/
#define SIOCSIFADDR		0x89300016		/* set PA address		*/
#define SIOCGIFDSTADDR		0x89300017		/* get remote PA address	*/
#define SIOCSIFDSTADDR		0x89300018		/* set remote PA address	*/
#define SIOCGIFBRDADDR		0x89300019		/* get broadcast PA address	*/
#define SIOCSIFBRDADDR		0x8930001a		/* set broadcast PA address	*/
#define SIOCGIFNETMASK		0x8930001b		/* get network PA mask		*/
#define SIOCSIFNETMASK		0x8930001c		/* set network PA mask		*/
#define SIOCGIFMETRIC		0x8930001d		/* get metric			*/
#define SIOCSIFMETRIC		0x8930001e		/* set metric			*/
#define SIOCGIFMEM		0x8930001f		/* get memory address (BSD)	*/
#define SIOCSIFMEM		0x89300020		/* set memory address (BSD)	*/
#define SIOCGIFMTU		0x89300021		/* get MTU size			*/
#define SIOCSIFMTU		0x89300022		/* set MTU size			*/
#define	SIOCSIFHWADDR		0x89300024		/* set hardware address 	*/
#define SIOCGIFENCAP		0x89300025		/* get encapsulations       	*/
#define SIOCSIFENCAP		0x89300026		/* set encapsulations       	*/
#define SIOCGIFHWADDR		0x89300027		/* Get hardware address		*/
#define SIOCGIFSLAVE		0x89300029		/* Driver slaving support	*/
#define SIOCSIFSLAVE		0x89300030
#define SIOCADDMULTI		0x89300031		/* Multicast address lists	*/
#define SIOCDELMULTI		0x89300032
#define SIOCSIFPFLAGS		0x89300034		/* set/get extended flags set	*/
#define SIOCGIFPFLAGS		0x89300035
#define SIOCDIFADDR		0x89300036		/* delete PA address		*/
#define	SIOCSIFHWBROADCAST	0x89300037		/* set hardware broadcast addr	*/

#define SIOCGIFBR		0x89300040		/* Bridging support		*/
#define SIOCSIFBR		0x89300041		/* Set bridging options 	*/

#define SIOCGIFTXQLEN		0x89300042		/* Get the tx queue length	*/
#define SIOCSIFTXQLEN		0x89300043		/* Set the tx queue length 	*/

#define SIOCSIFMEDIA		0x89300044
#define SIOCGIFMEDIA		0x89300045

#define SIOCSPACKETCAP			0x89300047
/* ARP cache control calls. */
#define SIOCDARP	0x89400053		/* delete ARP table entry	*/
#define SIOCGARP	0x89400054		/* get ARP table entry		*/
#define SIOCSARP	0x89400055		/* set ARP table entry		*/

/* RARP cache control calls. */
#define SIOCDRARP	0x89400060		/* delete RARP table entry	*/
#define SIOCGRARP	0x89400061		/* get RARP table entry		*/
#define SIOCSRARP	0x89400062		/* set RARP table entry		*/

#endif
