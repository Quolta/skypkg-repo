struct bootp {
	unsigned char	op;			/* packet opcode type */
	unsigned char	htype;			/* hardware addr type */
	unsigned char	hlen;			/* hardware addr length */
	unsigned char	hops;			/* gateway hops */
	unsigned int    xid;			/* transaction ID */
	unsigned short  secs;			/* seconds since boot began */
	unsigned short  unused;
	struct in_addr	ciaddr;		/* client IP address */
	struct in_addr	yiaddr;		/* 'your' IP address */
	struct in_addr	siaddr;		/* server IP address */
	struct in_addr	giaddr;		/* gateway IP address */
	unsigned char	chaddr[16];		/* client hardware address */
	char	sname[64];		/* server host name */
	char	file[128];		/* boot file name */
	unsigned char	options[312];		/* vendor-specific area */
};

typedef struct dhcp_para
{
	unsigned int ip;
	unsigned int net_mask;
	unsigned int gateway;
} dhcp_para;


