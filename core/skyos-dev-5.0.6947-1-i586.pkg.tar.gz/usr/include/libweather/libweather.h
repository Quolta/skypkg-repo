/* libWeather.h
Author: Peter Speybrouck
contact: peter.speybrouck@gmail.com

client functions
*/
#ifndef __INC_LIBWEATHER_H_
#define __INC_LIBWEATHER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <string.h>
#include <libdcs/libdcs.h>
#include <stdio.h>  // for definition of NULL
#include <stdlib.h>
#include <skyos/libskyos.h>
#include <ctype.h>

#define E_WEATHER_SERVICE_COMM_FAILED    _HRESULT_TYPEDEF_(0x81000000L)
#define E_WEATHER_NO_DATA_FOR_CITY       _HRESULT_TYPEDEF_(0x81000001L)
#define E_WEATHER_CITY_NOT_FOUND         _HRESULT_TYPEDEF_(0x81000002L)
#define E_WEATHER_CONNECTION_LOST        _HRESULT_TYPEDEF_(0x81000003L)
#define WEATHER_AMERICAN 0
#define WEATHER_METRIC 1

#ifndef WEATHER_SERVICE

typedef struct s_head{
       char locale[30];                                /* text localization of the document    */
       char format[30];                                /* text format of the document [ SHORT | MEDIUM | LONG ]    (form)*/
       char unitTemperature[30];                       /* text unit of temp [ F | C ]    (ut)*/
       char unitDistance[30];                          /* text unit of distance   (ud) */
       char unitSpeed[30];                             /* text unit of speed   (us) */
       char unitPrecipitation[30];                     /* text unit of precipitation   (up) */
       char unitPresure[30];                           /* text unit of presure   (ur) */
       unsigned int uiReserved[16];
} s_head;
typedef struct s_loc{
       char id[20];                                    /* text location id    */
       char displayName[100];                          /* text display name of the location   (dnam) */
       char timeFetched[30];                           /* text local time when data was fetched    (tm) */
       char latitude[30];                              /* decimal latitude   (lat) */
       char longitude[30];                             /* decimal longitude   (lon) */
       char sunrise[30];                               /* time of sunrise   (sunr) */
       char sunset[30];                                /* time of sunset   (suns) */
       int timezone;                                   /* integer time zone (GMT Offset)    (zone)*/
       unsigned int uiReserved[16];
} s_loc;
typedef struct s_cc{
       char timeLastUpdated[50];                       /* Date/Time of last update  (lsup)*/
       char observationStation[100];                   /* text name of observation station   (obst) */
       int  temperature;                               /* integer temp   (tmp) */
       int  feelsLike;                                 /* integer feels like temp   (flik) */
       char textDescription[100];                      /* text description of condition   (t) */
       int  icon;                                      /* integer icon code for display   (icon) */
       char presure[30];                               /* decimal current pressure   (bar_r) */
       char pressureAttidude[30];                      /* text description of raise or fall of pressure    (bar_d) */
       int  windSpeed;                                 /* integer wind speed   (wind_s) */
       int  windGustSpeed;                             /* integer maximum wind gust speed   (wind_gust) */
       int  windDirectionDegrees;                      /* integer direction in degrees   (wind_d) */
       char windDirectionText[30];                     /* text description of direction   (wind_t) */
       int  humidity;                                  /* integer relative humidity   (hmid) */
       char visibility[30];                            /* decimal visibility   (vis) */
       int  uvIndex;                                   /* integer index value   (uv_i) */
       char uvDescription[30];                         /* text value description   (uv_t) */
       int  dewPoint;                                  /* integer dew point   (dewp) */
       int  moonIcon;                                  /* integer icon code for moon display   (moon_icon) */
       char moonPhaseDescription[30];                  /* text description of moon phase   (moon_t) */
       unsigned int uiReserved[16];


} s_cc;
typedef struct s_day{
       int day;                                        /* integer day number   (d) */
       char dayName[30];                               /* text day name   (t) */
       char date[30];                                  /* date   (dt) */
       int  temperatureHigh;                           /* integer high temp   (hi) */
       int  temperatureLow;                            /* integer low temp   (low) */
       char sunrise[30];                               /* text time of sunrise   (sunr) */
       char sunset[30];                                /* text time of sunset   (suns) */
       int  dayIcon;                                   /* daytime integer icon code for display   (d_icon) */
       char dayTextDescription[30];                    /* daytime text description of condition   (d_t) */
       int  dayWindSpeed;                              /* daytime integer wind speed   (d_wind_s) */
       int  dayWindGustSpeed;                          /* daytime integer maximum wind gust speed   (d_wind_gust) */
       int  dayWindDirectionDegrees;                   /* daytime integer maximum wind gust speed   (d_wind_d) */
       char dayWindDirectionText[30];                  /* daytime text description of direction    (d_wind_t) */
       char d_bt[30];                                  /* daytime text description of condition (should be equal to d_t)  (d_bt) */
       int  dayPrecipitation;                          /* daytime integer percent chance of precipitation  (d_ppcp) */
       int  dayHumidity;                               /* daytime integer relative humidity   (d_hmid) */
       int  nightIcon;                                 /* nighttime integer icon code for display    (n_icon) */
       char nightTextDescription[30];                  /* nighttime text description of condition   (n_t) */
       int  nightWindSpeed;                            /* nighttime integer wind speed  (n_wind_s) */
       int  nightWindGustSpeed;                        /* nighttime integer maximum wind gust speed    (n_wind_gust) */
       int  nightWindDirectionDegrees;                 /* nighttime integer maximum wind gust speed   (n_wind_d) */
       char nightWindDirectionText[30];                /* nighttime text description of direction    (n_wind_t) */
       char n_bt[30];                                  /* nighttime text description of condition (should be equal to n_t)   (n_bt)*/
       int  nightPrecipitation;                        /* nighttime integer percent chance of precipitation   (n_ppcp) */
       int  nightHumidity;                             /* nighttime integer relative humidity   (n_hmid) */
       unsigned int uiReserved[16];
} s_day;

typedef struct weather{
       s_head head;                                    /* header part of weather data    */
       s_loc location;                                 /* location part containing city data    */
       s_cc currentConditions;                         /* current conditions part    */
       char dayfLsup[50];                              /* time when forcecasts were last updated    */
       s_day forecasts[10];                            /* 10 day forecast weather data*/
       unsigned int uiReserved[16];
} weather;

typedef struct node {
  int  nr;
  char city[100];
  char id[20];
  struct node *next;
} node;

void Weather_DumpData(weather * w);
HRESULT Weather_Connect(HANDLE *ppHandle);
HRESULT Weather_Disconnect(HANDLE *ppHandle);
HRESULT Weather_GetHeader(HANDLE hConnection);
HRESULT Weather_GetCurrentConditions(HANDLE hConnection);
HRESULT Weather_GetForecasts(HANDLE hConnection, int days);
HRESULT Weather_GetLocation(HANDLE hConnection);
HRESULT Weather_GetData(HANDLE hConnection);
int Weather_GetUnits(HANDLE hConnection);
HRESULT Weather_SetUnits(HANDLE hConnection,int units);
HRESULT Weather_ChangeCity(HANDLE hConnection, char * newCity, node** choices, int *iAmountOfCities);
HRESULT Weather_ChangeCityById(HANDLE hConnection, char * id, unsigned int uiFlags);
HRESULT Weather_ChangeCityDialog(HANDLE hConnection,char *pCity,unsigned int uiFlags);
HRESULT Weather_ChangeCityDialogString(HANDLE hConnection,char *pCity,unsigned int uiFlags);
DIB* Weather_GetIcon(int iID, int iSize);
DIB* Weather_GetIconByName(char *pName, int iSize);
weather* Weather_Get(HANDLE hConnection);

/* for handling city searches  */
HANDLE Weather_GetCityChoice(int nr);
void Weather_DeleteChoices(node *ptr );
int Weather_CountChoices();

HRESULT Weather_GetIconPathByName(char *pName, int iSize, char *pPath);
HRESULT Weather_GetIconPath(int iID, int iSize, char *pPath);
#endif

#ifdef __cplusplus
}
#endif

#endif
