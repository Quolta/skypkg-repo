#ifndef _INC_SERVICEMANAGER_
#define _INC_SERVICEMANAGER_

#define MAX_SERVICES 64

enum 
{
	START_MODE_MANUAL=0,
	START_MODE_AUTOMATIC
	
};

typedef struct sService
{
	char bUsed;
	char ucName[255];
	char ucType[255];
	char ucSettingsFile[512];
	char ucSettingsDir[512];

	char ucIconBig[1024];
	char ucIconSmall[1024];

	HRESULT (*ServiceShouldLoad)(struct sService *pService);
	HRESULT (*Start)(struct sService *pService);
	HRESULT (*Stop)(struct sService *pService);
	HRESULT (*ServiceGetName)(char *ucName, char *ucType);
	HRESULT (*ServiceGetIcon)(struct sService *pService, int bBig, char *ucIconPath);
	HRESULT (*ServiceGetStatus)(struct sService *pService, unsigned int *uiStatus);
	char*   (*ServiceGetInfo)(struct sService *pService);
	HRESULT (*ServiceOpenConfiguration)(struct sService *pService);
	unsigned int (*ServiceInitialStartMode)(struct sService *pService);
	int (*ServiceIsConfigurable)();
	int (*ServiceMustBeConfigured)();

	int				uiInitialStartMode;
	sDllHandle		pHandle;
	sDataCollection *pDataCollection;
} sService;

#endif
