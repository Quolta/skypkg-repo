#ifndef _INC_LIBUSER_H
#define _INC_LIBUSER_H

#define __IMPLEMENTES_SYSCALL__

#ifdef __cplusplus
extern "C" {
#endif

#define E_LIBUSER_IN_USE			_HRESULT_TYPEDEF_(0x81000200)	

/*#include "skygi/skygi.h"*/
#include "skyos/types.h"
#include "../source/include/sc.h"

#define USERDIRECTORY_BASE				0
#define USERDIRECTORY_SYSTEM_SETTINGS	1
#define USERDIRECTORY_APPLICATION_DATA  2
#define USERDIRECTORY_TEMP				3
#define USERDIRECTORY_DESKTOP			4
#define USERDIRECTORY_PANEL_PROGRAM     5
#define USERDIRECTORY_PANEL_SETTINGS	6
#define USERDIRECTORY_STARTUP_DIRECTORY 7


#define MAX_USERS 128

typedef struct
{
    unsigned int total[2];
    unsigned int state[4];
    unsigned char buffer[64];
}TMD5Context;

typedef struct 
{
	unsigned char d[16];
}TMD5Digest; 

void MD5InitContext( TMD5Context *pCtx );
void MD5Update( TMD5Context *pCtx, unsigned char *input, unsigned int length );
void MD5Finish( TMD5Context *pCtx, TMD5Digest *digest );


#define USER_FLAG_LOGIN_ALLOWED    0x00000001
#define USER_FLAG_LOGIN_SHOW_ICON  0x00000002

typedef struct sUserRecord
{
	char bUsed;
	char ucLogin[255];
	char ucFullName[255];
	unsigned char ucPassword[16];
	SecurtiyContextAccessFlags scAccessFlag[MAX_ACCESS_FLAG_GROUPS];
	unsigned int  uiUserFlags;
	unsigned int uiReserved[16];
} sUserRecord;

typedef struct sUserDatabase
{
	sUserRecord pUserRecord[MAX_USERS];
} sUserDatabase;


HRESULT UserModifyRight(sUserRecord   *pUserRecord,
						unsigned int uiRight,
						char bGrant);
HRESULT UserGetRecord(sUserDatabase *pUserDatabase,
					  char *ucLogin,
					  sUserRecord   **ppUserRecord);
HRESULT UserDatabaseAdd(sUserDatabase *pUserDatabase, 
						sUserRecord   *pUserRecord);
HRESULT UserDatabaseWrite(sUserDatabase *pUserDatabase);
HRESULT UserDatabaseOpen(sUserDatabase **ppUserDatabase);
int UserDatabaseEncryptPassword(char *pPassword, char *pEncryptedPassword);
char* UserGetRightDescription(unsigned int uiRight);
char *UserIterDescriptions(unsigned int iIndex);
HRESULT UserGetCurrentLoginName(char *ucLoginName);
HRESULT UserGetDirectory(char *pLoginName, unsigned int uiID, char *ucDirectory);
HRESULT UserSecurityCheck(char *ucUserLoginName,
					      sUserRecord *pUserRecord,
						  unsigned int uiRight);
HRESULT UserSwitchSecurityContext(sUserRecord *pRecord, char *ucPassword);

#ifdef __cplusplus
}
#endif


#endif

