#ifndef __SCHED_H__
#define __SCHED_H__

#include <sys/sched.h>

#endif