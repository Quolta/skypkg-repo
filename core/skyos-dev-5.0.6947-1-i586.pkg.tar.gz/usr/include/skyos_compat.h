#ifndef _SKYOS_COMPAT_H
#define _SKYOS_COMPAT_H

/*
 * SkyOS POSIX compatibility shims
 * Fills gaps between SkyOS's newlib headers and modern POSIX/C99 expectations
 */

/* RTLD_LOCAL: dlopen flag to keep symbols local (not exported) */
#ifndef RTLD_LOCAL
#define RTLD_LOCAL 0
#endif

/* sighandler_t: GNU extension typedef for signal handler function type */
#ifndef _SIGHANDLER_T_DEFINED
#define _SIGHANDLER_T_DEFINED
typedef void (*sighandler_t)(int);
#endif

/*
 * struct timespec sub-second stat timestamps (POSIX.1-2008)
 * SkyOS/newlib only provides st_atime/st_mtime/st_ctime as time_t integers.
 * Map st_atim.tv_sec etc. to the integer fields via macros.
 * Note: tv_nsec is always 0 (no sub-second precision).
 */
#include <sys/stat.h>
#include <time.h>

#ifndef st_atim
struct _skyos_fake_timespec { time_t tv_sec; long tv_nsec; };
#define st_atim _skyos_st_atim_compat
#define st_mtim _skyos_st_mtim_compat
#define st_ctim _skyos_st_ctim_compat
/* These won't work as struct member access - need a different approach */
#undef st_atim
#undef st_mtim
#undef st_ctim
#endif

#endif /* _SKYOS_COMPAT_H */
