#ifndef __LIBHASHTABLE_H_
#define __LIBHASHTABLE_H_

#include "skygi/skygi.h"

typedef int fpHashTableCompare(void* vpKey1, void* vpKey2);
typedef int fpHashTableFunction(void* vpKey, int iSize);
typedef int fpHashTableShouldRehash(HANDLE table, int bigger);
typedef void fpHashTableRehash(HANDLE table, int bigger);

HANDLE HashTable_Create(fpHashTableCompare* fpCompare, fpHashTableFunction* fpHash, int iSize);
void   HashTable_Destroy(HANDLE hTable, int iFreeKeys, int iFreeValues); 
void  *HashTable_Find( void* vpKey, HANDLE hTable ); 
int    HashTable_Insert( void* vpKey, void *vpValue, HANDLE hTable, int bAllowDuplicate); 
int    HashTable_Remove( void* vpKey, HANDLE hTable ); 
void   HashTable_InsertValue(void* key, void* value, HANDLE  hTable);
void   HashTable_RemoveValue(void* key, void* value, HANDLE  hTable);
void   HashTable_RemoveAll(void* key, HANDLE  hTable);
void*  HashTable_FindNext(HANDLE  hTable);

void   HashTable_IterBegin(HANDLE  hTable); 
void*  HashTable_IterKey(HANDLE  hTable);
void*  HashTable_IterValue(HANDLE  hTable);


int HashTable_FunctionString(void* vpKey, int iTableSize);
int HashTable_FunctionInteger(void* vpKey, int iTableSize);
int HashTable_FunctionPointer(void* vpKey, int iTableSize);
int HashTable_ComparePointer(void* vpKey1, void* vpKey2);
int HashTable_CompareInteger(void* vpKey1, void* vpKey2);


#endif
