#ifndef _INC_LIBPLUGIN_
#define _INC_LIBPLUGIN_

typedef struct sPluginFunctionReference
{
	unsigned int uiFlags;
	char *pName;
} sPluginFunctionReference;

#define PLUGIN_FUNCTION_REQUIRED	0x00000001
#define PLUGIN_FUNCTION_OPTIONAL	0x00000002
#define PLUGIN_FUNCTION_END			0x00000000

#endif