#ifndef _INC_LIBARCHIVE_H_
#define _INC_LIBARCHIVE_H_

#include "libskyos.h"

enum
{ 
	ARCHIVE_EXTRACT_INFO_ACTION_CREATE_DIRECTORY = 1,
	ARCHIVE_EXTRACT_INFO_ACTION_CREATE_LINK,
	ARCHIVE_EXTRACT_INFO_ACTION_CREATE_FILE,
	ARCHIVE_EXTRACT_INFO_ACTION_WRITE_FILE,
	ARCHIVE_EXTRACT_INFO_ACTION_DONE
};

typedef struct sArchiveEntry
{
	char   *pFile;
	char   *pLinkTo;
	size_t st_size;
	int    st_mode;
	time_t create;
	time_t modify;
	time_t access;
} sArchiveEntry;

typedef struct sArchiveExtractInfo
{
	char *pFile;
	size_t  iFileSizeTotal;
	size_t  iFileSizeExtracted;
	size_t  iArchiveTotal;
	size_t  iArchiveExtracted;
	HANDLE hArchive;
	int iNotifyFileExtractFragmentSize;
	int iAction;
	void *pClass;
} sArchiveExtractInfo;

typedef HRESULT (*fpArchiveListCallback)(HANDLE hArchive, sArchiveEntry *pEntry);
typedef HRESULT (*fpArchiveExtractInfoCallback)(HANDLE hArchive, sArchiveExtractInfo *pInfo);

typedef struct IArchive
{ 
	HRESULT	(*Archive_Open)(const char *pPath, HANDLE hArchive);
	HRESULT (*Archive_List)(HANDLE hArchive, fpArchiveListCallback fpCallback);
	HRESULT (*Archive_GetExtractedArchiveSize)(HANDLE hArchive, size_t *size);
	HRESULT (*Archive_ExtractAll)(HANDLE hArchive, const char *pRoot);
	HRESULT (*Archive_ExtractFiles)(HANDLE hArchive, const char *pFile, const char *pRoot, int bGlob);
	HRESULT (*Archive_Close)(HANDLE hArchive);
} IArchive;

typedef struct sArchive
{
	IArchive *pIArchive;
	void *pCookie;
	fpArchiveExtractInfoCallback fpExtractInfoCallback;
	int bAsynchron;
	int iPid;
} sArchive;



#define E_ARCHIVE_FILE_NOT_FOUND  _HRESULT_TYPEDEF_(0x81000400L)
#define E_ARCHIVE_WRONG_FORMAT    _HRESULT_TYPEDEF_(0x81000401L)
#define E_ARCHIVE_INTERNAL_ERROR  _HRESULT_TYPEDEF_(0x81000402L)

#endif