#ifndef _TASKS_INC_
#define _TASKS_INC_

#define BOOTSTEP_RESOURCES		6
#define BOOTSTEP_SETTINGS			7
#define BOOTSTEP_GFX				8
#define BOOTSTEP_DONE				-1


/*!
  Don't duplicate stdin/stdout/stderr for new process.
  stdin/stdout/stderr will be initialized with no file connected. (no input/output possible)
*/
#define TASK_CREATE_FLAG_NO_DUP_FILES		0x00000001

#define TASK_CREATE_FLAG_STOPPED			0x00000002

#define TASK_CREATE_FLAG_SUSPEND			0x00000004

/*!
  New process will have to same filedescriptors as the current one.
  You have to close the files in the parent and in the new process in order to "physically" release 
  the file.
*/
#define TASK_CREATE_FLAG_DUP_ALL_FILES		0x00000008

/*!
  Child process will get all open file handles from parent. All open file handles from parent will be closed.
*/
#define TASK_CREATE_FLAG_INHERIT_FILES		0x00000010

/*!
  Don't check the close-on-exec flag when creating a new process
*/
#define TASK_CREATE_FLAG_NO_CLOSE_ON_EXEC	0x00000020

#define TASK_CREATE_FLAG_REPLACE_CORE_IMAGE 0x00000040

/*!
  If set, the final task structure is not freed, until the status and exit value is fetched with waitpid.
  exec, execl, execv,.... and fork always defines this option.
  If you want to fetch the exit status of an application launched with ExecuteProcess, you have to specify
  this option manually.
*/
#define TASK_CREATE_FLAG_WAITPID			0x00000080

/*!
  Duplicate the current set signal handlers
*/
#define TASK_CREATE_FLAG_DUP_SIGNALS        0x00000100

#define TASK_CREATE_FLAG_SAME_PGROUP		0x00000200
#define TASK_CREATE_FLAG_PROCESS_TREE		0x00000400
#define TASK_CREATE_FLAG_REPLACE_CORE		0x00000800
#define TASK_CREATE_FLAG_DUP_STDIO  		0x00001000
#define TASK_CREATE_FLAG_WANT_EXIT_CODE		0x00002000
#define TASK_CREATE_FLAG_WANT_WAIT_FOR		0x00002000
#define TASK_CREATE_FLAG_REPLACE_COREIMAGE_NAME 0x00004000
#define TASK_CREATE_FLAG_INIT_WORKING_DIRECTORY 0x00010000
#define TASK_CREATE_FLAG_IS_CRITICAL		0x00020000
#define TASK_CREATE_FLAG_TRACE				0x00040000
#define TASK_CREATE_FLAG_TRACE_TREE			0x00080000
/*!
  Duplicate the current set signal masks. (blocked and pending)
*/
#define TASK_CREATE_FLAG_DUP_SIGNAL_MASK     0x00100000

#define TASK_FLAG_IS_CRITICAL			0x00000001
#define TASK_FLAG_DONT_HANDLE_WINDOWS	0x00000002

#define TASK_FLAG_DEBUG				0x00000001
#define TASK_FLAG_DEBUG_SYSCALL		0x00000002
#define TASK_FLAG_FPU				0x00000004
#define TASK_FLAG_TRASH_HANDLE		0x00000008
#define TASK_FLAG_PROFILE			0x00000010
#define TASK_FLAG_IN_PROFILE		0x00000080
#define TASK_FLAG_INTERRUPT			0x10000000
#define TASK_FLAG_TRACE				0x20000000
#define TASK_FLAG_TRACE_TREE		0x40000000
#define TASK_FLAG_WANT_EXIT_CODE	0x00000020
#define TASK_FLAG_PROCESS_SWITCH_NOT_ALLOWED 0x00000040
#define TASK_FLAG_FPU_USED			0x01000000
#define TASK_FLAG_FPU_DIRTY		    0x02000000
#define TASK_FLAG_SILENT_CRASH      0x04000000

#define TASK_FLAG_DEBUG_MASK		(TASK_FLAG_DEBUG | TASK_FLAG_DEBUG_SYSCALL)

enum
{
	THREADINFO_PAGEFAULTS,
	THREADINFO_HEAP_PAGES,
	THREADINFO_COW_PAGES,
	THREADINFO_STACK_PAGES,
	THREADINFO_FILES_OPENED,
	THREADINFO_FILES_CLOSED,
	THREADINFO_NAME,
	THREADINFO_USER,
	THREADINFO_PRIORITY,
	THREADINFO_TICKS,
	THREADINFO_PGID,
	THREADINFO_SIGNALS,
	THREADINFO_GOODTIME,
	THREADINFO_STATE,

	THREADINFO_CS_SWITCH_TO_BETTER,
	THREADINFO_CS_WAIT_FOR_RESOURCE,
	THREADINFO_CS_YIELD,
	THREADINFO_CS_ACTIVATE_FROM_WORSE,
	THREADINFO_CS_ACTIVATE_GOOD_TIME,
	THREADINFO_CS_ACTIVATE,

	THREADINFO_QUANTUM,
	THREADINFO_DYNAMIC_PRIORITY,
	THREADINFO_AVERAGE_RUNNING_TIME,
	THREADINFO_TICKS_CHILD,
	THREADINFO_STACK_START,
	THREADINFO_STACK_END
};

enum
{
	IMAGEINFO_PATH,
	IMAGEINFO_MAP_END,
	IMAGEINFO_MAP_START
};

typedef struct task_info
{
	char name[255];
	unsigned int  pid;
	unsigned int  state;
} task_info;

typedef struct spawn_para
{
	unsigned int bArgs;
	unsigned int uiStackSize;
	unsigned int arg1;
	unsigned int arg2;
	unsigned int arg3;
	unsigned int arg4;
	unsigned int arg5;
	unsigned int arg6;
	unsigned int arg7;
	unsigned int arg8;
	unsigned int arg9;
	unsigned int arg10;
	unsigned int uiFunction;
	unsigned int impure_data;
	unsigned int uiReserved[2];
} spawn_para;

#define MEMORY_MAP_READ  0x1
#define MEMORY_MAP_WRITE 0x2
#define MEMORY_MAP_EXEC  0x4

enum
{
	MULTIPLE_OBJECTWAIT_TYPE_MESSAGE = 1,
	MULTIPLE_OBJECTWAIT_TYPE_DEP,
	MULTIPLE_OBJECTWAIT_TYPE_DCS_INTERFACE,
	MULTIPLE_OBJECTWAIT_TYPE_FILE
};

#define	MULTIPLE_OBJECTWAIT_READ		SELECT_READ
#define	MULTIPLE_OBJECTWAIT_WRITE		SELECT_WRITE
#define	MULTIPLE_OBJECTWAIT_EXCEPT		SELECT_EXCEPT

typedef struct sMultipleObjectWaitItem
{
	int iType;
	unsigned int uiData1;
	unsigned int uiData2;
	unsigned int bReady;
} sMultipleObjectWaitItem;

#ifdef KERNEL
typedef struct sMultipleObjectWaitRequest
{
	char bReady;
	sWaitQueue  *wq;
	struct sMultipleObjectWaitRequest *pNext;
} sMultipleObjectWaitRequest;
#endif

typedef struct sDebugRequest
{
	int iPid;
	char ucAppName[255];
} sDebugRequest;

/*
   page table handling
*/
/*#define PROT_READ        0x1       
#define PROT_WRITE       0x2       
#define PROT_EXEC        0x4       
#define PROT_NONE        0x0       
*/

/*#define MAP_SHARED       1         
#define MAP_PRIVATE      2         
#define MAP_TYPE         0xf       
#define MAP_FIXED        0x10      
#define MAP_ANONYMOUS    0x20 
#define MAP_NO_ALLOC	 0x40*/

#define PAGE_PRESENT	0x001
#define PAGE_RW			0x002
#define PAGE_USER		0x004
#define PAGE_ACCESSED	0x020
#define PAGE_DIRTY		0x040
#define PAGE_COW		0x200	

enum
{
	THREAD_TYPE_MUTLIMEDIA=0,
	THREAD_TYPE_BACKGROUND_WORKER,
	THREAD_TYPE_IDLE
};

#define MEMORY_MAP_ACCESS_READ		0x00000001
#define MEMORY_MAP_ACCESS_WRITE		0x00000002
#define MEMORY_MAP_FULL_AREA		0x00010000

#define MEMORY_MAP_FLAG_CONTINGOUS  0x00000001

typedef struct sMemoryArea
{
	unsigned int uiAddress;
	unsigned int uiSize;
	unsigned int uiAccessFlags;
	void *vpHandle;
	unsigned int uiMapFlags;
	unsigned int uiReserved[31];
} sMemoryArea;

typedef struct sMapFile
{
	void *start;
	size_t length;
	int prot;
	int flags;
	int fd;
	off_t offset;
	void *vpMappedTo;
} sMapFile;



#define SYSTEM_MODE_LIVECD   0x00000001
#define SYSTEM_MODE_VOLATILE 0x00000002
#define SYSTEM_MODE_BRANCHED 0x00000004
#define SYSTEM_MODE_RESERVED 0x00000008
#define SYSTEM_MODE_NEW		 0x00000010


#endif
