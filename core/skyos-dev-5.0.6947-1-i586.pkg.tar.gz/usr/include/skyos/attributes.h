#ifndef _INC_ATTRIBUTES_H_
#define _INC_ATTRIBUTES_H_

#ifdef __cplusplus
extern "C" {
#endif


#define ATTR_NAME_FILE_DESCRIPTION		".Description"
#define ATTR_NAME_KEYWORDS				"Keywords"

#define ACCESS_METHOD_READ				0x00000001
#define ACCESS_METHOD_WRITE				0x00000002
#define ACCESS_METHOD_CREATE			0x00000004
#define ACCESS_METHOD_UNLINK			0x00000008
#define ACCESS_METHOD_LIST				0x00000010


#define MAKE_ATTR(a,b,c,d) (unsigned int)((a << 24) | (b<<16) | (c << 8) | d)

enum {
ATTR_ANY_TYPE 					= MAKE_ATTR('A','N','Y','T'),
	ATTR_BOOL_TYPE 					= MAKE_ATTR('B','O','O','L'),
	ATTR_CHAR_TYPE 					= MAKE_ATTR('C','H','A','R'),
	ATTR_COLOR_8_BIT_TYPE 			= MAKE_ATTR('C','L','R','B'),
	ATTR_DOUBLE_TYPE 				= MAKE_ATTR('D','B','L','E'),
	ATTR_FLOAT_TYPE 				= MAKE_ATTR('F','L','O','T'),
	ATTR_GRAYSCALE_8_BIT_TYPE		= MAKE_ATTR('G','R','Y','B'),
	ATTR_INT64_TYPE 				= MAKE_ATTR('L','L','N','G'),
	ATTR_INT32_TYPE 				= MAKE_ATTR('L','O','N','G'),
	ATTR_INT16_TYPE 				= MAKE_ATTR('S','H','R','T'),
	ATTR_INT8_TYPE 					= MAKE_ATTR('B','Y','T','E'),
	ATTR_MESSAGE_TYPE				= MAKE_ATTR('M','S','G','G'),
	ATTR_MESSENGER_TYPE				= MAKE_ATTR('M','S','N','G'),
	ATTR_MIME_TYPE					= MAKE_ATTR('M','I','M','S'),
	ATTR_MONOCHROME_1_BIT_TYPE 		= MAKE_ATTR('M','N','O','B'),
	ATTR_OBJECT_TYPE 				= MAKE_ATTR('O','P','T','R'),
	ATTR_OFF_T_TYPE 				= MAKE_ATTR('O','F','F','T'),
	ATTR_PATTERN_TYPE 				= MAKE_ATTR('P','A','T','N'),
	ATTR_POINTER_TYPE 				= MAKE_ATTR('P','N','T','R'),
	ATTR_POINT_TYPE 				= MAKE_ATTR('B','P','N','T'),
	ATTR_RAW_TYPE 					= MAKE_ATTR('R','A','W','T'),
	ATTR_RECT_TYPE 					= MAKE_ATTR('R','E','C','T'),
	ATTR_REF_TYPE 					= MAKE_ATTR('R','R','E','F'),
	ATTR_RGATTR_32_BIT_TYPE 		= MAKE_ATTR('R','G','B','B'),
	ATTR_RGATTR_COLOR_TYPE 			= MAKE_ATTR('R','G','B','C'),
	ATTR_SIZE_T_TYPE	 			= MAKE_ATTR('S','I','Z','T'),
	ATTR_SSIZE_T_TYPE	 			= MAKE_ATTR('S','S','Z','T'),
	ATTR_STRING_TYPE 				= MAKE_ATTR('C','S','T','R'),
	ATTR_TIME_TYPE 					= MAKE_ATTR('T','I','M','E'),
	ATTR_UINT64_TYPE				= MAKE_ATTR('U','L','L','G'),
	ATTR_UINT32_TYPE				= MAKE_ATTR('U','L','N','G'),
	ATTR_UINT16_TYPE 				= MAKE_ATTR('U','S','H','T'),
	ATTR_UINT8_TYPE 				= MAKE_ATTR('U','B','Y','T'),
	ATTR_MEDIA_PARAMETER_TYPE		= MAKE_ATTR('B','M','C','T'),
	ATTR_MEDIA_PARAMETER_WEATTR_TYPE= MAKE_ATTR('B','M','C','W'),
	ATTR_MEDIA_PARAMETER_GROUP_TYPE = MAKE_ATTR('B','M','C','G'),

	 /* deprecated, do not use*/
	ATTR_ASCII_TYPE 				= MAKE_ATTR('T','E','X','T')	/* use ATTR_STRING_TYPE instead*/
};
 
#define B_INT32_TYPE			ATTR_INT32_TYPE
#define B_UINT32_TYPE			ATTR_UINT32_TYPE

#define B_INT64_TYPE			ATTR_INT64_TYPE
#define B_UINT64_TYPE			ATTR_UINT64_TYPE

#define B_FLOAT_TYPE			ATTR_FLOAT_TYPE
#define B_DOUBLE_TYPE			ATTR_DOUBLE_TYPE
#define B_STRING_TYPE			ATTR_STRING_TYPE

#define B_SSIZE_T_TYPE			ATTR_SSIZE_T_TYPE
#define B_SIZE_T_TYPE			ATTR_SIZE_T_TYPE
#define B_OFF_T_TYPE			ATTR_OFF_T_TYPE


typedef struct sAttributesRead
{
	char   ucAttributeName[255];
	unsigned int    uiAttributeType;
	unsigned int    uiOffset;
	unsigned int    uiLength;
	unsigned char   *ucBuffer;
	unsigned int    uiReadBytes;
	char ucOperation;
} sAttributesRead;

typedef struct sAttributesStat
{
	char   ucAttributeName[255];
} sAttributesStat;


typedef struct sAttributesDirectoryEntry
{
	char ucName[255];
	unsigned int  uiType;
	unsigned int  uiLength;
} sAttributesDirectoryEntry;

typedef struct sAttributesDirectory
{
	int fd;

	sAttributesDirectoryEntry pEntry;
} sAttributesDirectory;

enum
{
	ATTR_OPERATION_READ,
	ATTR_OPERATION_WRITE,
	ATTR_OPERATION_DELETE
};

#ifndef KERNEL
int AttributeStat(char *pFileName, int fd, char *ucAttributeName, struct stat *st);
int AttributeRead(char *pFileName, int fd, char *ucAttributeName, unsigned int uiAttributeType,
				  void *pBuffer, unsigned int uiOffset, unsigned int uiLength, unsigned int *uiReadBytes);

				  
int AttributeWrite(char *pFileName, int fd, char *ucAttributeName, unsigned int uiAttributeType,
				  void *pBuffer, unsigned int uiOffset, unsigned int uiLength, unsigned int *uiWritenBytes);

int AttributeRemove(char *pFileName, int fd, char *ucAttributeName);

sAttributesDirectory *AttributeOpenDirectory(const char *pPath);
sAttributesDirectoryEntry *AttributeReadDirectory(sAttributesDirectory *d);
int AttributeCloseDirectory(sAttributesDirectory *d);

#endif

#define SKYOS_SYSTEM_ATTRIBUTE_APPLICATION_ICON_SMALL ".ApplicationIconSmall"
#define SKYOS_SYSTEM_ATTRIBUTE_APPLICATION_ICON_BIG   ".ApplicationIconBig"


#ifdef __cplusplus
}
#endif

#endif



