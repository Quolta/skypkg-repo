#ifndef _INC_PACK_H_
#define _INC_PACK_H_

typedef struct sPackedObject
{
	unsigned int uiSize;
	unsigned int uiOffset;
	char *vpData;
} sPackedObject;

#endif
