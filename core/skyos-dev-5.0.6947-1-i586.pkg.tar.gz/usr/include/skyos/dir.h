#ifndef __INC_DIR_
#define __INC_DIR_

#include "fcntl.h"

#ifndef KERNEL
#include "machine/types.h"
#endif

#ifndef PACKED
	#define PACKED __attribute__((packed))
#endif

typedef struct s_fsinfo
{
	char fs[255];
	char device[255];
} s_fsinfo;
    
#ifndef __NEW_KERNEL__   
struct dirent
{
   long d_version; 
   long d_fd; 
   unsigned long long d_ino; 
   char d_name[256];
   unsigned int  size;
   unsigned int  type;

   time_t        access;
   time_t        modify;
   time_t        create;
}; 
#else
struct dirent
{
   long d_version; 
   long d_fd; 
   dev_t			  d_dev;
   dev_t			  d_pdev;
   long long		  d_ino; 
   long long		  d_pino; 
//   int				  size;
  // unsigned int  type;

   time_t        access;
   time_t        modify;
   time_t        create;

   int d_reclen;
   char d_name[256];
};
#endif


typedef struct DIR
{
	int d_fd;
	struct dirent dp;
} DIR;

DIR *opendir(const char *pPath);
void rewinddir(DIR *dir);
struct dirent *readdir(DIR *d);
int closedir(DIR*);
off_t telldir(DIR *dir);
void seekdir(DIR *dir, off_t offset);
int readdir_r(DIR *d, struct dirent *entry, struct dirent **result);
int scandir (const char *__dir,
             struct dirent ***__namelist,
             int (*select) (const struct dirent *),
             int (*compar) (const struct dirent **, const struct dirent **));

int alphasort (const struct dirent **__a, const struct dirent **__b); 

#endif


