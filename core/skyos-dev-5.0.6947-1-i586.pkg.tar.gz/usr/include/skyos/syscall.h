#if defined(__INSIDE_LIBSKY__) || defined(__IMPLEMENTS_SYSCALL__)
#ifndef I_SYSCALL
#define I_SYSCALL

#ifndef KERNEL
#include <errno.h>
#endif

#ifndef NULL
#define NULL    ((void *)0)
#endif

#define __NR_sys_open		   0
#define __NR_sys_close		   1
#define __NR_sys_os_read	   2
#define __NR_sys_write			   3		
#define __NR_sys_lseek          4
#define __NR_os_exit		   5
#define __NR_sys_sysinfo          6
#define __NR_sys_set_quantum   7

#define __NR_sys_socket        8
#define __NR_sys_bind          9
#define __NR_sys_accept        10

#define __NR_sys_dup			   11
#define __NR_sys_dup2			   12
#define __NR_sys_connect	       13

#define __NR_sys_spawn			   14
#define __NR_sys_user_debug			15
#define __NR_sys_findnext			16
#define __NR_sys_chdir 			    17

#define __NR_sys_mount				18
#define __NR_sys_umount				19
#define __NR_sys_getcwd				20
#define __NR_sys_brk				21
#define __NR_sys_msgbox			22
#define __NR_sys_ioctl			23
#define __NR_sys_getpos         24
#define __NR_sys_module_alloc		  25
#define __NR_sys_module_symbol_size		  26
#define __NR_sys_module_get_symbolt       27
#define __NR_sys_module_init			28
#define __NR_sys_exec					29
#define __NR_call_v86					30
#define __NR_os_image_info				31
#define __NR_sys_get_ticks				32
#define __NR_sys_sendto					33
#define __NR_sys_recvfrom				34
#define __NR_sys_get_curtime			35

#define __NR_sys_shutdown				37
#define __NR_sys_readdir				38
#define __NR_sys_cpe_set				39
#define __NR_sys_createdir				40
#define __NR_sys_ramdisk  				41
#define __NR_sys_sync					42
#define __NR_sys_cache_configure		43
#define __NR_sys_module_unload			44
#define __NR_sys_semaphore				45
#define __NR_sys_SystemInfo				46
#define __NR_sys_getpid					47
#define __NR_sys_gettaskname			48
#define __NR_sys_get_usec_counter		49

#define __NR_sys_RSMGetNodeByName		51
#define __NR_sys_RSMEnumNodes			52
#define __NR_sys_send					53
#define __NR_sys_recv					54
#define __NR_sys_listen					55
#define __NR_sys_ioctlsocket			56
#define __NR_sys_sleeptaskusec			57
#define __NR_sys_fsinfo					58
#define __NR_sys_RSMSetEntry			59
#define __NR_sys_debug_attach			60
#define __NR_sys_debug_action			61
#define __NR_sys_stat					70
#define __NR_sys_notify					71
#define __NR_sys_RSMGetEntry			72
#define __NR_sys_RSMIterEntry			73
#define __NR_sys_RegistryLoad			74
#define __NR_sys_statfs					75
#define __NR_sys_unlink					76
#define __NR_sys_GetMeasurePoint		77
#define __NR_sys_GetMeasurePointByIndex 78
#define __NR_sys_GI_create_window	100
#define __NR_sys_GI_wait_message    101
#define __NR_sys_GI_rect			102
#define __NR_sys_GI_line			103
#define __NR_sys_GI_setpix		    104
#define __NR_sys_GI_post_message    105
#define __NR_sys_GI_blit			106
#define __NR_sys_GI_text			107
#define __NR_sys_GI_set_timer		108
#define __NR_sys_GI_destroy_window  109
#define __NR_sys_GI_set_mouse_pointer 110
#define __NR_sys_GI_get_resolution  111
#define __NR_sys_GI_setup_GFX       112
#define __NR_sys_GI_compute_screen_coordinates 113
#define __NR_sys_GI_set_dimension	114
#define __NR_sys_GI_palette_set_logical 115
#define __NR_sys_GI_beginpaint	116
#define __NR_sys_GI_endpaint	117
#define __NR_sys_GI_window_info 118
#define __NR_sys_GI_get_next_handle 119
#define __NR_sys_GI_window_set_state 120
#define __NR_sys_GI_color_free 		 121
#define __NR_sys_GI_color_get		 122
#define __NR_sys_GI_install_font	 123
#define __NR_sys_GI_get_font		 124
#define __NR_sys_GI_enum_fonts		 125
#define __NR_sys_GI_capture_screen   126
#define __NR_sys_GI_sound_play		 127
#define __NR_sys_GI_sound_setup		 128
#define __NR_sys_GI_sound_max_buffer 129
#define __NR_sys_GI_query_message    130
#define __NR_sys_GI_redraw_window    131
#define __NR_sys_closesocket		 132
#define __NR_sys_kill				 133
#define __NR_sys_task_info			 134
#define __NR_sys_wait_for_task_state 135
#define __NR_sys_syslog_set			 136
#define __NR_sys_GI_copy_rect		 137
#define __NR_sys_theme_get   		 138
#define __NR_sys_theme_set   		 139
#define __NR_sys_GI_mouse_get		 140
#define __NR_sys_clipboard_add		 141
#define __NR_sys_clipboard_get		 142
#define __NR_sys_GI_kill_timer		 143
#define __NR_sys_GI_circle			 144
#define __NR_sys_SystemEventServices_Initialize 145
#define __NR_sys_style_set			 146
#define __NR_sys_style_get           147
#define __NR_sys_DllInfo	         148
#define __NR_sys_get_image_info		 148
#define __NR_sys_DllLoad			 149
#define __NR_sys_DllUnload			 150
#define __NR_sys_DllGetFunction      151
#define __NR_sys_GI_redraw_region    152
#define __NR_sys_TimeDebug			 153
#define __NR_sys_GI_request_fullscreen 154
#define __NR_sys_SetKeyMap 155
#define __NR_sys_GI_GetResource		156
#define __NR_sys_GetNetStatistic	157
#define __NR_sys_GI_set_high_timer     158
#define __NR_sys_RSMGetNodeWithIndex   159

#define __NR_sys_getsockopt				160
#define __NR_sys_setsockopt				161
#define __NR_sys_select    				162
#define __NR_sys_sethostname			163
#define __NR_sys_gethostname			164
#define __NR_sys_isatty					165
#define __NR_sys_fcntl					166
#define __NR_sys_getsockname			167
#define __NR_sys_getpeername			168
#define __NR_sys_SetCapture				169
#define __NR_sys_GI_set_focus			170
#define __NR_sys_debug_data				171
#define __NR_sys_GI_SetWindowCap		172
#define __NR_sys_mem_dump				173
#define __NR_sys_settaskstate			174
#define __NR_sys_tasklogging			175
#define __NR_sys_seek					176
#define __NR_sys_system_busy			177
#define __NR_sys_fork					178
#define __NR_sys_waitpid			    179
#define __NR_sys_utime					180
#define __NR_sys_GI_GetWindow				181
#define __NR_sys_GI_GetDataMessage      182
#define __NR_sys_RegisterMessageDumper  183
#define __NR_sys_GI_SetWindowValue         184
#define __NR_sys_GI_Lock				185
#define __NR_sys_CheckBootOption        186
#define __NR_sys_GI_SetWindowBitmap		187
#define __NR_sys_GetBootKey				188
#define __NR_sys_GI_AddTransparentRect	189
#define __NR_sys_GI_GetMousePos         190
#define __NR_sys_pipe					191
#define __NR_sys_ShdMem					192
#define __NR_sys_GI_SetMousePointerImage 193
#define __NR_sys_NetFilterStart         194
#define __NR_sys_NetFilterGetNextPacket 195
#define __NR_sys_opendir				196
#define __NR_sys_closedir				197
#define __NR_sys_listener_register		198
#define __NR_sys_listener_unregister	199
#define __NR_sys_fs_initialize			200
#define __NR_sys_SendSignal				201
#define __NR_sys_SignalSetHandler		202
#define __NR_sys_return					203
#define __NR_sys_GetProcessImageName    204
#define __NR_sys_GI_SetWindowTitle		205
#define __NR_sys_GI_WindowAtPointer     206
#define __NR_sys_rewinddir				207
#define __NR_sys_tls_alloc				208
#define __NR_sys_tls_free				209
#define __NR_sys_tls_set				210
#define __NR_sys_tls_get				211
#define __NR_sys_SystemEvent			212
#define __NR_sys_profile				213
#define __NR_sys_RegistrySerializeEnable 214
#define __NR_sys_AttributeRead			215
#define __NR_sys_AttributeOpenDirectory 216
#define __NR_sys_AttributeCloseDirectory 217
#define __NR_sys_AttributeReadDirectory 218
#define __NR_sys_GetApplicationDirectory 219

#define __NR_sys_DataExchangePortRegister 220
#define __NR_sys_DataExchangePortConnect  221
#define __NR_sys_DataExchangePortRead     222
#define __NR_sys_DataExchangePortWrite    223
#define __NR_sys_DataExchangePortBlocking 224
#define __NR_sys_DataExchangePortRelease  225
#define __NR_sys_BootStep				  226
#define __NR_sys_SwitchSecurityContext    227
#define __NR_sys_uname					  228
#define __NR_sys_GI_SetMousePos				229
#define __NR_sys_GI_HideMouseCursor			230
#define __NR_sys_GetFSCapability			231
#define __NR_sys_dump_fd					232
#define __NR_sys_sigprocmask				233
#define __NR_sys_setpgid					234
#define __NR_sys_getpgid					235
#define __NR_sys_getppid					236
#define __NR_sys_MapVirtualKey				237
#define __NR_sys_GI_register_accelerator	238
#define __NR_sys_setsid						239
#define __NR_sys_getsid						240
#define __NR_sys_tweak						241
#define __NR_sys_GI_KeyStateGet				242
#define __NR_sys_GI_RaiseWindowToTop		243
#define __NR_sys_rename						244
#define __NR_sys_GI_InjectMouseAction		245
#define __NR_sys_GI_InjectKeyAction		    246
#define __NR_sys_GI_GetMouseState			247
#define __NR_sys_MemoryMap					248
#define __NR_sys_MemoryUnMap				249
#define __NR_sys_usleep						250
#define __NR_sys_SemaphoreCreateEtc			251
#define __NR_sys_SemaphoreCreate			252
#define __NR_sys_SemaphoreDelete			253
#define __NR_sys_SemaphoreDeleteEtc			254
#define __NR_sys_SemaphoreAcquire			255
#define __NR_sys_SemaphoreAcquireEtc		256
#define __NR_sys_SemaphoreRelease			257
#define __NR_sys_SemaphoreReleaseEtc		258
#define __NR_sys_SemaphoreGetCount			259
#define __NR_sys_SemaphoreInfo				260
#define __NR_sys_DataExchangePortDataAvailable 261
#define __NR_sys_ThreadResume				262
#define __NR_sys_TaskInfo					263
#define __NR_sys_GI_PosInWindow				264
#define __NR_sys_MultipleObjectWait			265
#define __NR_sys_MemoryMapGet				266
#define __NR_sys_SystemGetVolumeInformation 267
#define __NR_sys_GetInternalOSVersion       268
#define __NR_sys_symlink					269
#define __NR_sys_readlink					270
#define __NR_sys_DataExchangePortWriteTo	271
#define __NR_sys_DataExchangePortWriteToBroadcast	272
#define __NR_sys_ThreadSetPriority			273
#define __NR_sys_SystemNotificationsGet		274
#define __NR_sys_sigsuspend					275
#define __NR_sys_GetPidOfTask				276
#define __NR_sys_alarm						277
#define __NR_sys_ThreadYield				278
#define __NR_sys_QueryOpen					279
#define __NR_sys_QueryClose					280
#define __NR_sys_QueryRead					281
#define __NR_sys_GetParentNode				282
#define __NR_sys_IndexCreate				283
#define __NR_sys_IndexRemove				284
#define __NR_sys_IndexOpen					285
#define __NR_sys_IndexRead					286
#define __NR_sys_IndexClose					287
#define __NR_sys_LastInputActivity			288
#define __NR_sys_GI_DirectAccess			289
#define __NR_sys_IsDebugKernel				290
#define __NR_sys_GetInternalBuildNumber		291
#define __NR_sys_TaskLogData				292
#define __NR_sys_DragAndDropServiceStart	293
#define __NR_sys_DragAndDropCancel			294
#define __NR_sys_DragAndDropDrop			295
#define __NR_sys_DragAndDropAllow			296
#define __NR_sys_GI_DragAndDropInProgress	297
#define __NR_sys_GI_DragAndDropDeny			298
#define __NR_sys_GI_GetWindowValue			299
#define __NR_sys_fsync						300
#define __NR_sys_DesktopComposing			301
#define __NR_sys_GI_TranslationChanged		302
#define __NR_sys_TaskFlagSet				303
#define __NR_sys_TaskFlagClear				304
#define __NR_sys_TaskFlagsGet				305
#define __NR_sys_gettimeofday				306
#define __NR_sys_GI_RegisterGestureExecutor 307
#define __NR_sys_TraceAction				308
#define __NR_sys_sysconf					309
#define __NR_sys_MemAreaAlloc				310
#define __NR_sys_MemAreaMap					311
#define __NR_sys_GI_WindowSetIcon			312
#define __NR_sys_GI_WindowGetIcon			313
#define __NR_sys_UpdateMeasurePoint			314
#define __NR_sys_AddMeasurePoint			315
#define __NR_sys_HeapAlloc					316
#define __NR_sys_HeapResize					317
#define __NR_sys_ThreadDetach				318
#define __NR_sys_SecurityContextCheckCurrentProcess 319
#define __NR_sys_GI_set_window_mouse_pointer	320
#define __NR_sys_listener_register_thread   321
#define __NR_sys_CheckFilePermission		322
#define __NR_sys_FilePermissionAuthentificate 323
#define __NR_sys_GetFunctionName	324
#define __NR_sys_mmap	325
#define __NR_sys_munmap 326
#define __NR_sys_KernelDebuggerEnter 327
#define __NR_sys_mprotect	328
#define __NR_sys_msync		329
#define __NR_sys_GI_WindowUnlink 330
#define __NR_sys_GI_WindowLink 331
#define __NR_sys_GI_compute_window_coordinates 332
#define __NR_sys_GI_WindowOwnSet	333
#define __NR_sys_GIWM_LayerCommand 334
#define __NR_sys_GI_WindowSetDefaultColor 335
#define __NR_sys_GI_WindowTransparency 336
#define __NR_sys_chmod 337
#define __NR_sys_exit_code 338
#define __NR_sys_getprocesspid 339
#define __NR_sys_clipboard_clear 340
#define __NR_sys_get_usec_idle 341
#define __NR_sys_seekdir 342
#define __NR_sys_telldir 343
#define __NR_sys_sendmsg 344
#define __NR_sys_recvmsg 345
#define __NR_sys_GI_MouseParameterSet 346
#define __NR_sys_GetTasks 347
#define __NR_sys_GetSystemMode 348
#define __NR_sys_SetSystemMode 349
#define __NR_sys_sigpending 350
#define __NR_sys_set_ldt_entry 351
#define __NR_sys_sock_shutdown 352
#define __NR_sys_sigaltstack 353
#define __NR_sys_GI_post_message_thread 354
#define __NR_sys_GI_GetActiveWindow 355
#define __NR_sys_GI_WindowIsVisible 356
#define __NR_sys_fchdir 357
#define __NR_sys_GetImageInfo 358
#define __NR_sys_DataExchangePortClear 359
#define __NR_sys_settimeofday	360
#define __NR_sys_AttributeStat	361


asm (".L__X'%ebx = 1\n\t"
     ".L__X'%ecx = 2\n\t"
     ".L__X'%edx = 2\n\t"
     ".L__X'%eax = 3\n\t"
     ".L__X'%esi = 3\n\t"
     ".L__X'%edi = 3\n\t"
     ".L__X'%ebp = 3\n\t"
     ".L__X'%esp = 3\n\t"
     ".macro bpushl name reg\n\t"
     ".if 1 - \\name\n\t"
     ".if 2 - \\name\n\t"
     "pushl %ebx\n\t"
     ".else\n\t"
     "xchgl \\reg, %ebx\n\t"
     ".endif\n\t"
     ".endif\n\t"
     ".endm\n\t"
     ".macro bpopl name reg\n\t"
     ".if 1 - \\name\n\t"
     ".if 2 - \\name\n\t"
     "popl %ebx\n\t"
     ".else\n\t"
     "xchgl \\reg, %ebx\n\t"
     ".endif\n\t"
     ".endif\n\t"
     ".endm\n\t"
     ".macro bmovl name reg\n\t"
     ".if 1 - \\name\n\t"
     ".if 2 - \\name\n\t"
     "movl \\reg, %ebx\n\t"
     ".endif\n\t"
     ".endif\n\t"
     ".endm\n\t"); 

#undef INLINE_SYSCALL


#define INLINE_SYSCALL(type, name, nr, args...) \
  ({									      \
    type resultvar = INTERNAL_SYSCALL (type, name, , nr, args);	      \
    (type) resultvar; })
 
/* Define a macro which expands inline into the wrapper code for a system
   call.  This use is for internal calls that do not need to handle errors
   normally.  It will never touch errno.  This returns just what the kernel
   gave back.  */
#undef INTERNAL_SYSCALL

# define INTERNAL_SYSCALL(type, name, err, nr, args...) \
  ({									      \
    type resultvar;						      \
    asm volatile (							      \
    LOADARGS_##nr							      \
    "movl %1, %%eax\n\t"						      \
    "int $0xA0\n\t"						      \
    RESTOREARGS_##nr							      \
    : "=a" (resultvar)							      \
    : "i" (__NR_##name) ASMFMT_##nr(args) : "memory", "cc");		      \
    (type) resultvar; })

#undef INTERNAL_SYSCALL_DECL
#define INTERNAL_SYSCALL_DECL(err) do { } while (0)

#undef INTERNAL_SYSCALL_ERROR_P
#define INTERNAL_SYSCALL_ERROR_P(val, err) \
  ((unsigned int) (val) >= 0xfffff001u)

#undef INTERNAL_SYSCALL_ERRNO
#define INTERNAL_SYSCALL_ERRNO(val, err)	(-(val))

#define LOADARGS_0
# define LOADARGS_1 \
    "bpushl .L__X'%k2, %k2\n\t"						      \
    "bmovl .L__X'%k2, %k2\n\t"

#define LOADARGS_2	LOADARGS_1
#define LOADARGS_3	LOADARGS_1
#define LOADARGS_4	LOADARGS_1
#define LOADARGS_5	LOADARGS_1

#define RESTOREARGS_0
#if defined I386_USE_SYSENTER && defined SHARED
# define RESTOREARGS_1 \
    "bpopl .L__X'%k3, %k3\n\t"
#else
# define RESTOREARGS_1 \
    "bpopl .L__X'%k2, %k2\n\t"
#endif
#define RESTOREARGS_2	RESTOREARGS_1
#define RESTOREARGS_3	RESTOREARGS_1
#define RESTOREARGS_4	RESTOREARGS_1
#define RESTOREARGS_5	RESTOREARGS_1

#define ASMFMT_0()
#define ASMFMT_1(arg1) \
	, "acdSD" (arg1)
#define ASMFMT_2(arg1, arg2) \
	, "adSD" (arg1), "c" (arg2)
#define ASMFMT_3(arg1, arg2, arg3) \
	, "aSD" (arg1), "c" (arg2), "d" (arg3)
#define ASMFMT_4(arg1, arg2, arg3, arg4) \
	, "aD" (arg1), "c" (arg2), "d" (arg3), "S" (arg4)
#define ASMFMT_5(arg1, arg2, arg3, arg4, arg5) \
	, "a" (arg1), "c" (arg2), "d" (arg3), "S" (arg4), "D" (arg5)


#define _syscall0(type,name) \
type name(void) \
{ \
	return INLINE_SYSCALL(type, name, 1, 0);\
}

#define _syscall1(type,name,atype,a) \
type name(atype a) \
{ \
	return INLINE_SYSCALL(type, name, 1, a);\
}

#define _syscall2(type,name,atype,a,btype,b) \
type name(atype a,btype b) \
{ \
	return INLINE_SYSCALL(type, name, 2, a, b);\
}

#define _syscall3(type,name,atype,a,btype,b,ctype,c) \
type name(atype a,btype b,ctype c) \
{ \
	return INLINE_SYSCALL(type, name, 3, a, b, c);\
}


#define _syscall4(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4) \
type name (type1 arg1, type2 arg2, type3 arg3, type4 arg4) \
{ \
	return INLINE_SYSCALL(type, name, 4, arg1, arg2,arg3,arg4);\
} 

#define _syscall5(type,name,type1,arg1,type2,arg2,type3,arg3,type4,arg4,type5,arg5) \
type name (type1 arg1,type2 arg2,type3 arg3,type4 arg4,type5 arg5) \
{ \
	return INLINE_SYSCALL(type, name, 5, arg1, arg2,arg3,arg4,arg5);\
}
#endif


#endif
