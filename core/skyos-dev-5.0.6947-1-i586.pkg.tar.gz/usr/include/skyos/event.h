#ifndef _INC_SKYOS_EVENTS_H_
#define _INC_SKYOS_EVENTS_H_

/*
  SkyOS

  Copyright 1996 - 2004 SkyOS Team. All rights reserved.  
  You may not modify or redistribute this file, or any part of this file, in any way, shape, or form.
*/
/*
#define EVENT_TYPE_NOTE      0x00000000
#define EVENT_TYPE_PANIC	 0x00010000
#define EVENT_TYPE_SECURITY  0x00020000
#define EVENT_TYPE_ERROR     0x00040000
#define EVENT_TYPE_WARNING   0x00080000
#define EVENT_TYPE_REPORT    0x00100000
*/

#define EVENT_TYPE_LOG		 0x00000001
#define EVENT_TYPE_MESSAGE   0x00000002

#define EVENT_TYPE_NOTE      0x00010000
#define EVENT_TYPE_ERROR     0x00040000
#define EVENT_TYPE_WARNING   0x00080000
#define EVENT_TYPE_SECURITY  0x00020000

/*
enum
{
	EVENT_ID_ACCESS=1,
	EVENT_ID_HARDWARE,
	EVENT_ID_IMAGE,
	EVENT_ID_FILESYSTEM,
	EVENT_TYPE_IO,
	EVENT_TYPE_APPLICATION_ERROR,
	EVENT_TYPE_MISC,
	EVENT_ID_ISS,
	EVENT_ID_USER,
	EVENT_ID_HARDWARE_CHANGE_ADD,
	EVENT_ID_HARDWARE_CHANGE_ADD_FAIL,
	EVENT_ID_SYSTEM
};
*/

typedef struct sUserEvent
{
	unsigned int uiType;
	char *pUserTitle;
	char *pUserText;
	char *pSource;
} sUserEvent;

typedef struct sEventType_HardwareChanged
{
	unsigned char ucDeviceName[255];
	unsigned char bRemoved;
	unsigned char bReady;
	unsigned char bFailure;
	unsigned char ucFailureReason[512];
} sEventType_HardwareChanged;

typedef struct sEvent
{
	unsigned long long ullEventSender;
	unsigned long long ullEventID;
	unsigned int   uiType;
	unsigned char  ucIcon[255];
	unsigned char  pDescription[255];
	unsigned char  pData[1];
} sEvent;

#ifdef KERNEL

#ifdef __cplusplus
extern "C" {
#endif

int Notification(unsigned int uiType,
				 const void *pPath,
			     const void *pShortDescription,
			     char *fmt, ...);

#ifdef __cplusplus
}
#endif

#endif

#endif


