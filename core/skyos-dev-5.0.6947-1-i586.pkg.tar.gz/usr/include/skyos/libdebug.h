#define DBG_ACTION_START	0
#define DBG_ACTION_PEEK		1
#define DBG_ACTION_GET_REGS 2
#define DBG_ACTION_SINGLESTEP 3
#define DBG_ACTION_POKE     4
#define DBG_ACTION_CONT		5
#define DBG_ACTION_PUT_REGS 6
#define DBG_ACTION_SYSCALL  7
#define DBG_ACTION_DEBUG_ME 8
#define DBG_ACTION_ATTACH   9

#define DBGMSG_BREAK		0x00000001
#define DBGMSG_FAULT        0x00000002
#define DBGMSG_SYSCALL_ENTER     0x00000003
#define DBGMSG_SYSCALL_LEAVE     0x00000004

typedef struct dbg_regs
{
	unsigned int eax	;
	unsigned int ebx	;
	unsigned int ecx	;
	unsigned int edx	;
	unsigned int edi	;
	unsigned int esi	;
	unsigned int ebp	;
	unsigned int esp	;
	unsigned int eip	;
	unsigned int cs	;
	unsigned int ds	;
	unsigned int es	;
	unsigned int fs	;
	unsigned int gs	;
	unsigned int ss	;
	unsigned int eflags	;
} dbg_regs;




