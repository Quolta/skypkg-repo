#ifndef _INC_LIBSKYOS_
#define _INC_LIBSKYOS_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdlib.h>
#include <skyos/types.h>
#include <malloc.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "skyos/tasks.h"
#include "skyos/types.h"
#include "module.h"
#include "errno.h"
#include "sysinfo.h"
#include "getopt.h"
#include "skyos/event.h"
#include "sys/fcntl.h"
#include "sys/time.h"
#include "dir.h"
#include "stdarg.h"
/*
typedef struct 
  {
    int __fill[6];
  } mbstate_t; 
*/

//extern char **environ;	/* argument associated with option */


/*
   Thread
*/
int 	ThreadGetInfo (unsigned int pid, task_info *t);
int 	ThreadGetState (unsigned int pid);
int 	ThreadCheckValid (unsigned int pid);
int 	waittask (unsigned int pid);
int 	ThreadWaitForState (unsigned int pid, unsigned int state);
int 	ThreadSuspend (int iPid);
int 	ThreadResume (int iPid);
int 	ThreadGetPid (void);
int 	ThreadGetProcessID (void);
int 	ThreadIsValid (int iPid);
int 	ThreadSleep (unsigned int uiMilliseconds);
void 	ThreadYield (void);
int 	ThreadCreate (char *ucName, unsigned int uiFlags, void *fpFunction, unsigned int arg1, unsigned int arg2, unsigned int arg3, unsigned int arg4, unsigned int arg5, unsigned int arg6, unsigned int arg7, unsigned int arg8, unsigned int arg9, unsigned int arg10);
int 	ThreadWait (int iPid, int *iStatus);
int		ThreadWaitAllChildren(int iPid);
int     SystemTaskInfo (int pid, unsigned int uiInfo, void *pData, unsigned int uiMaxSize);
int 	ThreadSetPriority (int pid, int iPriority);
int 	ThreadSuggestPriority (unsigned int uiThreadType);
int 	ThreadGetMaxPriority (void);
void 	ThreadGetName (char *str);
HRESULT 	ThreadGetApplicationDirectory (char *ucDir);
HRESULT 	ThreadGetApplicationPath (char *ucFile);
int		ThreadGetPids(int* PidArray, int size);

int printd(char *format, ...);
int close(int fd);
int chdir(const char *dir);
int exec(char *name, int argc, char **argv, char **envp);
int ExecuteProcessWithArguments(char *prog, char **argv);
int ExecuteProcessForDebug(char *name, int argc, char **argv);
int fork(void);
int spawn(unsigned int addr, unsigned int stack);
int pspawn(unsigned int addr, unsigned int stack,
		   unsigned int arg1, unsigned int arg2,
		   unsigned int arg3, unsigned int arg4,
		   unsigned int arg5, unsigned int arg6,
		   unsigned int arg7, unsigned int arg8,
		   unsigned int arg9, unsigned int arg10);
int spawnv(int flags, const char *cmd, const char *const* argv);
int spawnvp(int flags, const char *cmd, const char *const* argv);
unsigned int GetDllFunction(sDllHandle *pDllHandle,
				   char *pFunctionName);
int DllLoad(char *pPath, sDllHandle *pHandle);
unsigned int OptionParserGet(char *Text, char *Key);
unsigned int OptionParserGetString(char *Text, char *Key, char *Value);
unsigned int OptionParserGetLong(char *Text, char *Key, unsigned int *Value);
unsigned int SystemDLMLoad(char *name, char *para);
//int SystemDLMmInfo(char *name, module_info_section *info, unsigned int maxsize);


/*
  LibSky
*/
unsigned int get_ticks(void);


/*
  LibSkyGI
*/
int GI_Initialize();


#define UNIMPL { \
	printd("********** UNIMPLEMENTED FUNCTION"); \
	printd("           Function: %s",__FUNCTION__); \
	printd("           File    : %s",__FILE__); \
	printd("           Line    : %d",__LINE__); \
}

#define NOTIMPL { \
	printd("********** UNIMPLEMENTED FUNCTION"); \
	printd("           Function: %s",__FUNCTION__); \
	printd("           File    : %s",__FILE__); \
	printd("           Line    : %d",__LINE__); \
}

#define DEB { \
	printd("********** DEBUG: %s",__FUNCTION__); \
	printd("**********        LINE: %d",__LINE__); \
	printd("**********        FILE: %s",__FILE__); \
}

unsigned long long TimeGetIdleCounter();
unsigned long long TimeGetUsecCounter();
unsigned long long get_usec_counter();
void MemoryDump(unsigned int vpAddr, unsigned int uiBytes);
unsigned int get_curtime(struct t_curtime *t);

int semaphore_aquire(void* hSem);
int semaphore_release(void* hSem);
void* semaphore_create(char *name);
unsigned int SystemGetPartitionInfo(char *dev);
unsigned long long SystemGetPartitionSize(char *dev);
int kill(int pid, int signal);

/*
   Set a fifo to a pipe.

   fd	     ... fd of pipe
   iReader   ... Pid of task which will read from pipe
   iWriter   ... Pid of task which will write to pipe

   After calling this function, as soon as the reader or writer terminates,
   read from the pipe will return -EPIPE.

*/
int SetFifoPipeInfo(int fd, int iReader, int iWriter);

int ExecuteProcess(char *pImage, char **argv, unsigned int uiFlag1, unsigned int uiFlag2, unsigned int uiFlag3, char **envp);

/*
   Execute an application and connect stdio handles with pipes

   pImage    ... File the execute
   argv      ... Pointer to parameters. Don't include filename
   iFdInput  ... If set, pipe to communicate with input of child process
   iFdOutput ... If set, pipe to communicate with output of child process
   iFdError  ... If set, pipe to communicate with error of child process
*/
int ExecuteProcessStdIO(char *pImage, char **argv, unsigned int uiFlag1, unsigned int uiFlag2, unsigned int uiFlag3, char **envp,
					 int *iFdInput, int *iFdOutput, int *iFdError);

unsigned int hex2dec(char *str);
int ListenerRegister(char *ucPath, unsigned int uiEvents, unsigned int hWnd, unsigned int *puiHandle);
int ListenerUnregister(unsigned int uiHandle);
/* int vsnprintf(char *str, size_t size, const char *fmt, va_list ap);*/

unsigned int SystemEvent(unsigned long long ullEventSenderID,
						 unsigned long long ullEventID,
						 unsigned int uiType, 
						 void *pData,
						 char *pTitle,
						 char *pText);

HRESULT SystemEventNotifyMessage(unsigned long long ullEventSenderID,
								 unsigned long long ullEventID,
								 char *pTitle,
								 char *pText);

int FilesystemConstructFullName(char *pRoot, ino_t vnode, char *ucFileName, char *ucFullname);
unsigned int OptionParserGetStringMax(char *Text, char *Key, char *Value, unsigned int uiMax);
unsigned int SystemMapVirtualKey(unsigned int uiVKey, unsigned int uiMapType, unsigned int uiVKeyModifier);
HRESULT FilesystemNormalizePath(char *ucPath);
HRESULT FilesystemConstructPath(char *pPath, char *ucFirst, ...);
HRESULT FilesystemIsExecutable(char *pPath);

HRESULT SystemNotify(unsigned int uiType,
					 char *pTitle,
					 char *fmt, ...);
char *strhr(HRESULT hr);
int InitializeDefaultEnvironment(char *pUser);
void RegistrySerializeEnable( void );


void *LockCreate(char *pName);
int LockLock(void *pLock);
int LockLockInterruptable(void *pLock);
int LockUnLock(void *pLock);
int LockTryLock(void *pLock);

#define DISKDEVICE_FILESYSTEM_CAP_HAS_ATTRIBUTES 

#define FUNCTION_NOT_IMPLEMENTED printd("%s, %s@%d : NOT IMPLEMENTED", __FILE__, __FUNCTION__, __LINE__);
 
#define FILESYSTEM_COPY_ATTRIBUTES		0x00000001
#define FILESYSTEM_COPY_SILENT			0x00000002
#define FILESYSTEM_COPY_OVERWRITE		0x00000004
#define FILESYSTEM_COPY_SKIP_EXISTING	0x00000008

#define	E_FILESYSTEM_COPY_SOURCE_NOT_VALID				1
#define E_FILESYSTEM_COPY_CANNOT_CREATE_DESTINATION		2

typedef HRESULT (*FilesystemCopyProgressCallback)(HANDLE hCopy, 
												  float fProgress,
												  size_t iBytesCopied);

#define DISK_DEVICE_FLAG_TYPE_FLOPPY			0x00000001
#define DISK_DEVICE_FLAG_TYPE_HARDDISK			0x00000002
#define DISK_DEVICE_FLAG_TYPE_CDROM				0x00000004
#define DISK_DEVICE_FLAG_INCLUDE_PARTITIONS     0x00000008

#define DISK_DEVICE_FLAG_TYPE_ALL				(DISK_DEVICE_FLAG_TYPE_FLOPPY | DISK_DEVICE_FLAG_TYPE_HARDDISK | DISK_DEVICE_FLAG_TYPE_CDROM)

#ifdef __cplusplus
}
#endif


#endif



