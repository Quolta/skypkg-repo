#ifndef _INC_DEP_
#define _INC_DEP_

#ifdef __cplusplus
extern "C" {
#endif

#include "libskyos.h"
#include "tasks.h"

int DataExchangePortRegister(char *ucName);
int DataExchangePortRegisterPrivate(char *ucName);
int DataExchangePortConnect(char *ucName);
int DataExchangePortRead(int uiPortID, unsigned int uiTimeOut, void *  pData,
						unsigned int*  uiSize);
int DataExchangePortWrite(int uiPortID, void *  pData,
						unsigned int  uiSize);
HRESULT DataExchangePortRelease(int uiPortID);
int DataExchangePortBlocking(int uiPortID, int bBlocking);
int DataExchangePortDataAvailable(int uiPortID);


#ifdef __cplusplus
}
#endif


#endif
