/*
  Virtual SkyOS KeyCodes
*/
#ifndef   _VKEY_INC_
#define  _VKEY_INC_

#define VKEY_MODIFIER_SHIFT_LEFT		0x00000001
#define VKEY_MODIFIER_SHIFT_RIGHT		0x00000002
#define VKEY_MODIFIER_CTRL_LEFT	  	    0x00000004
#define VKEY_MODIFIER_CTRL_RIGHT		0x00000008
#define VKEY_MODIFIER_ALT_LEFT   		0x00000010
#define VKEY_MODIFIER_ALT_RIGHT 		0x00000020
#define VKEY_MODIFIER_NUMLOCK			0x00000040
#define VKEY_MODIFIER_CAPSLOCK          0x00000080

#define VKEY_MODIFIER_PRESSED			0x80000000

#define VKEY_F1				1
#define VKEY_F2				2
#define VKEY_F3				3
#define VKEY_F4				4
#define VKEY_F5				5
#define VKEY_F6				6
#define VKEY_F7				7
#define VKEY_F8				8
#define VKEY_F9				9
#define VKEY_F10		   10	
#define VKEY_F11		   11	
#define VKEY_F12		   12	
#define VKEY_PRINT			13
#define VKEY_SCROLL			14
#define VKEY_PAUSE			15
#define VKEY_CAP			16
#define VKEY_1				17
#define VKEY_2				18
#define VKEY_3				19
#define VKEY_4				20
#define VKEY_5				21
#define VKEY_6				22
#define VKEY_7				23
#define VKEY_8				24
#define VKEY_9				25
#define VKEY_0				26
#define VKEY_MINUS			27
#define VKEY_EQUAL			28
#define VKEY_BACKSPACE		29
#define VKEY_INSERT			30
#define VKEY_HOME			31
#define VKEY_PAGEUP			32
#define VKEY_NUMLOCK		33
#define VKEY_KEYPAD_DIVIDE  34
#define VKEY_KEYPAD_MULT    35
#define VKEY_KEYPAD_MINUS  36
#define VKEY_TAB			37
#define VKEY_Q				38
#define VKEY_W				39
#define VKEY_E				40
#define VKEY_R				41
#define VKEY_T				42
#define VKEY_Y				43
#define VKEY_U				44
#define VKEY_I				45
#define VKEY_O				46
#define VKEY_P				47
#define VKEY_UNKNOWN_1		48	
#define VKEY_UNKNOWN_2		49			
#define VKEY_ENTER			50	
#define VKEY_DEL			51
#define VKEY_END			52
#define VKEY_PAGEDOWN		53
#define VKEY_KEYPAD_7		54
#define VKEY_KEYPAD_8		55
#define VKEY_KEYPAD_9		56
#define VKEY_KEYPAD_PLUS	57
#define VKEY_CAPSLOCK		58
#define VKEY_A				59
#define VKEY_S				60
#define VKEY_D				61
#define VKEY_F				62
#define VKEY_G				63
#define VKEY_H				64
#define VKEY_J				65
#define VKEY_K				66
#define VKEY_L				67
#define VKEY_SEMICOLON		68
#define VKEY_DOT			69
#define VKEY_KEYPAD_4		70
#define VKEY_KEYPAD_5		71
#define VKEY_KEYPAD_6		72
#define VKEY_SHIFT_LEFT		73
#define VKEY_BACKSLASH		74
#define VKEY_Z				75
#define VKEY_X				76
#define VKEY_C				77
#define VKEY_V				78
#define VKEY_B				79
#define VKEY_N				80
#define VKEY_M				81
#define VKEY_UNKNOWN_4		82
#define VKEY_UNKNOWN_5		83
#define VKEY_SLASH			84
#define VKEY_SHIFT_RIGHT	85	
#define VKEY_KEYPAD_1		86
#define VKEY_KEYPAD_2		87
#define VKEY_KEYPAD_3		88
#define VKEY_KEYPAD_ENTER	89
#define VKEY_CTRL_LEFT		90
#define VKEY_WIN_LEFT		91
#define VKEY_ALT_LEFT		92
#define VKEY_SPACE			93
#define VKEY_ALT_RIGHT		94	
#define VKEY_WIN_RIGHT		95	
#define VKEY_APPS			96	
#define VKEY_CTRL_RIGHT		97	
#define VKEY_CURUP			98	
#define VKEY_CURDOWN		99	
#define VKEY_CURLEFT		100	
#define VKEY_CURRIGHT		101
#define VKEY_KEYPAD_0		102	
#define VKEY_KEYPAD_SEPARATOR 103	
#define VKEY_UNKNOWN_6       104

#define VKEY_SS				 105
#define VKEY_HASH			 106
#define VKEY_GREATER		 107
#define VKEY_PLUS			 108
#define VKEY_ESCAPE			 109
#define VKEY_MENU			 110
#define VKEY_INVALID        255

typedef struct sVKeyToName
{
	unsigned int uiVKey;
	char *ucVKeyName;
} sVKeyToName;

typedef struct sDeadKey
{
	unsigned int uiDeadUnicode;
	unsigned int uiNextUnicode;
	unsigned int uiNewUnicode;
} sDeadKey;

void KeyReport(unsigned int uiVkey, char bReleased);

#define KEYMAP_ENTRIES 10

#define VK_MAP_TYPE_GET_ASCII	0x00000001
#define VK_MAP_TYPE_GET_VKEY	0x00000002
#define VK_MAP_TYPE_MOD_SHIFT	0x00000010
#define VK_MAP_TYPE_MOD_CTRL	0x00000020
#define VK_MAP_TYPE_MOD_ALT  	0x00000040

#define VK_MAP_FLAG_CAPS_LOCK_AFFECTED	0x00000001

#endif



