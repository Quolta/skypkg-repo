#ifndef _INC_QUERY_
#define _INC_QUERY_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct sGetParentNode
{
	char *pMountEntry;
	unsigned long long vThis;
	unsigned long long vParent;
	char ucParentFileName[255];
} sGetParentNode;

typedef struct sQueryItem
{
   unsigned long long d_ino; 
   unsigned long long d_pino;
   dev_t			  d_dev;
   char d_name[256];
   unsigned int  size;
   unsigned int  type;

   time_t        access;
   time_t        modify;
   time_t        create;
} sQueryItem;


typedef struct sQueryCookie
{
	int id;
} sQueryCookie;

typedef struct sIndexCookie
{
	unsigned int id;
} sIndexCookie;

typedef struct sQueryOpenData
{
	char *pMountEntry;
	char *pQueryString;
	unsigned int uiFlags;
	unsigned int uiHandle;
	unsigned char ucInterface[255];
	void *pToken;
} sQueryOpenData;

int QueryOpen(char *pMountEntry,
			  const char *pQueryString,
			  unsigned int uiFlags,
			  sQueryCookie **ppCookie);
int QueryRead(sQueryCookie *pCookie, sQueryItem *dp);
int QueryClose(sQueryCookie *pCookie);

#define QUERY_FLAG_LIVE			0x00000001
#define QUERY_FLAG_NON_INDEXED	0x00000002
#define QUERY_FLAG_UPDATE     	0x00000004


#ifdef __cplusplus
}
#endif


#endif


