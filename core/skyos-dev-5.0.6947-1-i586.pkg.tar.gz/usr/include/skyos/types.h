#ifndef __SKYOS_TYPES_H_
#define __SKYOS_TYPES_H_

#define DEFINE_GUID(x) unsigned char x[16];
#define SET_GUID(x,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11,b12,b13,b14,b15,b16) \
	((char*)x)[0] = b1; ((char*)x)[1] = b2; ((char*)x)[2] = b3; ((char*)x)[3] = b4; ((char*)x)[4] = b5; ((char*)x)[5] = b6; \
	((char*)x)[6] = b7; ((char*)x)[7] = b8; ((char*)x)[8] = b9; ((char*)x)[9] = b10; ((char*)x)[10] = b11; ((char*)x)[11] = b12; \
	((char*)x)[12] = b13; ((char*)x)[13] = b14; ((char*)x)[14] = b15; ((char*)x)[15] = b16;

#define GET_GUID(x, str) \
	sprintf(str, "%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X", \
	x[0], x[1], x[2],x[3],x[4],x[5],x[6],x[7],x[8],x[9],x[10],x[11],x[12],x[13],x[14],x[15]);

#define TYPE_GUID void *

#include "sys/types.h"
/*
  Values are 32 bit values layed out as follows:

   3 3 2 2 2 2 2 2 2 2 2 2 1 1 1 1 1 1 1 1 1 1
   1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0
  +---+-+-+-----------------------+-------------------------------+
  |Sev|C|R|     Facility          |               Code            |
  +---+-+-+-----------------------+-------------------------------+

  where

      Sev - is the severity code

          00 - Success
          01 - Informational
          10 - Warning
          11 - Error

      C - is the Customer code flag

      R - is a reserved bit

      Facility - is the facility code

      Code - is the facility's status code


 Define the facility codes
*/

typedef long HRESULT;

#ifdef __cplusplus
extern "C" {
#endif

HRESULT TraceHResult(HRESULT hr, char *Info);


#define DEBUG_RETURN_HR(hr,Text)   return( TraceHResult(hr, Text ) )

#define returnhr(hr)     DEBUG_RETURN_HR(hr,##__FUNCTION__) 

#ifdef __cplusplus
}
#endif

#ifndef SUCCEEDED
#define SUCCEEDED(hr) ( (long)(hr) >=0 )			/* Macro to check if result is an error */
#endif

#ifndef FAILED
#define FAILED(hr) ( (long)(hr) < 0)								/* */
#endif


#define _HRESULT_TYPEDEF_(_sc) ((HRESULT)_sc)


/*
  81000000 - 81000100	Serial (dd_com.h)
  81000100 - 81000200	LibNet
  81000200 - 81000300   LibUser
*/





/*
 Success codes
*/
#ifndef S_OK
#define S_OK                                   _HRESULT_TYPEDEF_(0x00000000L)    /* No error */
#endif

#ifndef S_FALSE
#define S_FALSE                                _HRESULT_TYPEDEF_(0x00000001L)	 /* No error but call failed */
#endif

#define E_UNEXPECTED                     _HRESULT_TYPEDEF_(0x8000FFFFL)
#define E_UNEXPECTED_DEBUG_TXT			 "E_UNEXPECTED"					/* Text for TRACE Message */

#define E_NOTIMPL                        _HRESULT_TYPEDEF_(0x80004001L)
#define E_NOTIMPL_DEBUG_TXT				 "E_NOTIMPL"				/* Text for TRACE Message */	

#define E_ACCESSDENIED                   _HRESULT_TYPEDEF_(0x80070005L)
#define E_HANDLE                         _HRESULT_TYPEDEF_(0x80070006L)
#define E_OUTOFMEMORY                    _HRESULT_TYPEDEF_(0x8007000EL)
#define E_INVALIDARG                     _HRESULT_TYPEDEF_(0x80070057L)
#define E_FAULT		                    _HRESULT_TYPEDEF_(0x80070058L)
#define E_NODEVICE		                    _HRESULT_TYPEDEF_(0x80070059L)

#define E_NOINTERFACE                    _HRESULT_TYPEDEF_(0x80004002L)
#define E_NOINTERFACE_DEBUG_TXT			 "E_NOINTERFACE"

#define E_POINTER                        _HRESULT_TYPEDEF_(0x80004003L)



#define E_ABORT                          _HRESULT_TYPEDEF_(0x80004004L)

#define E_FAIL                           _HRESULT_TYPEDEF_(0x80004005L)
#define E_FAIL_DEBUG_TXT				 "E_FAIL"

#define E_PIPE                           _HRESULT_TYPEDEF_(0x80004006L)

#define E_AGAIN							 _HRESULT_TYPEDEF_(0x80004007L)

#define E_NOTVALID                       _HRESULT_TYPEDEF_(0x80004008L)

/*
  Disk and filesystem
*/
#define E_DISK_SPACE                     _HRESULT_TYPEDEF_(0x80080000L)
#define E_DISK_READ_ERROR                _HRESULT_TYPEDEF_(0x80080001L)
#define E_DISK_WRITE_ERROR               _HRESULT_TYPEDEF_(0x80080002L)
#define E_IO_ERROR						 _HRESULT_TYPEDEF_(0x80080004L)

#define E_FILE_NOT_FOUND                 _HRESULT_TYPEDEF_(0x80090000L)
#define E_FILE_TOO_MANY_OPEN_FILES       _HRESULT_TYPEDEF_(0x80090001L)
#define E_FILE_NO_DIRECTORY				 _HRESULT_TYPEDEF_(0x80090002L)
#define E_FILE_IS_DIRECTORY				 _HRESULT_TYPEDEF_(0x80090003L)
#define E_FILE_EOF         				 _HRESULT_TYPEDEF_(0x80090004L)

#define E_WOULD_BLOCK					 _HRESULT_TYPEDEF_(0x80090005L)
#define E_FILE_IS_PIPE					 _HRESULT_TYPEDEF_(0x80090006L)
#define E_PIPE_ERROR					 _HRESULT_TYPEDEF_(0x80090007L)
#define E_TIMEOUT						 _HRESULT_TYPEDEF_(0x80090008L)
#define E_FILE_EXISTS					 _HRESULT_TYPEDEF_(0x80090009L)


/*
  Network
*/
#define E_NETIF_OPEN					 _HRESULT_TYPEDEF_(0x80080000L)
#define E_NETIF_CLOSE					 _HRESULT_TYPEDEF_(0x80080000L)
#define E_LIBNET_DEVICE_UNKNOWN			 _HRESULT_TYPEDEF_(0x80000100L)
#define E_LIBNET_DHCP_FAILED			 _HRESULT_TYPEDEF_(0x80000101L)
#define E_LIBNET_PPP_OPEN_SERIAL		 _HRESULT_TYPEDEF_(0x80000110L)
#define E_NETIF_BUFFER					 _HRESULT_TYPEDEF_(0x80080002L)
#define E_NO_ROUTE						 _HRESULT_TYPEDEF_(0x80080003L)

#define E_BUSY							_HRESULT_TYPEDEF_(0x80060001L)
	
#define E_INTERRUPTED					_HRESULT_TYPEDEF_(0x80087601L)
	
#define E_ISS_BUSY						_HRESULT_TYPEDEF_(0x80020000L)
#define E_ISS_UNKNOWN_FILE_FORMAT		_HRESULT_TYPEDEF_(0x80020001L)
#define E_ISS_NOT_SUPPORTED				_HRESULT_TYPEDEF_(0x80020002L)
#define E_ISS_END_OF_FILE				_HRESULT_TYPEDEF_(0x80020003L)

/*
** Description: Macro for defining a HRESULT parameter.
**
** Arguments:
**     sev - Severity code. 
**     fac -  The facility code. 
**     code - The facility's status code. 
*/
#define MAKE_HRESULT(sev,fac,code) \
    ((HRESULT) (((unsigned long)(sev)<<31) | ((unsigned long)(fac)<<16) | ((unsigned long)(code))) )  /* Macro for defining an HRESULT value */


/*
** Description: Macro for defining a HRESULT parameter.
**
** Arguments:
**     sev - Severity code. 
**     fac -  The facility code. 
**     code - The facility's status code. 
*/
#define MAKE_SCODE(sev,fac,code) \
    ((SCODE) (((unsigned long)(sev)<<31) | ((unsigned long)(fac)<<16) | ((unsigned long)(code))) )


#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef _COMPILE_QT_
typedef void* HANDLE;
#endif

#endif


