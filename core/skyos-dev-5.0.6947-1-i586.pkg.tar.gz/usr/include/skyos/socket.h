#ifndef _SOCKET_H_SKYOS_
#define _SOCKET_H_SKYOS_

#ifdef __cplusplus
extern "C" {
#endif

typedef unsigned short sa_family_t; 

#include "sys/ioctl.h"
#include "netinet/in.h"
#include "sys/types.h"
/*
  Sky Operating System 
  Copyright (c) 1996 - 2002 by Szeleney Robert
*/

/*!
  Socket library for SkyOS. 
  This file implement syscall wrappers to use sockets for network communication.
*/
/* Protocol families.  */
#define	PF_UNSPEC	0	/* Unspecified.  */
#define	PF_LOCAL	1	/* Local to host (pipes and file-domain).  */
#define	PF_UNIX		PF_LOCAL	/* Old BSD name for PF_LOCAL.  */
#define	PF_FILE		PF_LOCAL	/* Another non-standard name for PF_LOCAL.  */
#define	PF_INET		2	/* IP protocol family.  */
#define	PF_AX25		3	/* Amateur Radio AX.25.  */
#define	PF_IPX		4	/* Novell Internet Protocol.  */
#define	PF_APPLETALK	5	/* Appletalk DDP.  */
#define	PF_NETROM	6	/* Amateur radio NetROM.  */
#define	PF_BRIDGE	7	/* Multiprotocol bridge.  */
#define	PF_ATMPVC	8	/* ATM PVCs.  */
#define	PF_X25		9	/* Reserved for X.25 project.  */
#define	PF_INET6	10	/* IP version 6.  */
#define	PF_ROSE		11	/* Amateur Radio X.25 PLP.  */
#define	PF_DECnet	12	/* Reserved for DECnet project.  */
#define	PF_NETBEUI	13	/* Reserved for 802.2LLC project.  */
#define	PF_SECURITY	14	/* Security callback pseudo AF.  */
#define	PF_KEY		15	/* PF_KEY key management API.  */
#define	PF_NETLINK	16
#define	PF_ROUTE	PF_NETLINK	/* Alias to emulate 4.4BSD.  */
#define	PF_PACKET	17	/* Packet family.  */
#define	PF_ASH		18	/* Ash.  */
#define	PF_ECONET	19	/* Acorn Econet.  */
#define	PF_ATMSVC	20	/* ATM SVCs.  */
#define	PF_SNA		22	/* Linux SNA Project */
#define PF_IRDA		23	/* IRDA sockets.  */
#define	PF_MAX		32	/* For now..  */
#define PF_LINK		33


/* Address families.  */
#define	AF_UNSPEC	PF_UNSPEC
#define	AF_LOCAL	PF_LOCAL
#define	AF_UNIX		PF_UNIX
#define	AF_FILE		PF_FILE
#define	AF_INET		PF_INET
#define	AF_AX25		PF_AX25
#define	AF_IPX		PF_IPX
#define	AF_APPLETALK	PF_APPLETALK
#define	AF_NETROM	PF_NETROM
#define	AF_BRIDGE	PF_BRIDGE
#define	AF_ATMPVC	PF_ATMPVC
#define	AF_X25		PF_X25
#define	AF_INET6	PF_INET6
#define	AF_ROSE		PF_ROSE
#define	AF_DECnet	PF_DECnet
#define	AF_NETBEUI	PF_NETBEUI
#define	AF_SECURITY	PF_SECURITY
#define	AF_KEY		PF_KEY
#define	AF_NETLINK	PF_NETLINK
#define	AF_ROUTE	PF_ROUTE
#define	AF_PACKET	PF_PACKET
#define	AF_ASH		PF_ASH
#define	AF_ECONET	PF_ECONET
#define	AF_ATMSVC	PF_ATMSVC
#define	AF_SNA		PF_SNA
#define AF_IRDA		PF_IRDA
#define	AF_MAX		PF_MAX
#define AF_LINK		PF_LINK
 

#define SOCK_STREAM 1
#define SOCK_DGRAM  2
#define	SOCK_RAW	3
#define SOCK_RDM	4		/* reliably-delivered message	*/
#define SOCK_SEQPACKET	5	/* sequential packet socket	*/

#define SOMAXCONN       0x7fffffff 

/* Generic socket address structure */
struct sockaddr 
{
	short sa_family;
	char sa_data[14];
};



/* This is a structure for "historical" reasons (whatever they are) */
struct in_addr 
{
	unsigned long s_addr;
};

struct ip_mreq
{
   struct in_addr imr_multiaddr;	/* IP multicast address of group */
   struct in_addr imr_interface;	/* local IP address of interface */
};

/* Socket address, DARPA Internet style */
struct sockaddr_in 
{
	short sin_family;
	unsigned short sin_port;
	struct in_addr sin_addr;
	char sin_zero[8];
};

/*
   sockaddr_un defined in sys/un.h
*/

struct s_sockaddr_in
{
  unsigned int sa_family;
  unsigned int sa_port;
  unsigned int sa_addr;
};

/*
   Sync this structure with ksock.h
*/
struct socket_syscall
{
	char *buf;
	int len;
	int flags;
	struct sockaddr daddr;
	int totlen;
};


/* User visible structure for SCM_CREDENTIALS message */

struct ucred
{
  int pid;			/* PID of sending process.  */
  unsigned short uid;			/* UID of sending process.  */
  unsigned short gid;			/* GID of sending process.  */
}; 


/* Needed for if queries */

#if 0

#define SOL_SOCKET      0xffff          /* options for socket level */
#define SO_DEBUG        0x0001          /* turn on debugging info recording */
#define SO_ACCEPTCONN   0x0002          /* socket has had listen() */
#define SO_REUSEADDR    0x0004          /* allow local address reuse */
#define SO_KEEPALIVE    0x0008          /* keep connections alive */
#define SO_DONTROUTE    0x0010          /* just use interface addresses */
#define SO_BROADCAST    0x0020          /* permit sending of broadcast msgs */
#define SO_USELOOPBACK  0x0040          /* bypass hardware when possible */
#define SO_LINGER       0x0080          /* linger on close if data present */
#define SO_OOBINLINE    0x0100          /* leave received OOB data in line */
#define SO_DONTLINGER   (u_int)(~SO_LINGER)

/*
 * Additional options.
 */
#define SO_SNDBUF       0x1001          /* send buffer size */
#define SO_RCVBUF       0x1002          /* receive buffer size */
#define SO_SNDLOWAT     0x1003          /* send low-water mark */
#define SO_RCVLOWAT     0x1004          /* receive low-water mark */
#define SO_SNDTIMEO     0x1005          /* send timeout */
#define SO_RCVTIMEO     0x1006          /* receive timeout */
#define SO_ERROR        0x1007          /* get error status and clear */
#define SO_TYPE         0x1008          /* get socket type */
 
#endif

#define IP_OPTIONS          1
#define IP_MULTICAST_IF     2
#define IP_MULTICAST_TTL    3
#define IP_MULTICAST_LOOP   4
#define IP_ADD_MEMBERSHIP   5
#define IP_DROP_MEMBERSHIP  6
#define IP_TTL              7
#define IP_TOS              8
#define IP_DONTFRAGMENT     9 
#define IP_PORTRANGE		19   /* int; range to choose for unspec port */

#define	IP_PORTRANGE_DEFAULT	0	/* default range */
#define	IP_PORTRANGE_HIGH	1	/* "high" - request firewall bypass */
#define	IP_PORTRANGE_LOW	2	/* "low" - vouchsafe security */


/* SUS symbolic values for the second parm to shutdown(2) */
#define SHUT_RD   0		/* == Win32 SD_RECEIVE */
#define SHUT_WR   1		/* == Win32 SD_SEND    */
#define SHUT_RDWR 2		/* == Win32 SD_BOTH    */
 

#define	_SS_MAXSIZE	128U
#define	_SS_ALIGNSIZE	(sizeof(unsigned long long))
#define	_SS_PAD1SIZE	(_SS_ALIGNSIZE - sizeof(unsigned char) - sizeof(sa_family_t))
#define	_SS_PAD2SIZE	(_SS_MAXSIZE - sizeof(unsigned char) - sizeof(sa_family_t) - \
				_SS_PAD1SIZE - _SS_ALIGNSIZE) 

/* TCP options - this way around because someone left a set in the c library includes */
#ifndef TCP_NODELAY
#define TCP_NODELAY     0x0001
#define TCP_MAXSEG	2
#endif 


struct sockaddr_storage {
	unsigned char		ss_len;		/* address length */
	sa_family_t	ss_family;	/* address family */
	__extension__ char		__ss_pad1[_SS_PAD1SIZE];
	__extension__ unsigned long long __ss_align;	/* force desired structure storage alignment */
	__extension__ char		__ss_pad2[_SS_PAD2SIZE];
}; 

#define INADDR_ANY  0x00000000
#define INADDR_NONE 0xFFFFFFFF
#define ADDR_ANY INADDR_ANY


int socket(unsigned int family, unsigned int type, unsigned int protocol);
int bind(int sock, struct sockaddr *name, unsigned int namelen);
int connect(int sock, struct sockaddr *addr, unsigned int len);
int sendto(int sock, char *buf, int len, int flags, struct sockaddr *to, int tolen);
int recvfrom(int sock, char *buf, int len, int flags, struct sockaddr *from, int *fromlen);
#ifndef KERNEL
char* in_ntoa(unsigned long in);
unsigned long in_aton(const char *str);
#endif
#ifndef KERNEL
ssize_t recv(int socket, void *buffer, size_t length, int flags);
ssize_t send(int socket, const void *buffer, size_t length, int flags);
#endif
/* int send(int sock, unsigned char *buf, unsigned int len, unsigned int flags);
   int recv(int sock, unsigned char *buf, unsigned int len, unsigned int flags); */
int listen(int sock, int backlog);
int accept(int sock, struct sockaddr *client,  int *len);
int shutdown (int, int); 

#ifndef __socklen_t_defined
typedef unsigned int socklen_t;
#define __socklen_t_defined 1
#endif

int getsockopt(int s, int level, int optname, void *optval, socklen_t *optlen);
int setsockopt(int s, int level, int optname, const void *optval, socklen_t optlen);
int getpeername(int socket, struct sockaddr *address,
                socklen_t *address_len);
int getsockname(int socket, struct sockaddr *address,
                socklen_t *address_len);

/* Flags we can use with send/ and recv. */
#define MSG_OOB         0x1             /* process out-of-band data */
#define MSG_PEEK        0x2             /* peek at incoming message */
#define MSG_DONTROUTE   0x4             /* send without using routing tables */
#define MSG_WAITALL		0x8				/* Wait for full request or error.  */ 
#define MSG_NOSIGNAL    0x4000

struct linger {
    int l_onoff;		/* Linger active                */
    int l_linger;		/* How long to linger for       */
}; 

/*
 *	As we do 4.4BSD message passing we use a 4.4BSD message passing
 *	system, not 4.3. Thus msg_accrights(len) are now missing. They
 *	belong in an obscure libc emulation or the bin.
 */
struct msghdr {
    void *msg_name;		/* Socket name                  */
    int msg_namelen;		/* Length of name               */
    struct iovec *msg_iov;	/* Data blocks                  */
    int msg_iovlen;		/* Number of blocks             */
    void *msg_control;		/* Per protocol magic (eg BSD file descriptor passing) */
    int msg_controllen;	/* Length of cmsg list */
    unsigned msg_flags;
};

/* Structure used for storage of ancillary data object information.  */
struct cmsghdr
  {
    int  cmsg_len;		/* Length of data in cmsg_data plus length  of cmsghdr structure.  */
    int cmsg_level;		    /* Originating protocol.  */
    int cmsg_type;		    /* Protocol specific type.  */
#if (!defined __STRICT_ANSI__ && __GNUC__ >= 2) || __STDC_VERSION__ >= 199901L
    __extension__ unsigned char __cmsg_data[0] ; /* Ancillary data.  */
#endif
  };

/* Ancillary data object manipulation macros.  */
#if (!defined __STRICT_ANSI__ && __GNUC__ >= 2) || __STDC_VERSION__ >= 199901L
# define CMSG_DATA(cmsg) ((cmsg)->__cmsg_data)
#else
# define CMSG_DATA(cmsg) ((unsigned char *) ((struct cmsghdr *) (cmsg) + 1))
#endif
#define CMSG_NXTHDR(mhdr, cmsg) __cmsg_nxthdr (mhdr, cmsg)
#define CMSG_FIRSTHDR(mhdr) \
  ((int) (mhdr)->msg_controllen >= sizeof (struct cmsghdr)		      \
   ? (struct cmsghdr *) (mhdr)->msg_control : (struct cmsghdr *) NULL)
#define CMSG_ALIGN(len) (((len) + sizeof (int) - 1) \
			 & (int) ~(sizeof (int) - 1))
#define CMSG_SPACE(len) (CMSG_ALIGN (len) \
			 + CMSG_ALIGN (sizeof (struct cmsghdr)))
#define CMSG_LEN(len)   (CMSG_ALIGN (sizeof (struct cmsghdr)) + (len))

extern struct cmsghdr *__cmsg_nxthdr (struct msghdr *__mhdr,
				      struct cmsghdr *__cmsg) ;


extern __inline struct cmsghdr *
__cmsg_nxthdr (struct msghdr *__mhdr, struct cmsghdr *__cmsg) 
{
  if ((int) __cmsg->cmsg_len < (int)sizeof (struct cmsghdr))
    return 0;

  __cmsg = (struct cmsghdr *) ((unsigned char *) __cmsg
			       + CMSG_ALIGN (__cmsg->cmsg_len));
  if ((unsigned char *) (__cmsg + 1) > ((unsigned char *) __mhdr->msg_control
					+ __mhdr->msg_controllen)
      || ((unsigned char *) __cmsg + CMSG_ALIGN (__cmsg->cmsg_len)
	  > ((unsigned char *) __mhdr->msg_control + __mhdr->msg_controllen)))
    return 0;
  return __cmsg;
}

enum
{
    SCM_RIGHTS = 0x01,		/* Transfer file descriptors.  */
#define SCM_RIGHTS SCM_RIGHTS
    __SCM_CONNECT = 0x03	/* Data array is `struct scm_connect'.  */
};

int sendmsg(int s, const struct msghdr *msg, int flags);
int recvmsg(int s, struct msghdr *msg, int flags);
int socketpair(int af, int type,  int protocol, int fd[2]);
char *getdomainname( char *name, int length );

#ifdef __cplusplus
}
#endif

#endif


