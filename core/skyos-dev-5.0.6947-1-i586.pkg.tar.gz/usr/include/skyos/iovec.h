#ifndef _INC_SKYOS_IOVEC_H_
#define _INC_SKYOS_IOVEC_H_

typedef struct iovec
{
	void * iov_base;
	size_t iov_len;
} iovec;

#endif



