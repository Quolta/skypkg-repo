#ifndef   __MODULE_H__
#define   __MODULE_H__

struct s_symbol
{
	void *addr		;
	char name[50]   ;
} __attribute__((packed));


typedef struct sDllHandle
{
	unsigned int uiImageBase;
    void *pImage;	
} sDllHandle;

struct s_module_info
{
	unsigned int  count			 ;		
	unsigned int  alloc_order	 ;

	void *data					 ;

	unsigned int state			;		
	unsigned int addr			;		
	unsigned int size			;		
	unsigned int load_time	    ;		

	unsigned int userspace		;		
	unsigned int bLinkable	    ;
	unsigned int entry			;		
	unsigned char name[255]		;		
	unsigned char para[255]		;		

	void *node					;
  
	unsigned int start			;
	unsigned int end			;
	unsigned int uiOrgImageBase ;

	void *pImageInstance		;
} __attribute__((packed));

#define EXEC_MAX_LENGTH 4095

struct s_exec_info
{
	unsigned char name[EXEC_MAX_LENGTH + 1]	;
	unsigned int  argc			;
	char		  **argv		;
	char		  **envp		;
	unsigned char ucLibraryPath[4096];
	unsigned char ucRealExec[EXEC_MAX_LENGTH + 1]	;
} __attribute__((packed));


#define MODULE_ERROR_ALREADY_REGISTERED		2
#define MODULE_ERROR_UNKNOWN				1

#endif

#if 0

#ifdef __WINESRC__
#include "c:/skyos/apps/wine/include/module.h"
#else





#define MODULE_SECTION_SD		".mod_sd"
#define MODULE_SECTION_VER		".mod_ver"
#define MODULE_SECTION_LD		".mod_ld"
#define MODULE_SECTION_AUTHOR	".mod_aut"
#define MODULE_SECTION_DATE		".mod_dat"
#define MODULE_SECTION_DEPEND	".mod_dep"

#define MODULE_SHORT_DESCRIPTION(DATA) \
   unsigned char pModule_Description[255]  __attribute__((section (MODULE_SECTION_SD))) = DATA ;

#define MODULE_VERSION(DATA) \
   unsigned char pModule_Version[255] __attribute__((section (MODULE_SECTION_VER))) = DATA;

#define MODULE_LONG_DESCRIPTION(DATA) \
   unsigned char pModule_LongDescription[1024]   __attribute__((section (MODULE_SECTION_LD))) = DATA;

#define MODULE_AUTHOR(DATA) \
   unsigned char pModule_Author[255]   __attribute__((section (MODULE_SECTION_AUTHOR))) = DATA;

#define MODULE_DATE(DATA) \
   unsigned char pModule_Date[255]   __attribute__((section (MODULE_SECTION_DATE))) = DATA;

#define MODULE_DEPEND(DATA) \
   unsigned char pModule_Depend[255]   __attribute__((section (MODULE_SECTION_DEPEND))) = DATA;

typedef struct module_info_section
{
	unsigned char ucShortDescription[255];
    unsigned char ucVersion[255];
	unsigned char ucLongDescription[1024];
    unsigned char ucAuthor[255];
    unsigned char ucDate[255];
	unsigned char ucDepend[255];
} module_info_section;





unsigned int SystemDLMLoad(char *name, char *para);

#endif

#endif



