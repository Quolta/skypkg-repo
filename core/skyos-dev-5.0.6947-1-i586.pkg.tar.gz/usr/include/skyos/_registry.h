#ifndef _INC_LIBREGISTRY_
#define _INC_LIBREGISTRY_

#ifdef __cplusplus
extern "C" {
#endif

int RegistryGetOrSetDefaultValue(char *path, unsigned int def, void *vpData);
int RegistryGetOrSetDefaultText(char *path, char *def, char *data, unsigned int maxsize);
int RegistrySetKey(char *path, unsigned int type, unsigned int size, void *vpData);


#ifdef __cplusplus
}
#endif

#endif


