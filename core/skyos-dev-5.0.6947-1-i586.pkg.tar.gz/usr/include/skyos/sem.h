#ifndef _SEM_H_
#define _SEM_H_

#ifdef __cplusplus
extern "C" {
#endif

/*!
	\ingroup semaphore

	Unlocking a semaphore when the thread didn't make a successful lock on it will return in 
	a failure with either EPERM or EINVAL.
	EPERM is returned when another thread holds the lock, EINVAL when no thread holds the lock
	\sa	semaphore_create , semaphore_create_flags

*/
#define LOCK_FLAG_ONLY_OWNER_CAN_RELEASE 0x00000001

/*!
	\ingroup semaphore

	If set recursive locks will succeed.
	\sa	semaphore_create , semaphore_create_flags
*/
#define LOCK_FLAG_RECURSIVE				 0x00000002

/*!
	\ingroup semaphore

    If set and LOCK_FLAG_RECURSIVE is not set, lock will fail with EDEADLK
	\sa	semaphore_create , semaphore_create_flags
*/
#define LOCK_FLAG_RECURSIVE_FAILS		 0x00000004

/*!
	\ingroup semaphore

	If set the sempahore will be public, meaning that it can be used to synchronize processes and not
	threads only.
	Every process which wants to use this public semaphore must call sempahore_create_public to get
	the handle to this semaphore.
	\sa	semaphore_create , semaphore_create_flags
*/
#define LOCK_FLAG_PUBLIC				 0x00000008


/*!
	\ingroup semaphore

	If not set, a release on a not locked semaphore will fail with -EPERM. \n
	\n
	If set, the internal semaphore value will just be adjusted by the release value and the function will
	return success.\n
	A task remove will not undo the semaphore operation, because there is no real "semaphore owner". \n
	Be like semaphore.
	\sa	semaphore_create , semaphore_create_flags
*/
#define LOCK_FLAG_RELEASE_COUNTING       0x00000010

/*!
	\ingroup semaphore

	empty
*/
#define LOCK_ACQUIRE_FLAG_INTERRUPTABLE   0x00000001

/*!
	\ingroup semaphore

	empty
*/
#define LOCK_ACQUIRE_FLAG_TRYLOCK		  0x00000002

/*!
	\ingroup semaphore

	empty
*/
#define LOCK_RELEASE_FLAG_DONT_RESCHEDULE 0x00000001

#define SEM_CREATE  0
#define SEM_AQUIRE  1
#define SEM_RELEASE 2
#define SEM_DESTROY 3
#define SEM_VALUE   4


#ifndef KERNEL

void* semaphore_create(char *name);
void* semaphore_create_anonymous(void);
int semaphore_aquire(void* hSem);
int semaphore_release(void* hSem);

#endif

#ifdef __cplusplus
}
#endif

#endif


