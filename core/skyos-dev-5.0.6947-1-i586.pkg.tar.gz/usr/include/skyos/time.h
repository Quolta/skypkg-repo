unsigned long long cycles_to_usec(unsigned long long cycles);
unsigned long long sl_read_pentium_clock(void);


