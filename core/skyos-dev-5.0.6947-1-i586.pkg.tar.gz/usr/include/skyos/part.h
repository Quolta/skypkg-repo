#ifndef _INC_PART
#define _INC_PART

typedef struct sFSInitialize_SkyFS
{
	unsigned int  uiBlockSize;
	char ucDeviceName[256];
} sFSInitialize_SkyFS;

typedef struct sFSInitialize_BFS
{
	unsigned int  uiBlockSize;
	char ucDeviceName[256];
} sFSInitialize_BFS;

#define PART_ID_SKYFS 0xEC

#define PART_IS_FAT(id) \
	( (id == 0x01) || (id == 0x11) || (id == 0x04) || (id == 0x14) || (id == 0x0B) || \
	  (id == 0x0C) || (id == 0x0E) || (id == 0x1B) || (id == 0x1C) || (id == 0x1E) || \
	  (id == 0x06) || (id == 0x16))

#define PART_IS_EXT2(id) \
	( (id == 0x43) || (id == 0x83) || (id == 0x93))

#define PART_IS_SKYFS(id) \
	( (id == PART_ID_SKYFS) )

#define PART_IS_BEOS(id) \
	( (id == 0xEB) )

#define PART_IS_EXTENDED(id) \
	( (id == 0x05) || (id == 0x0F) || (id == 0x85))

#define PART_IS_NTFS(id) \
	( (id == 0x86) || (id == 0x87) || (id == 0xb7) || (id == 0x07))

#define PART_IS_UNUSED(id) \
	( (id == 0) )

static inline char* PartGetPartitionName(unsigned int uiPartId)
{
	if (PART_IS_FAT(uiPartId))
		return "FAT";
	if (PART_IS_EXT2(uiPartId))
		return "Ext2";
	if (PART_IS_SKYFS(uiPartId))
		return "SkyFS";
	if (PART_IS_BEOS(uiPartId))
		return "BFS";
	if (PART_IS_EXTENDED(uiPartId))
		return "Extended";
	if (PART_IS_NTFS(uiPartId))
		return "NTFS";
	if (uiPartId == 0x82)
		return "Linux Swap";

	return "Unknown";
}
#endif

