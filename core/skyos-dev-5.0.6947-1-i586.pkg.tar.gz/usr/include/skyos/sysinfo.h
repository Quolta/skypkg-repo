#ifndef _SYSINFO_H_
#define _SYSINFO_H_

#ifdef __cplusplus
extern "C" {
#endif


#define PACKED __attribute__((packed))

struct t_curtime
{
	unsigned char hour;
	unsigned char min;
	unsigned char sec;
	
	unsigned char day;
	unsigned char mon;
	unsigned int year;
};

struct cpupara
{
	unsigned char vendor_id[64];
	unsigned char model_id[64];

	unsigned int vendor;
	unsigned int model;

	unsigned int capability;

	unsigned int mhz;
	unsigned int pentium;
};

/*
 * capabilities of CPUs
 */

#define X86_FEATURE_FPU		0x00000001	/* onboard FPU */
#define X86_FEATURE_VME		0x00000002	/* Virtual Mode Extensions */
#define X86_FEATURE_DE		0x00000004	/* Debugging Extensions */
#define X86_FEATURE_PSE		0x00000008	/* Page Size Extensions */
#define X86_FEATURE_TSC		0x00000010	/* Time Stamp Counter */
#define X86_FEATURE_MSR		0x00000020	/* Model-Specific Registers, RDMSR, WRMSR */
#define X86_FEATURE_PAE		0x00000040	/* Physical Address Extensions */
#define X86_FEATURE_MCE		0x00000080	/* Machine Check Exceptions */
#define X86_FEATURE_CX8		0x00000100	/* CMPXCHG8 instruction */
#define X86_FEATURE_APIC	0x00000200	/* onboard APIC */
#define X86_FEATURE_10		0x00000400
#define X86_FEATURE_SEP		0x00000800	/* Fast System Call */ 
#define X86_FEATURE_MTRR	0x00001000	/* Memory Type Range Registers */
#define X86_FEATURE_PGE		0x00002000	/* Page Global Enable */
#define X86_FEATURE_MCA		0x00004000	/* Machine Check Architecture */
#define X86_FEATURE_CMOV	0x00008000	/* CMOV instruction (FCMOVCC and FCOMI too if FPU present) */
#define X86_FEATURE_PAT	0x00010000	/* Page Attribute Table */
#define X86_FEATURE_PSE36	0x00020000	/* 36-bit PSEs */
#define X86_FEATURE_18		0x00040000
#define X86_FEATURE_19		0x00080000
#define X86_FEATURE_20		0x00100000
#define X86_FEATURE_21		0x00200000
#define X86_FEATURE_22		0x00400000
#define X86_FEATURE_MMX		0x00800000	/* multimedia extensions */
#define X86_FEATURE_FXSR	0x01000000	/* FXSAVE and FXRSTOR instructions (fast save and restore of FPU context), and CR4.OSFXSR (OS uses these instructions) available */
#define X86_FEATURE_25		0x02000000
#define X86_FEATURE_26		0x04000000
#define X86_FEATURE_27		0x08000000
#define X86_FEATURE_28		0x10000000
#define X86_FEATURE_29		0x20000000
#define X86_FEATURE_30		0x40000000
#define X86_FEATURE_AMD3D	0x80000000


struct sysinfo
{
	unsigned int system_up_time;		/* Kernel-Up time in seconds */
	
	unsigned int total_mem;				/* Total memory in byte */
	unsigned int free_mem;

	unsigned int memused_kernel;
	unsigned int memused_user;
	
	unsigned int total_process;
	unsigned int total_user_process;
	unsigned int total_kernel_process;

	unsigned int task_switch;          /* number of task switches */
	unsigned int cpu_load;             /* cpu_load in percent */
	unsigned int cpu_speed;			   
    unsigned int cyc_per_msec;		   
	unsigned int syscalls;
	unsigned int interrupts;
	/*
	  Network
	*/
	unsigned int eth_state;
	unsigned int eth_recv;
	unsigned int eth_send;
	unsigned int eth_error;

	unsigned int arp_state;
	unsigned int arp_recv;
	unsigned int arp_send;
	unsigned int arp_error;

	unsigned int ip_state;
	unsigned int ip_recv;
	unsigned int ip_send;
	unsigned int ip_error;

	unsigned int tcp_state;
	unsigned int tcp_recv;
	unsigned int tcp_send;
	unsigned int tcp_error;
 
	unsigned int udp_state;
	unsigned int udp_recv;
	unsigned int udp_send;
	unsigned int udp_error;

	unsigned int icmp_state;
	unsigned int icmp_recv;
	unsigned int icmp_send;
	unsigned int icmp_error;

	unsigned int process_next_pid;
	unsigned int process_processes_active;
	struct cpupara cpu;

	unsigned int uiMemPagesAvailable;
	unsigned int uiMemPagesUseable;
	unsigned int uiMemPagesFree;
};


typedef struct sSystemInfo
{
	unsigned int cyc_per_msec PACKED;
} sSystemInfo;

int sys_info(struct sysinfo *info);

#ifdef __cplusplus
}
#endif



#endif


