#ifndef __INC_STATIS_
#define __INC_STATIS_

typedef struct s_ip_statistics
{
   unsigned int received;
   unsigned int received_errors_in_header;

   unsigned int received_known_proto;
   unsigned int received_unknown_proto;

   unsigned int frag_reasm_ok;
   unsigned int frag_reasm_failed;

   unsigned int transmitted;

   unsigned int frag_created;
} s_ip_statistics;


typedef struct sNetStatistic
{
	unsigned int uiEthernet_Send;
	unsigned int uiEthernet_Receive;
	unsigned int uiEthernet_Error;

	unsigned int uiARP_Send;
	unsigned int uiARP_Receive;
	unsigned int uiARP_Error;

    unsigned int uiUDP_Send;
    unsigned int uiUDP_Recv;
    unsigned int uiUDP_Recv_error;
    unsigned int uiUDP_Recv_no_port;
    unsigned int uiUDP_Send_error;

	unsigned int uiTCP_Send;
    unsigned int uiTCP_Recv;
    unsigned int uiTCP_Recv_error;
    unsigned int uiTCP_Recv_no_port;
    unsigned int uiTCP_Send_error;

	unsigned int uiTCP_Dropped;

	unsigned int uiTCP_ReSend;

	unsigned int uiICMP_Send;
    unsigned int uiICMP_Recv;



	s_ip_statistics  pIP;
} sNetStatistic;

#endif


