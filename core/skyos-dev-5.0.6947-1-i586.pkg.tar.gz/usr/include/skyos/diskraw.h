#ifndef __INC_DISKRAW_H__
#define __INC_DISKRAW_H__

#ifdef __cplusplus
extern "C" {
#endif

#define DISK_DATA_DIRECTION_NO		0
#define DISK_DATA_DIRECTION_WRITE	1
#define DISK_DATA_DIRECTION_READ	2

typedef struct sDiskRawPacket
{
	unsigned char ucCommand[12];
	int			  iCommandLength;
	unsigned char *cpBuffer;
	int			  iBufferLength;
	unsigned char *cpSense;
	int			  iSenseLength;
	unsigned int  uiDirection;
	unsigned int  uiFlags;
	unsigned char iSense;
	unsigned char iError;
} sDiskRawPacket;

#ifdef __cplusplus
}
#endif


#endif



