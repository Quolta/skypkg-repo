#ifndef _INC_LISTENER
#define _INC_LISTENER

/*!
   \ingroup listener

   Sent with the inode of the directory a new file was created in
*/
#define LISTEN_EVENT_CREATED_IN_DIRECTORY	  		0x00000001

/*!
   \ingroup listener

   Sent with the inode of the file which was opened for write, a write occured and the file gets closed.
*/
#define LISTEN_EVENT_FILE_CHANGED  		            0x00000002
#define LISTEN_EVENT_DELETED  		                0x00000004
#define LISTEN_ATTRIBUTE_CHANGED					0x00000008
#define LISTEN_EVENT_DELETED_IN_DIRECTORY			0x00000010
#define LISTEN_EVENT_FILE_CHANGING					0x00000020
#define LISTEN_EVENT_FILE_CHANGING_IN_DIRECTORY		0x00000040
#define LISTEN_EVENT_FILE_CHANGED_IN_DIRECTORY		0x00000080
#define LISTEN_EVENT_ATTRIBUTE_CHANGED_IN_DIRECTORY	0x00000100
#define LISTEN_EVENT_CREATED				  		0x00000200

#ifdef KERNEL
HRESULT listener_notify(struct vfs_mount_entry *pme, vnode_t listenVnodeid, vnode_t vnode_id, 
						unsigned int uiEventType);
#endif
#endif

