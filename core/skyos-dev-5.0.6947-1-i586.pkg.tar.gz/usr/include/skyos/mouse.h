/************************************************************************
 * Sky Operating System V2
 * Copyright (c) 1996 by Szeleney Robert
 *
 * Project Members: Szeleney Robert
 ************************************************************************
 * File       : include\newgui.h
 * Docus      :
 ************************************************************************/ 

#ifndef _INC_MOUSE_
#define _INC_MOUSE_

#define MAX_STANDARD_MOUSE_POINTERS		 32
#define MOUSE_POINTER_ID_POINTER		 0
#define MOUSE_POINTER_ID_TEXT			 2
#define MOUSE_POINTER_ID_HAND			 3
#define MOUSE_POINTER_ID_DRAGSIZE		 4
#define MOUSE_POINTER_ID_SYSTEM_BUSY	 5
#define MOUSE_POINTER_ID_SIZE_B			 7
#define MOUSE_POINTER_ID_SIZE_BR		 8
#define MOUSE_POINTER_ID_SIZE_BL		 9
#define MOUSE_POINTER_ID_SIZE_T			 10
#define MOUSE_POINTER_ID_SIZE_TR		 11
#define MOUSE_POINTER_ID_SIZE_TL		 12
#define MOUSE_POINTER_ID_SIZE_L			 13
#define MOUSE_POINTER_ID_SIZE_R			 14
#define MOUSE_POINTER_ID_DRAG			 15
#define MOUSE_POINTER_ID_INVISIBLE		 16
#define MOUSE_POINTER_ID_DRAGSIZE_VERT   17
#define MOUSE_POINTER_ID_DND			 18
#define MOUSE_POINTER_ID_DND_CURRENT	 19
#define MOUSE_POINTER_ID_DND_DENIED		 20




typedef struct sMousePointer
{
	unsigned int uiID;
	int iWidth;
	int iHeight;
	int iHotSpotX;
	int iHotSpotY;
	unsigned int *vpDataOriginal;
	unsigned int *vpData;
	unsigned int *uiBackGround;
} sMousePointer;

#endif



