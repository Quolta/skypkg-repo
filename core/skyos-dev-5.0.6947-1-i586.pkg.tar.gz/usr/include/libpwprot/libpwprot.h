#ifndef __LIBPWPROT_H_
#define __LIBPWPROT_H_

#ifdef __cplusplus
extern "C" {
#endif

#define E_PWPROT_SERVICE_NOT_RUNNING  _HRESULT_TYPEDEF_(0x81000200L)

#include <stdio.h>
#include <stdlib.h>
#include <skyos/libskyos.h>
#include <ctype.h>

HRESULT Pwprot_Access(char *pFile,
					  char *pRoot,
					  ino_t vRoot,
					  ino_t vNode,
					  unsigned int enumAccessMethod);
#ifdef __cplusplus
}
#endif
#endif