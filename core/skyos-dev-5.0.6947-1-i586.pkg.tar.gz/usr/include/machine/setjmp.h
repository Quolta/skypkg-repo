#ifndef _INC_SETJMP_H_
#define _INC_SETJMP_H_

_BEGIN_STD_C

#ifdef __SKYOS__

#include "stddef.h"   /* To include NULL definition, is required by a few configure scipts to check for setjmp which just include setjmp.h and use NULL */

#define _JBLEN	9 
typedef	long __jmp_buf[_JBLEN];

#define SP_INDEX 7
#define _JMPBUF_UNWINDS(buf, address) \
  ((void *)(address) < (void *)(buf)[SP_INDEX]) 

#include "signal.h"

typedef struct __sigjmpbuf
{
  __jmp_buf __buf;
  int __is_mask_saved;
  sigset_t __saved_mask;
} sigjmp_buf;

typedef __jmp_buf jmp_buf;

#ifdef __cplusplus
extern "C" {
#endif
void	_EXFUN(longjmp,(jmp_buf __jmpb, int __retval));
int	_EXFUN(setjmp,(jmp_buf __jmpb));
void	_EXFUN(siglongjmp,(sigjmp_buf __jmpb, int __retval));
/*int	_EXFUN(sigsetjmp,(sigjmp_buf __jmpb, int __savemask));*/
#ifdef __cplusplus
}
#endif

/* sigsetjmp is implemented as macro using setjmp */

#define sigsetjmp(__jmpb, __savemask) \
                 ( (__jmpb).__is_mask_saved = __savemask && \
                   (sigprocmask (SIG_BLOCK, NULL, &(__jmpb).__saved_mask) == 0), \
                    setjmp ((__jmpb).__buf) )
#endif

_END_STD_C

#endif
