#ifndef __INC_LIBSKY_LOCK_
#define __INC_LIBSKY_LOCK_

#ifdef __cplusplus
extern "C" {
#endif

#include "atomic.h"

typedef struct libskyLock
{
	atomic_t iCount;
	atomic_t bCreated;
	volatile void *hLock;
	char *pName;
	volatile int hOwner;
} libskyLock;

void* semaphore_create_flags_value(char *name, unsigned int uiFlags, int iValue);
int semaphore_destroy(void* hSem);


#ifdef __cplusplus
}
#endif

#endif


