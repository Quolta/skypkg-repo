#ifndef _INC_LIBLIST_H_
#define _INC_LIBLIST_H_

#include "skygi/skygi.h"

HANDLE List_New(void);
HANDLE List_GetFirst(HANDLE hList, HANDLE *hNode);
HANDLE List_GetNext(HANDLE hList, HANDLE hThis, HANDLE *hNode);
HANDLE List_GetPrev(HANDLE hList, HANDLE hThis, HANDLE *hNode);
HANDLE List_AddTail(HANDLE hList, void *vpData);
HANDLE List_AddHead(HANDLE hList, void *vpData);
HRESULT List_Remove(HANDLE hList, HANDLE hNode);
HRESULT List_GetData(HANDLE hNode);
HRESULT List_IsEmpty(HANDLE hList);

#endif
