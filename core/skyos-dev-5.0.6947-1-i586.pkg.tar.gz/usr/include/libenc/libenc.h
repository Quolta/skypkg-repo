
static inline unsigned int MAKE_LANGUAGE(char *language, char *country)
{
	unsigned int uiID=0;
	unsigned char str[4];

	if (language)
	{
		uiID |= (toupper(language[0])) << 24;
		uiID |= (toupper(language[1])) << 16;
	}
	if (country)
	{
	    uiID |= (toupper(country[0])) << 8;
	    uiID |= (toupper(country[1]));
	}

	return uiID;
}

static inline int GET_LANGUAGE(unsigned int uiID, unsigned char *str)
{
	unsigned short uiLang;

	uiLang = (unsigned short)(uiID >> 16);
	str[0] = (uiLang >> 8) & 0xFF;
	str[1] = uiLang & 0xFF;
	str[2] = 0;
	return 0;

}


