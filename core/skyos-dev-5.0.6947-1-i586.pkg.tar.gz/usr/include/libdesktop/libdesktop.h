#ifndef _INC_LIBDESKTOP_
#define _INC_LIBDESKTOP_

#ifdef __cplusplus
extern "C" {
#endif

#include "skygi/skygi.h"

#define DESKTOP_LINK_CREATE_HERE_ON_DESKTOP		0x00000001

#define DESKTOP_EXECUTE_OPEN_WITH				0x00000002


enum
{
	DESKTOP_QUERY_METHOD_CONTENT=0,
	DESKTOP_QUERY_METHOD_QUERY
};

typedef struct sDesktopLink
{
	char *pName;
	char *pPathToExecutable;
	char *pArgumentString;
	char *pIconPath;
	char *pWorkingFolder;
	unsigned int uiFlags;
	int iPreferedDisplayPosX;
	int iPreferedDisplayPosY;
} sDesktopLink;

typedef struct sDesktopQuery
{
	char *pName;
	char *pQuery;
	unsigned int uiQueryMethod;
	unsigned int uiFlags;
} sDesktopQuery;

int Desktop_Execute(char *pPath,
					char *pArgs[],
					unsigned int uiTaskCreateFlags,
					unsigned int uiFlags);
HANDLE Desktop_LinkCreateInPanel(char *pUser,
								 char *pPath,
								 char *pMenu,
								 char *pType,
								 HANDLE hLink);
HANDLE Desktop_LinkCreateOnDesktop(char *pUser, char *pFile, int x, int y, HANDLE hLink);
HRESULT Desktop_LinkRead(HANDLE *phLink, char *pFileName);
HRESULT Desktop_LinkFree(HANDLE hLink);
HRESULT Desktop_LinkGetPreferedDisplayPos(HANDLE hLink, int *piX, int *piY);
HRESULT Desktop_LinkCreate(HANDLE *phLink);
char* Desktop_LinkGetExecutable(HANDLE hLink);
char* Desktop_LinkGetArgumentString(HANDLE hLink);
char* Desktop_LinkGetIcon(HANDLE hLink);
char* Desktop_LinkGetName(HANDLE hLink);
char* Desktop_LinkGetWorkingFolder(HANDLE hLink);
HRESULT Desktop_LinkSetName(HANDLE hLink, char *pName);
HRESULT Desktop_LinkSetArgumentString(HANDLE hLink, char *pArgumentString);
HRESULT Desktop_LinkSetExecutable(HANDLE hLink, char *pPathToExecutable);
HRESULT Desktop_LinkSetIcon(HANDLE hLink, char *pIconPath);
HRESULT Desktop_LinkSetWorkingFolder(HANDLE hLink, char *pWorkingFolder);
HRESULT Desktop_LinkSetPreferedDisplayPos(HANDLE hLink, int iX, int iY);
HRESULT Desktop_LinkWrite(HANDLE hLink, char *pFileName);

HRESULT Desktop_QueryRead(HANDLE *phQuery, char *pFileName);
char* Desktop_QueryGetQuery(HANDLE hQuery);
HRESULT Desktop_QuerySetQuery(HANDLE hQuery, char *pQueryString);
 HRESULT Desktop_QueryCreate(HANDLE *phQuery);
HRESULT Desktop_QueryWrite(HANDLE hQuery, char *pFileName);
HRESULT Desktop_QueryFree(HANDLE hQuery);

#ifdef __cplusplus
}
#endif

#endif
