/*
	libTimer for SkyOS
	Author: Peter Speybrouck
	Contact: peter.speybrouck@gmail.com

	Don't change or remove this header info.
*/

typedef void (*tTimerFunction)(void *pCookie);

int Timer_Create(unsigned int msec,tTimerFunction onTimer, void *pCookie );
void Timer_Cleanup(int PID);
void Timer_Enable(int PID);
void Timer_Disable(int PID);
void Timer_SetInterval(int PID, unsigned int msecs);
unsigned int Timer_GetInterval(int PID);
void Timer_SetEvent(int PID,tTimerFunction onTimer);



