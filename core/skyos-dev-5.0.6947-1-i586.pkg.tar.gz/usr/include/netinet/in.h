#ifndef _NETINET_IN_
#define _NETINET_IN_

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/socket.h>

#ifndef _IN_ADDR_T_DECLARED
typedef unsigned int    in_addr_t;
#define _IN_ADDR_T_DECLARED
#endif

#ifndef _IN_PORT_T_DECLARED
typedef unsigned short  in_port_t;
#define _IN_PORT_T_DECLARED
#endif

/* Internet address */
struct in_addr {
    in_addr_t s_addr;
};

/* Socket address for IPv4 */
struct sockaddr_in {
    sa_family_t    sin_family;
    in_port_t      sin_port;
    struct in_addr sin_addr;
    char           sin_zero[8];
};

#ifndef INADDR_ANY
#define INADDR_ANY          ((in_addr_t) 0x00000000)
#endif

#ifndef INADDR_NONE
#define INADDR_NONE         ((in_addr_t) 0xffffffff)
#endif

/* Standard well-defined IP protocols */
enum {
  IPPROTO_IP = 0,
  IPPROTO_ICMP = 1,
  IPPROTO_IGMP = 2,
  IPPROTO_IPIP = 4,
  IPPROTO_TCP = 6,
  IPPROTO_EGP = 8,
  IPPROTO_PUP = 12,
  IPPROTO_UDP = 17,
  IPPROTO_IDP = 22,
  IPPROTO_RSVP = 46,
  IPPROTO_GRE = 47,
  IPPROTO_IPV6 = 41,
  IPPROTO_PIM = 103,
  IPPROTO_RAW = 255,
  IPPROTO_MAX
};

/* Standard well-known ports */
enum {
    IPPORT_ECHO = 7, IPPORT_DISCARD = 9, IPPORT_SYSTAT = 11,
    IPPORT_DAYTIME = 13, IPPORT_NETSTAT = 15, IPPORT_FTP = 21,
    IPPORT_TELNET = 23, IPPORT_SMTP = 25, IPPORT_TIMESERVER = 37,
    IPPORT_NAMESERVER = 42, IPPORT_WHOIS = 43, IPPORT_MTP = 57,
    IPPORT_TFTP = 69, IPPORT_RJE = 77, IPPORT_FINGER = 79,
    IPPORT_TTYLINK = 87, IPPORT_SUPDUP = 95,
    IPPORT_EXECSERVER = 512, IPPORT_LOGINSERVER = 513,
    IPPORT_CMDSERVER = 514, IPPORT_EFSSERVER = 520,
    IPPORT_BIFFUDP = 512, IPPORT_WHOSERVER = 513,
    IPPORT_ROUTESERVER = 520,
    IPPORT_RESERVED = 1024, IPPORT_USERRESERVED = 5000
};

#define MAXHOSTNAMELEN 64
#define INADDR_BROADCAST    ((unsigned long int) 0xffffffff)

/* Socket level options */
#define SOL_SOCKET      1
#define SO_DEBUG        1
#define SO_REUSEADDR    2
#define SO_TYPE         3
#define SO_ERROR        4
#define SO_DONTROUTE    5
#define SO_BROADCAST    6
#define SO_SNDBUF       7
#define SO_RCVBUF       8
#define SO_KEEPALIVE    9
#define SO_OOBINLINE    10
#define SO_NO_CHECK     11
#define SO_PRIORITY     12
#define SO_LINGER       13
#define SO_BSDCOMPAT    14
#define SO_PASSCRED     16
#define SO_PEERCRED     17
#define SO_RCVLOWAT     18
#define SO_SNDLOWAT     19
#define SO_RCVTIMEO     20
#define SO_SNDTIMEO     21
#define SO_BINDTODEVICE 25
#define SO_NONBLOCK     26
#define SO_ACCEPTCONN   27

/* TCP options */
#define TCP_NODELAY     1

/* IP class macros */
#define IN_CLASSA(a)       ((((in_addr_t)(a)) & 0x80000000) == 0)
#define IN_CLASSA_NET      0xff000000
#define IN_CLASSA_NSHIFT   24
#define IN_CLASSB(a)       ((((in_addr_t)(a)) & 0xc0000000) == 0x80000000)
#define IN_CLASSB_NET      0xffff0000
#define IN_CLASSC(a)       ((((in_addr_t)(a)) & 0xe0000000) == 0xc0000000)
#define IN_CLASSC_NET      0xffffff00
#define IN_CLASSD(a)       ((((in_addr_t)(a)) & 0xf0000000) == 0xe0000000)
#define IN_MULTICAST(a)    IN_CLASSD(a)

#ifndef INADDR_LOOPBACK
#define INADDR_LOOPBACK ((unsigned int) 0x7f000001)
#endif
#define IN_LOOPBACKNET  127

/* IPv6 options */
#define IPV6_UNICAST_HOPS   16
#define IPV6_MULTICAST_IF   17
#define IPV6_MULTICAST_HOPS 18
#define IPV6_MULTICAST_LOOP 19
#define IPV6_JOIN_GROUP     20
#define IPV6_LEAVE_GROUP    21
#define IPV6_ADD_MEMBERSHIP IPV6_JOIN_GROUP
#define IPV6_DROP_MEMBERSHIP IPV6_LEAVE_GROUP
#define IPV6_V6ONLY         26

/* IP-level socket options for multicast */
#define IP_TOS              1
#define IP_TTL              2
#define IP_MULTICAST_IF     32
#define IP_MULTICAST_TTL    33
#define IP_MULTICAST_LOOP   34
#define IP_ADD_MEMBERSHIP   35
#define IP_DROP_MEMBERSHIP  36

/* Multicast group request struct */
struct ip_mreq {
    struct in_addr imr_multiaddr;
    struct in_addr imr_interface;
};

/* Source-specific multicast (SSM) */
#define IP_ADD_SOURCE_MEMBERSHIP  39
#define IP_DROP_SOURCE_MEMBERSHIP 40

struct ip_mreq_source {
    struct in_addr imr_multiaddr;
    struct in_addr imr_interface;
    struct in_addr imr_sourceaddr;
};

/* group_source_req for SSM (Protocol-independent) */
struct group_source_req {
    unsigned int                gsr_interface;
    struct sockaddr_storage     gsr_group;
    struct sockaddr_storage     gsr_source;
};

#define MCAST_JOIN_SOURCE_GROUP    46
#define MCAST_LEAVE_SOURCE_GROUP   47

#ifndef KERNEL
unsigned int   htonl(unsigned int hostlong);
unsigned short htons(unsigned short hostshort);
unsigned int   ntohl(unsigned int netlong);
unsigned short ntohs(unsigned short netshort);
#endif

#include <netinet/in6.h>

#ifdef __cplusplus
}
#endif

#endif /* _NETINET_IN_ */
