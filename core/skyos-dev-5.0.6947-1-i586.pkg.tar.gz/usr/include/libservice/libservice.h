#ifndef _INC_LIBSERVICE_
#define _INC_LIBSERVICE_

#include "libdcs/libdcs.h"

#define SERVICE_DEFAULT_REPLY_TIMEOUT		5*1000			/* 1sec */

#define SERVICE_MANAGER_INTERFACE "System.ServiceManager"

enum
{
	SERVICE_STATUS_STOPPED = 0,
	SERVICE_STATUS_RUNNING
};

enum
{
	SERVICE_START_MODE_MANUAL = 0,
	SERVICE_START_MODE_AUTOMATIC
};

typedef struct sServiceManagerInterface
{
	char ucPath[255];
	sDCSInterface *pInterface;
} sServiceManagerInterface;


HRESULT 	ServiceManager_Connect (sServiceManagerInterface **ppInterface);
HRESULT 	ServiceManager_GetServiceName (sServiceManagerInterface *pInterface, int iServiceIndex, char *ucName, char *ucType);
HRESULT 	ServiceManager_GetStartMode (sServiceManagerInterface *pInterface, char *ucServiceName, unsigned int *puiStartMode);
HRESULT 	ServiceManager_SetStartMode (sServiceManagerInterface *pInterface, char *ucServiceName, unsigned int uiStartMode);
HRESULT 	ServiceManager_GetServiceStatus (sServiceManagerInterface *pInterface, char *ucServiceName, unsigned int *puiServiceStatus);
HRESULT 	ServiceManager_GetServiceInfo (sServiceManagerInterface *pInterface, char *ucServiceName, char *ucText);
HRESULT 	ServiceManager_StartService (sServiceManagerInterface *pInterface, char *ucServiceName);
HRESULT 	ServiceManager_StopService (sServiceManagerInterface *pInterface, char *ucServiceName);
HRESULT 	ServiceManager_OpenConfiguration (sServiceManagerInterface *pInterface, char *ucServiceName);
HRESULT 	ServiceManager_CloseConfiguration (sServiceManagerInterface *pInterface, char *ucServiceName);
HRESULT 	ServiceManager_IsConfigurationInProgress (sServiceManagerInterface *pInterface, char *ucServiceName, int *puiInProgress);

#endif
