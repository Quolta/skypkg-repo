#ifndef __INC_CLIPBOARD_H__
#define __INC_CLIPBOARD_H__

#include <os/Object.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <gui/Window.h>
#include <os/DataCollection.h>

namespace SkyGI
{

class Clipboard : public Object
{
public:
	Clipboard();

	DataCollection*		Get();
	void				Clear();
	bool				Submit(const DataCollection& pDataCollection);


private:
	class Private;
	Private *m;
};

}

#endif
