#ifndef	__INC_HARDWAREDEVICE_H__
#define	__INC_HARDWAREDEVICE_H__

#include <os/Object.h>
#include <os/String.h>
#include <gui/Image.h>
#include <vector>
#include <include/device.h>

namespace SkyGI
{

class HardwareDeviceClass : public Object
{
public:
	HardwareDeviceClass(enumDeviceType deviceType);

	String	GetName();
	Image*  GetImage(int iSize = 16);

private:
	enumDeviceType m_deviceType;
};

class HardwareDevice : public Object
{
public:
	HardwareDevice(enumDeviceType deviceType);

	enumDeviceType  GetClass() { return m_deviceType; };
	bool IsClaimed() { return m_bIsClaimed; };
	bool SetClaimed(bool bClaimed) { m_bIsClaimed = bClaimed; };

	String GetName() { return m_szDeviceName; };
	void   SetName(const String& szName) { m_szDeviceName = szName; };

	String GetErrorText() { return m_szErrorText; };
	void   SetErrorText(const String& szErrorText) { m_szErrorText = szErrorText; };

	int    GetError() { return m_iErrorCode; };
	void   SetError(int iErrorCode) { m_iErrorCode = iErrorCode; };

private:
	enumDeviceType m_deviceType;
	bool		   m_bIsClaimed;
	String		   m_szDeviceName;
	int			   m_iErrorCode;
	String		   m_szErrorText;
	String		   m_szInfoFile;
};

class HardwareDeviceList : public Object
{
public:
	HardwareDeviceList();
	~HardwareDeviceList()
	{
	}

	static std::vector<HardwareDevice*> Get();

private:

} ;

}

#endif
