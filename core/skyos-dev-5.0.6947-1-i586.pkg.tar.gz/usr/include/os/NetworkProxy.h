#ifndef __INC_NetworkProxy_H__
#define __INC_NetworkProxy_H__

#include "os/Object.h"

namespace SkyGI
{
	enum NetworkProxyType
	{
		NETWORK_PROXY_TYPE_HTTP=0,
		NETWORK_PROXY_TYPE_SOCKS4,
		NETWORK_PROXY_TYPE_SOCKS5,
	};

	class NetworkProxy
	{
	public:
		NetworkProxy();
		virtual ~NetworkProxy();

		bool	Get(const String& szName = "Primary");

		bool	Enabled() const;
		String				GetHost() const;
		int					GetPort() const;
		NetworkProxyType	GetType() const;
		String				GetUser() const;
		String				GetPassword() const;

	private:
		NetworkProxyType	m_nType;
		String				m_szHost;
		String				m_szUser;
		String				m_szPassword;
		int					m_iPort;

		bool				m_bValid;
		bool				m_bEnabled;
	};
}

#endif
