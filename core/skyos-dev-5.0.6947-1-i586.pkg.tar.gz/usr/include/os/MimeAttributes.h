#ifndef	__INC_MIMEATTRIBUTES_H__
#define	__INC_MIMEATTRIBUTES_H__

#include <os/Object.h>
#include <os/String.h>
#include <os/FileAttribute.h>
#include <gui/Image.h>

namespace SkyGI
{
/** MimeAttributes
 * \ingroup skygi
 * \par Description:
 *		This class handles the known attributes from various MimeTypes like Images, Videos, ...\n
 *		Each MimeType is handled by a single plugin which gets loaded automatically. \n
 *		Use this class to either retrieve the list of supported/known attributes for a specific mimetype or to actually read
 *		all known attributes for specified file
 *****************************************************************************/
class MimeAttributes
{
public:
	MimeAttributes();
	~MimeAttributes();

	bool GetAttributeList(int iIndex, String& szType, FileAttributeList& pAttributeList );
private:
	class Private;
	Private *m;
};

}

#endif
