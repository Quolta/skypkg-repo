#ifndef __INC_OptionParser_H__
#define __INC_OptionParser_H__

#include "os/Object.h"
#include "os/String.h"
#include "os/Variant.h"

namespace SkyGI
{
	class OptionParser
	{
	public:
		static bool Get(const String& szString, const String& szKey, String& cString);
		static bool Get(const String& szString, const String& szKey, int& iValue);
		static bool	Get(const String& szString, const String& cKey, Variant& pVariant);
	};
}

#endif
