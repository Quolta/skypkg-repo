#ifndef __INC_Archiver_H__
#define __INC_Archiver_H__

#include <os/Object.h>
#include <os/String.h>
#include <os/PluginManager.h>
#include <gui/Point.h>
#include <gui/Rect.h>
#include <gui/Image.h>

namespace SkyGI
{
class Archiver;

class ArchiveEntry
{
public:
	ArchiveEntry()
	{
		m_szPath = "";
		m_szLinkTo = "";
		m_iMode = m_iOwner = 0;
		m_iFileSize = m_iPackedSize = 0;
		m_fPackRatio = 0.0;

		m_tModify = m_tCreate = m_tAccess = 0;
	}

	String		 m_szPath;
	String		 m_szLinkTo;
	int			 m_iMode;
	int			 m_iOwner;
	off_t		 m_iFileSize;
	off_t		 m_iPackedSize;
	float		 m_fPackRatio;
	time_t		 m_tModify;
	time_t		 m_tCreate;
	time_t		 m_tAccess;
};


class ArchiverFactory : public Object
{
public:

	ArchiverFactory();
	~ArchiverFactory();

	static int LoadArchiver(const String &szPath);
	static int LoadArchivers(const String &szDirectory);

	void ArchiverLoaded(Plugin *pPlugin, const String &szPath);

	static Archiver* GetArchiver(const String& szPath);

private:
	static std::vector<Plugin *>			m_pArchiverPlugins;
	static PluginManager					m_pArchiverPluginManager;
	static bool								m_bArchiversLoaded;
};

class Archiver : public Object
{
public:
	enum Error
	{
		ERROR_OK		   = 0,
		ERROR_WRONG_FORMAT = 1,
		ERROR_NOT_OPENED   = 2,
		ERROR_INTERAL_FORMAT_ERROR = 3,
	};

	enum Action
	{
		CREATE_DIRECTORY = 1,
		CREATE_LINK,
		CREATE_FILE,
		WRITE_FILE,
		DONE
	};
	
	Archiver();
	~Archiver();

	virtual String GetName() = 0;

	virtual bool Identify(char *pBuffer, int iBufferSize)  = 0;

	virtual bool			Open(const String& szPath) = 0;

	virtual void SetError(Archiver::Error nError);
	virtual Archiver::Error GetError();

	// todo: make sure that ArchiveEntry gets freed when we free the std::vector
	virtual bool GetFileList(std::vector<ArchiveEntry>& arrFileList) = 0;
	
	virtual bool Extract(const String& szDestinationFolder) = 0;

	virtual bool Extract(const String& szFile, const String& szDestinationFolder) = 0;

	virtual bool OnProcessEntry(Archiver::Action nAction, const ArchiveEntry &nEntry, off_t iSize, off_t iTotalSize);

	virtual bool OnError(Archiver::Action nAction, const ArchiveEntry &nEntry, off_t iSize, off_t iTotalSize);

	signal5<Archiver*, Archiver::Action, const ArchiveEntry&, off_t, off_t> _Process;
	signal5<Archiver*, Archiver::Action, const ArchiveEntry&, off_t, off_t> _Error;

	virtual void Abort() = 0;

	virtual bool Aborted() = 0;

	virtual void Reset() = 0;

	virtual void SetOverwriteMode(bool bOverwrite) = 0;

	virtual off_t GetExtractedSize() = 0;

	virtual bool GetProgressTotal(off_t& llSize, off_t& llTotalSize) = 0;


private:
	class Private;
	Private *m;

};

}

#endif
