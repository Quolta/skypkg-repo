#ifndef	__INC_NetworkRoute_H__
#define	__INC_NetworkRoute_H__

#include <os/Object.h>
#include <os/String.h>
#include <vector>

namespace SkyGI
{

class NetworkRoute : public Object
{
public:
	NetworkRoute(const String& pTargetIP, const String& pNetmaskIP, const String& pGatewayIP, const String& pNetworkDevice, int iMetric=0);
	~NetworkRoute();

	String	GetTarget() const {return m_pTargetIP;}
	String	GetNetmask()const  {return m_pNetmaskIP;}
	String	GetGateway() const {return m_pGatewayIP;}
	String	GetNetworkDevice() const {return m_pNetworkDevice;}
	int     GetMetric() const {return m_iMetric;}

private:
	String m_pTargetIP;
	String m_pNetmaskIP;
	String m_pGatewayIP;
	String m_pNetworkDevice;
	int	   m_iMetric;
} ;

class NetworkRoutingTable : public Object
{
public:
	NetworkRoutingTable();
	~NetworkRoutingTable();

	static bool Add(const NetworkRoute &pRoute);
	static bool Remove(const NetworkRoute &pRoute);

	static std::vector<NetworkRoute> Get();

private:
} ;
}

#endif
