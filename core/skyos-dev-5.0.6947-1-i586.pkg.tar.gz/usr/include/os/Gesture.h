#ifndef	__INC_GESTURE_H__
#define	__INC_GESTURE_H__

#include <os/Object.h>
#include <os/String.h>
#include <gui/Image.h>
#include <vector>

namespace SkyGI
{

class Gesture
{
public:
	enum GestureAction
	{
		NOACTION=0,
		MAXIMIZE_FOCUSED_WINDOW,
		MINIMIZE_FOCUSED_WINDOW,
		LAUNCH_APPLICATION,
		HIDE_SHOW_ALL_WINDOWS,
	};


	Gesture();
	~Gesture();

	void				SetStroke(const String& szStroke);
	String				GetStroke();

	void				SetAction(enum GestureAction enumAction);
	enum GestureAction	GetAction();

	void				SetActionData(const String& szString);
	String				GetActionData();

	bool				Save(const String& szName);
	bool				Load(const String& szName);

	bool				IsValid();
	static bool			Remove(const String& szName);


	static std::vector<String> Get();
private:
	class Private;
	Private *m;
};

class GestureAction
{
public:
	GestureAction();

	String						m_szDescription;
	Gesture::GestureAction		m_enumAction;
	bool						m_bParameter;
	String						m_szParameterDescription;

	static std::vector<GestureAction> Get();
};

}

#endif
