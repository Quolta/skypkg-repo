#ifndef	__INC_KeyboardLayout_H__
#define	__INC_KeyboardLayout_H__

#include <os/Object.h>
#include <os/String.h>
#include <vector>

namespace SkyGI
{

class KeyboardLayout : public Object
{
public:
	KeyboardLayout();
	KeyboardLayout(const KeyboardLayout& pKeyboardLayout);
	KeyboardLayout(const String& szPath);
	~KeyboardLayout();

	bool IsValid();
	bool SetActive();
	String GetName() const;
	String GetPath() const;

	

private:
	class Private;
	Private *m;
} ;

}

#endif
