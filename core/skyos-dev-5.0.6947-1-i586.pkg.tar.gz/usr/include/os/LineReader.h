#ifndef __INC_LineReader_H__
#define __INC_LineReader_H__

#include "os/Object.h"
#include "os/String.h"
#include "os/Variant.h"

namespace SkyGI
{
	class LineReader
	{
	public:
		LineReader(const String& szString);
		~LineReader();

		bool GetNextLine(String &szString);
		void Rewind();


	private:
		class Private;
		Private *m;
	};
}

#endif
