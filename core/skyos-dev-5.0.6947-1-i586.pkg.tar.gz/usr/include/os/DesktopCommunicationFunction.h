#ifndef __INC_DESKTOPCOMMUNICATIONFUNCTION_H__
#define __INC_DESKTOPCOMMUNICATIONFUNCTION_H__

class DesktopCommunicationFunctionBase
{
public:
	DesktopCommunicationFunctionBase(const String& szFunctionName)
	{
		m_szFunctionName = szFunctionName;
	}
	virtual void ProcessCall(DesktopCommunicationMessage *pMessage) = 0;

	String m_szFunctionName;
	int m_iParams;
	std::vector<String> m_pParam;
};

#define DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(__message, __callparams) \
	m_iCallParams = __callparams;\
	m_bCallMessage = __message; \
	m_iParams = 0; \
	const char* szParameterName; \
	va_list pArgs; \
	va_start( pArgs, szFunctionName );  \
	while( ( szParameterName = va_arg( pArgs, const char * ) ) != NULL ) \
	{ \
		m_iParams++; \
		m_pParam.push_back(szParameterName); \
	} \

#define DESKTOP_COMMUNICATION_FUNCTION_PARAM_COMMON \
	Variant v[m_iCallParams]; \
	for (int i=0;i<m_iParams;i++)\
	{\
	printf("get '%s'\n", m_pParam[i].c_str()); \
		pMessage->Get(m_pParam[i], v[i]);\
	v[i].Dump();\
	}

#define DESKTOP_COMMUNICATION_FUNCTION_MEMBERS \
	int m_iCallParams; \
	bool m_bCallMessage;


class DesktopCommunicationFunction : public DesktopCommunicationFunctionBase
{
	public:
		template<class desttype>
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(DesktopCommunicationMessage *), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(true, 0)
			CalledMessage0.Connect((desttype*)pObject, fp);
		}

		template<class desttype>
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(DesktopCommunicationMessage *, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(true, 1)
			CalledMessage1.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(DesktopCommunicationMessage *, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(true, 2)
			CalledMessage2.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(DesktopCommunicationMessage *, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(true, 3)
			CalledMessage3.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(DesktopCommunicationMessage *, Variant, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(true, 4)
			CalledMessage4.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(DesktopCommunicationMessage *, Variant, Variant, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(true, 5)
			CalledMessage5.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(DesktopCommunicationMessage *, Variant, Variant, Variant, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(true, 6)
			CalledMessage6.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(DesktopCommunicationMessage *, Variant, Variant, Variant, Variant, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(true, 7)
			CalledMessage7.Connect((desttype*)pObject, fp);
		}


		template<class desttype>
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(false, 0)
			Called0.Connect((desttype*)pObject, fp);
		}

		template<class desttype>
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(false, 1)
			Called1.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(false, 2)
			Called2.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(false, 3)
			Called3.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(Variant, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(false, 4)
			Called4.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(Variant, Variant, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(false, 5)
			Called5.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(Variant, Variant, Variant, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(false, 6)
			Called6.Connect((desttype*)pObject, fp);
		}

		template<class desttype> 
		DesktopCommunicationFunction( void *pObject, void (desttype::*fp)(Variant, Variant, Variant, Variant, Variant, Variant, Variant), const String &szFunctionName, ...) : DesktopCommunicationFunctionBase(szFunctionName)
		{
			DESKTOP_COMMUNICATION_FUNCTION_IMPLEMENTATION_COMMON(false, 7)
			Called7.Connect((desttype*)pObject, fp);
		}





		void ProcessCall(DesktopCommunicationMessage *pMessage)
		{
			DESKTOP_COMMUNICATION_FUNCTION_PARAM_COMMON
			
			if (m_bCallMessage)
			{
				switch (m_iCallParams)
				{
					case 0:	CalledMessage0(pMessage); break;
					case 1:	CalledMessage1(pMessage, v[0]); break;
					case 2:	CalledMessage2(pMessage, v[0], v[1]); break;
					case 3:	CalledMessage3(pMessage, v[0], v[1], v[2]); break;
					case 4:	CalledMessage4(pMessage, v[0], v[1], v[2], v[3]); break;
					case 5:	CalledMessage5(pMessage, v[0], v[1], v[2], v[3], v[4]); break;
					case 6:	CalledMessage6(pMessage, v[0], v[1], v[2], v[3], v[4], v[5]); break;
					case 7:	CalledMessage7(pMessage, v[0], v[1], v[2], v[3], v[4], v[5], v[6]); break;
				}
			}
			else
			{
				switch (m_iCallParams)
				{
					case 0:	Called0(); break;
					case 1:	Called1(v[0]); break;
					case 2:	Called2(v[0], v[1]); break;
					case 3:	Called3(v[0], v[1], v[2]); break;
					case 4:	Called4(v[0], v[1], v[2], v[3]); break;
					case 5:	Called5(v[0], v[1], v[2], v[3], v[4]); break;
					case 6:	Called6(v[0], v[1], v[2], v[3], v[4], v[5]); break;
					case 7:	Called7(v[0], v[1], v[2], v[3], v[4], v[5], v[6]); break;
				}
			}
		}

		signal0<> Called0;
		signal1<Variant> Called1;
		signal2<Variant, Variant> Called2;
		signal3<Variant, Variant, Variant> Called3;
		signal4<Variant, Variant, Variant, Variant> Called4;
		signal5<Variant, Variant, Variant, Variant, Variant> Called5;
		signal6<Variant, Variant, Variant, Variant, Variant, Variant> Called6;
		signal7<Variant, Variant, Variant, Variant, Variant, Variant, Variant> Called7;

		signal1<DesktopCommunicationMessage*> CalledMessage0;
		signal2<DesktopCommunicationMessage*, Variant> CalledMessage1;
		signal3<DesktopCommunicationMessage*, Variant, Variant> CalledMessage2;
		signal4<DesktopCommunicationMessage*, Variant, Variant, Variant> CalledMessage3;
		signal5<DesktopCommunicationMessage*, Variant, Variant, Variant, Variant> CalledMessage4;
		signal6<DesktopCommunicationMessage*, Variant, Variant, Variant, Variant, Variant> CalledMessage5;
		signal7<DesktopCommunicationMessage*, Variant, Variant, Variant, Variant, Variant, Variant> CalledMessage6;
		signal8<DesktopCommunicationMessage*, Variant, Variant, Variant, Variant, Variant, Variant, Variant> CalledMessage7;

	private:
		DESKTOP_COMMUNICATION_FUNCTION_MEMBERS
};
#endif
