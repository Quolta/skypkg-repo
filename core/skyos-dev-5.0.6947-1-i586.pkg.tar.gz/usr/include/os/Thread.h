#ifndef	__INC_THREAD_H__
#define	__INC_THREAD_H__

#include <os/Object.h>
#include <os/String.h>
#include <gui/MessageQueue.h>

extern "C" int ThreadKill(int iPid);

namespace SkyGI
{

/** Thread
 * \ingroup skygi
 * \par Description:
 *		This virtual base class can be used to create threads. 
 * \par Note:
 *		This thread class will not handle windows and so doesn't have a MessageQueue. 
 *		If you create a window from within such a thread the Process itself will get the window owner. If you want let the thread handle windows
 *		then use the WindowThread class. \n
 *		Optinally you get use an EventThread to wait for events and perform idle work.
 *
 * \par Example:
 * \code
 *		class MyThread : public Thread
 *		{
 *		public:
 *			MyThread();
 *			int Run() { printf("Hello from thread!\n");
 *		};
 *
 *		MyThread::MyThread() : Thread("mythread") {};
 *
 *		...
 *		MyThread *pThread = new MyThread();
 *		MyThread->Start();
 *		...
 * \endcode
 * \sa
 *		WindowThread
 *****************************************************************************/
class Thread : public Object
{
public:
	Thread(const String& szName);
	virtual ~Thread();
	bool		 IsValid();
	virtual bool Kill();
	virtual int  Run() = 0;
	virtual int	 Start(unsigned int uiCreateFlags = 0);
	virtual int	 Stop();
	virtual int	 WaitFor();
	virtual int	 WaitFor(int& iExitCode);
	int			 GetPid();
	void		 SetFlags(unsigned int uiFlags);
	void		 ClearFlags(unsigned int uiFlags);
	unsigned int GetFlags();
	static void	 SetKey(int iKey, void* vpData);
	static void* GetKey(int iKey);
	static int   AllocKey();



	class Private;
	Private *m;

	static int	  _ThreadEntry(Thread *pThread, unsigned int uiFlags);

protected:
	void *fpEntryFunction;
} ;

}

#endif
