#ifndef __INC_LOCK_H__
#define __INC_LOCK_H__

extern "C" 
{
	#include "libskylock.h"
	#include "skyos/sem.h"
	#include "skyos/libskyos.h"
}

namespace SkyGI
{
/** Locker
 * \ingroup skygi
 * \par Description:
 *		Implementes a recursive and optional interruptable lock
 *****************************************************************************/
class Locker
{
public:
    Locker( const char* cpName, bool bInterruptable = false )
    {
		_Init(cpName, bInterruptable);
    }
    Locker( bool bInterruptable = false)
    {
		_Init("anonymous", bInterruptable);
    }
    ~Locker() { semaphore_destroy( m_nSemaphore ); }

    inline int    Lock() const;
    inline int    Unlock() const;
    int			  GetLockCount() const { return( m_nNestCount ); }
    int			  GetOwner() const { return( m_nOwnerPid ); }
    inline bool   IsLocked() const;

private:
	void	 _Init(const char* cpName, bool bInterruptable = false)
	{
		m_nOwnerPid  = -1;
		m_nSemaphore = semaphore_create_flags_value((char*)cpName, LOCK_FLAG_RELEASE_COUNTING, 0);
		m_nLockCount = 0;
		m_nNestCount = 0;
		bInterruptable = bInterruptable;
	}

    bool     m_bInterruptable;
    void*    m_nSemaphore;
    mutable int		  m_nOwnerPid;
    mutable atomic_t  m_nLockCount;
    mutable int	      m_nNestCount;
};

class ScopeLocker
{
public:
    ScopeLocker( Locker* pLock ) 
	{ 
		m_pLock = pLock; 
		pLock->Lock(); 
	}
    ~ScopeLocker() 
	{ 
		m_pLock->Unlock(); 
	}
private:
    Locker* m_pLock;
};

int Locker::Lock() const
{
    int pid= ThreadGetPid();
    int iError;

    if ( m_nOwnerPid == pid ) 
	{
		m_nNestCount++;
		iError = 0;
    } 
	else 
	{
		if ( atomic_add( &m_nLockCount, 1 ) > 0 ) 
		{
			while (1)
			{
				iError = semaphore_aquire( m_nSemaphore );

				if (( iError == -1) && (errno == EINTR))
					continue;
				break;
			}
	    	    
			if ( iError < 0 ) 
			{
				atomic_add( &m_nLockCount, -1 );
			} 
			else 
			{
				m_nOwnerPid  = pid;
				m_nNestCount = 1;
			}
		} 
		else 
		{
			iError = 0;
			m_nOwnerPid  = pid;
			m_nNestCount = 1;
		}
	}
    return( iError );
}

int Locker::Unlock() const
{
    int iError;

    if ( m_nNestCount > 1 ) 
	{
		m_nNestCount--;
		return 0 ;
	} 
	else 
	{
		m_nOwnerPid  = -1;
		m_nNestCount = 0;
    
		if ( atomic_add( &m_nLockCount, -1 ) > 1)
		{
			iError = semaphore_release( m_nSemaphore );
		} 
		else 
		{
			iError = 0;
		}
	
		return iError ;
    }
}

inline bool Locker::IsLocked() const
{
    return( m_nNestCount > 0 && m_nOwnerPid == ThreadGetPid() );
}

}

#endif 


