#ifndef __INC_REGISTRY_H__
#define __INC_REGISTRY_H__

#include "os/Object.h"
#include "os/String.h"
#include "librsm/rsmuser.h"


namespace SkyGI
{

enum RegistryFlags
{
	REGISTRYFLAG_USER_LOCAL  = 0x00000001,
};


class Registry : public Object
{
public:
	Registry();

	bool	Get(const String& cKey, String& cValue, unsigned int uiFlags);
	bool	Set(const String& cKey, const String& cValue, unsigned int uiFlags);
	bool	Get(const String& cKey, int& iValue, unsigned int uiFlags);
	bool	Set(const String& cKey, int iValue, unsigned int uiFlags);
};

}

#endif
