#ifndef	__INC_PROCESS_H__
#define	__INC_PROCESS_H__

#include <os/Object.h>
#include <os/String.h>
#include <vector>

extern "C" int ThreadKill(int iPid);

namespace SkyGI
{

typedef std::vector<String> ProcessArguments;

class Process : public Object
{
public:
	Process();
	Process(int iPid);
	Process(Process *pProcess);
	~Process();
	bool		IsValid();
	bool		SetTo(int iPid);
	bool		Refresh();
	String		GetName() { return m_pName; }
	String		GetUser() { return m_pUser; }
	String		GetState() { return m_pState; }
	String		GetTime() { return m_pTime; }
	int			GetPid() { return m_iPid; }
	int			GetPgid() { return m_iPGid; }
	int			GetPriority() { return m_iPriority; }
	int			GetDynamicPriority() { return m_iDynamicPriority; }
	int			GetHeapPages() { return m_iHeapPages; }
	int			GetStackPages() { return m_iStackPages; }
	unsigned long long GetTicks() { return m_ullTicks; }
	bool		Kill();
	int			Execute(const String& szExecutable, const ProcessArguments& pArguments, 
						bool bAskOnNoHandler = true,
						bool bAsk = false);
						
	void		ExecuteWithinApplicationDirectory(bool bSet);
	bool		IsCritical();
	unsigned int GetFlags() { return m_uiFlags; }
	void		SetCritical(bool bCritical);
	bool		GetApplicationPath(String &szPath);
	bool		GetApplicationDirectory(String &szDirectory);

	int			WaitFor();
	int			WaitFor(int& iExitCode);

	void		ExecuteDuplicateStdIO(bool bSet);
	void		ExecuteWantExitCode(bool bSet);

	int			ExecuteScript(const String& szScript, bool bShowConsole=false);

private:
	bool			m_bExecutesWithinApplicationDirectory;
	int				m_iPid;
	String			m_pName;
	String			m_pUser;
	String			m_pState;
	int				m_iPriority;
	int				m_iDynamicPriority;
	unsigned long long m_ullTicks;
	int				m_iHeapPages;
	int				m_iStackPages;
	String			m_pTime;
	String			m_szExecutable;
	unsigned int	m_uiFlags;
	int				m_iPGid;
	bool			m_bDupStdIO;
	bool			m_bWantExitCode;

} ;

}

#endif
