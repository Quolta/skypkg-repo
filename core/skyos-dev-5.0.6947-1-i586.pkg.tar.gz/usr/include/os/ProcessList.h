#ifndef	__INC_PROCESSLIST_H__
#define	__INC_PROCESSLIST_H__

#include <os/Object.h>
#include <os/Process.h>
#include <os/String.h>
#include <vector>

namespace SkyGI
{
class ProcessList : public Object
{
public:
	ProcessList();

	void		Refresh();
	int			Size();
	Process*	Get(int iIndex);

private:
	std::vector<Process*>   m_pProcessList;
};
}

#endif
