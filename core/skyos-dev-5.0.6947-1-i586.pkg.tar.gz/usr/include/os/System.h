#ifndef __INC_SYSTEM_H__
#define __INC_SYSTEM_H__



#include "os/Object.h"
#include "os/String.h"

enum SystemNotifyFlags
{
	SYSTEM_NOTIFY_EVENT_ACCESS=1,
	SYSTEM_NOTIFY_EVENT_HARDWARE,
	SYSTEM_NOTIFY_EVENT_IMAGE,
	SYSTEM_NOTIFY_EVENT_FILESYSTEM,
	SYSTEM_NOTIFY_EVENT_IO,
	SYSTEM_NOTIFY_EVENT_APPLICATION_ERROR,
	SYSTEM_NOTIFY_EVENT_MISC,
	SYSTEM_NOTIFY_EVENT_ISS,
	SYSTEM_NOTIFY_EVENT_USER,
	SYSTEM_NOTIFY_EVENT_HARDWARE_CHANGE_ADD,
	SYSTEM_NOTIFY_EVENT_HARDWARE_CHANGE_ADD_FAIL,
	SYSTEM_NOTIFY_EVENT_SYSTEM,

	SYSTEM_NOTIFY_EVENT_TYPE_NOTE      = 0x00000000,
	SYSTEM_NOTIFY_EVENT_TYPE_PANIC	   = 0x00010000,
	SYSTEM_NOTIFY_EVENT_TYPE_SECURITY  = 0x00020000,
	SYSTEM_NOTIFY_EVENT_TYPE_ERROR     = 0x00040000,
	SYSTEM_NOTIFY_EVENT_TYPE_WARNING   = 0x00080000,
	SYSTEM_NOTIFY_EVENT_TYPE_REPORT    = 0x00100000
}; 

enum ShutDownMode
{
	SHUTDOWN_MODE_REBOOT    = 0,
	SHUTDOWN_MODE_POWER_OFF = 1,
	SHUTDOWN_MODE_LOGOFF    = 2
};

namespace SkyGI
{
	class System : public Object
	{
	public:
		enum BuildNumberType
		{
			Kernel = 0,
			Api
		};

		System();
		bool IsSafeMode();
		bool IsLiveCD();
		bool IsVolatile();
		bool IsBranched();
		bool HasBootOption(const String& pOption);
		void Notify(unsigned int uiType, const String& szCaption, char *szFormatString, ...);
		unsigned int GetTotalMemory();
		unsigned int GetFreeMemory();
		unsigned int GetBuildNumber(BuildNumberType nBuildNumberType);

		static void DumpMemory(void *vpAddress, unsigned int uiBytes, bool bStdOut=true, bool bDebugLog=true);

		static bool Shutdown(ShutDownMode nMode);

		String GetSystemModeString();
	};
}

#endif
