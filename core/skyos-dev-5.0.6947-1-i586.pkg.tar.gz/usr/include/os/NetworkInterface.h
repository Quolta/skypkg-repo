#ifndef	__INC_NETWORKINTERFACE_H__
#define	__INC_NETWORKINTERFACE_H__

#include <os/Object.h>
#include <os/String.h>
#include <vector>

namespace SkyGI
{

class IPV4Address : public Object
{
public:
	IPV4Address();
	IPV4Address(unsigned int uiIPAddress);
	IPV4Address(const String &szIPAddress);

	unsigned int GetNumeric() const;
	String	   GetString() const ;

private:
	unsigned int m_uiAddress;
};

class EthernetAddress : public Object
{
public:
	EthernetAddress();
	EthernetAddress(unsigned char *ucEthernetAddress, int iLength);

	String		   GetString() const ;
	void		   Get(unsigned char *ucEthernetAddress, int iLength) const;

private:
	unsigned char m_ucEthernetAddress[6];
};

enum NetworkInterfaceLink
{
	NETWORK_INTERFACE_LINK_UNKNOWN    = 0,
	NETWORK_INTERFACE_LINK_DISCONNECT,
	NETWORK_INTERFACE_LINK_CONNECTED_10MBIT,
	NETWORK_INTERFACE_LINK_CONNECTED_100MBIT,
	NETWORK_INTERFACE_LINK_CONNECTED_1000MBIT,
	NETWORK_INTERFACE_LINK_CONNECTED_UNKNOWN
};

class NetworkInterface : public Object
{
public:
	NetworkInterface();
	~NetworkInterface();

	bool		IsValid();
	bool		SetTo(const String& szInterfaceName);
	bool		Refresh();
	bool		Apply();

	IPV4Address		GetIP();
	void			SetIP(const IPV4Address& nIPV4Address );
	IPV4Address		GetNetMask();
	void			SetNetMask(const IPV4Address& nIPV4Address );
	IPV4Address		GetDefaultGateway();
	void			SetDefaultGateway(const IPV4Address& nIPV4Address );
	EthernetAddress GetEthernetAddress();


	bool		Start(bool bDhcp = false, bool bDhcpAsync = false);
	bool		Stop();
	bool		IsRunning();
	bool		IsLoopBack();

	NetworkInterfaceLink GetLink();

	String		GetName();
	int			GetDhcpAsyncPid();
private:
	int			m_dhcpPid;
	bool		m_bValid;
	String      m_szInterfaceName;
	IPV4Address m_IP;
	IPV4Address m_NetMask;
	IPV4Address m_DefaultGateWay;
	unsigned int m_uiFlags;
	bool		m_bRunning;
	bool		m_bLoopBack;
	String		m_szDeviceName;

} ;

}

#endif
