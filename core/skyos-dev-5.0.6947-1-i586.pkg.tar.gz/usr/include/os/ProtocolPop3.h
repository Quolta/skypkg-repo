#ifndef __INC_ProtocolPop3_H__
#define __INC_ProtocolPop3_H__

#include "os/BufferIO.h"

namespace SkyGI
{
	class ProtocolPop3 
	{
	public:
		ProtocolPop3();
		~ProtocolPop3();

		int Connect(const String& szServer, const String& szUserName, const String& szPassword, int iPort = 110);
		int Disconnect();
		int GetMessageCount(int& iMessageCount, int& iMailboxSize);

		int WaitFor(const String& szWaitCode);
		int ClearBuffer();

		int GetMessageSize(unsigned int iMessageID, size_t &iSize);
		int GetMessage(unsigned int iMessageID, void* &vpData, size_t &iSize);

		int DeleteMessage(unsigned int iMessageID);

		signal1<bool&>		Abort;
	private:
		class Private;
		Private *m;
	};
}

#endif

