#ifndef __INC_OBJECT_H__
#define __INC_OBJECT_H__

#include "os/SignalSlot.h"
#include "os/String.h"

#define __THREAD


namespace SkyGI
{
	class Object : public SkyGI::Slot<>
	{
	public:
		Object();
		String ObjectName() { return m_pName?String(m_pName):String("<unknown>"); };
		void   SetObjectName(const char* pName) { m_pName = pName; };

	private:
		const char *m_pName;
	};
}

#endif
