#ifndef	__INC_STORAGEDEVICELIST_H__
#define	__INC_STORAGEDEVICELIST_H__

#include <os/Object.h>
#include <os/String.h>
#include <gui/Image.h>
#include <vector>

namespace SkyGI
{

enum StorageDeviceType
{
	STORAGE_DEVICE_TYPE_UNKNOWN  = 0x00000000,
	STORAGE_DEVICE_TYPE_HARDDISK = 0x00000001,
	STORAGE_DEVICE_TYPE_FLOPPY   = 0x00000002,
	STORAGE_DEVICE_TYPE_CD       = 0x00000004,
	STORAGE_DEVICE_TYPE_ALL      = 0xFFFFFFFF
};

class StorageDevice : public Object
{
public:
	StorageDevice(const String& szDevicePath);
	StorageDevice(dev_t nDevice);

	bool				IsAvailable();
	bool				IsMounted();
	static bool			IsDeviceAvailable(const String& szDevicePath);
	bool				IsBootDevice();

	bool				SupportsAttributes();
	bool				SupportsQuery();
	bool				SupportsIndex();
	bool				IsReadOnly();


	String				GetDevicePath();
	bool				GetMountPoint(String& szMountPoint);
	StorageDeviceType   GetDeviceType();
	unsigned long long  GetSize();
	unsigned long long  GetFree();
	bool				Refresh();

	Image*				GetIcon(int iSize=16);

	int					Mount(const String& szRoot, const String& szFileSystem);
	int					UnMount();

private:
	void				_Init(const String& szDevicePath);
	class Private;
	Private *m;
};

class StorageDeviceList : public Object
{
public:
	StorageDeviceList();

	std::vector<StorageDevice> Get(unsigned int nStorageDeviceTypeFilter = STORAGE_DEVICE_TYPE_ALL, 
		                           bool bIncludePartitions = true,
								   bool bMountAbleOnly = false);
	static	StorageDevice*	   Get(const String &szMountPoint);
	//std::vector<StorageDevice> GetMountable(unsigned int nStorageDeviceTypeFilter = STORAGE_DEVICE_TYPE_ALL);
		                           

private:
	class Private;
	Private *m;
};

}

#endif
