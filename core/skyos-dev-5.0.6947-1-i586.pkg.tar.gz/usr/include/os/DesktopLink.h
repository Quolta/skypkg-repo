#ifndef __INC_DESKTOPLINK_H__
#define __INC_DESKTOPLINK_H__

#include "os/Object.h"
#include "os/FileReference.h"
#include "os/String.h"

namespace SkyGI
{
	class DesktopLink : public Object
	{
	public:
		DesktopLink();
		DesktopLink(const FileReference& pFileReference);
		~DesktopLink();

		bool SetTo(const FileReference& pFileReference);
		void Unset();
		bool IsValid();

		String GetName();
		String GetExecutable();
		String GetIconPath();
		String GetWorkingFolder();
		String GetArgumentString();
		Point  GetPreferredPosition();

		void SetName(const String& szName);
		void SetExecutable(const String& szExecutable);
		void SetIconPath(const String& szIconPath);
		void SetWorkingFolder(const String& szWorkingFolder);
		void SetArgumentString(const String& szArgumentString);
		void SetPreferredPosition(const Point& pPoint);
		bool Write(const String& szPath);

		bool WriteToDesktop(const String& szLinkName = "", const String& szUser = "");
		bool WriteToPanel(const String& szLinkName = "", const String& szUser = "", bool bSetting=false);
		String GetPath();

	private:
		class Private;
		Private *m;
	};
}

#endif
