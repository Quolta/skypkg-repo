#ifndef __INC_DATAEXCHANGEPORT_H__
#define __INC_DATAEXCHANGEPORT_H__

#include <os/Object.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <gui/Window.h>

namespace SkyGI
{

class DataExchangePort : public Object
{
public:
	DataExchangePort();
	~DataExchangePort();

	bool Connect(const String& szRemotePortName);
	bool Register(const String& szPortName, bool bProcessUnique=false, bool bThreadUnique=false);
	bool DataAvailable();
	bool IsBlocking();
	void SetBlocking(bool bBlock);
	bool IsValid();
	int  GetPortID();
	int  BytesAvailable(int uiTimeOutInMsec=0);

	int  Read(void *vpData, unsigned int uiSize, unsigned int uiTimeOutInMsec = 0);
	int  Write(void *vpData, unsigned int uiSize);
	int  WriteTo(const String& szRemotePortName, void *vpData, unsigned int uiSize, bool bBroadcast = false);

	signal1<DataExchangePort*> Received;

	bool Close();

	int  Clear();

private:
	class Private;
	Private *m;
};

}

#endif
