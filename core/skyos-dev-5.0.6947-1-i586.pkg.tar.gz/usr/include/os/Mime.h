#ifndef	__INC_MIME_H__
#define	__INC_MIME_H__

#include <os/Object.h>
#include <os/String.h>
#include <gui/Image.h>
#include <vector>

namespace SkyGI
{
class MimeHandler
{
public:
	MimeHandler(const String& szPath, const String& szDescription)
	{
		m_szPath = szPath;
		m_szDescription = szDescription;
	}

	String GetPath() const { return m_szPath;};
	String GetDescription() const { return m_szDescription;};
private:
	String m_szPath;
	String m_szDescription;
};


class Mime
{
public:
	Mime();
	~Mime();

	bool GetByIndex(int iIndex);
	bool GetByExtension(const String& szExtension);
	bool GetByMimeType(const String& szMimeType);
	bool GetByPath(const String& szPath);
	bool Set(void* hMimeType);
	bool IsValid();
	String GetIconPath();
	Image* GetIcon(int iWidth=16, int iHeight=16);
	String Get();

	bool AddExtension(const String& szExtension);
	bool AddHandler(const MimeHandler& pMimeHandler);
	bool RemoveExtension(const String& szExtension);
	bool RemoveHandler(const String& szExecutable);
	bool Add(const String& szMimeType);
	bool Remove();

	bool SetIconPath(const String& szIconPath);

	std::vector<MimeHandler>   GetHandlers();
	std::vector<String>		   GetExtensions();

private:
	class Private;
	Private *m;
};

}

#endif
