#ifndef __INC_JobManager_H__
#define __INC_JobManager_H__

#include "os/Object.h"
#include "os/String.h"
#include "os/Package.h"
#include "gui/EventThread.h"
#include "os/Job.h"
#include <vector>

namespace SkyGI
{

class JobManager;

class JobThread : public Thread
{
public:
	JobThread(JobManager* pJobManager, Job *pJob);

	int Run();

	Job*	    m_pJob;
	JobManager* m_pJobManager;
};

class JobManager : public EventThread
{
public:
	JobManager();

	bool AddJob(Job *pJob);
	bool RemoveJob(Job *pJob);

	bool Work();

	void Wait();

	void SetMaximumThreads(int iThreads);

private:
	friend class JobThread;
	bool				_ProcessJob();
	void				_JobThreadFinished(JobThread *pJobThread);
	
	class Private;
	Private *m;
};


}
#endif
