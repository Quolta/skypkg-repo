#ifndef	__INC_KeyboardLayoutList_H__
#define	__INC_KeyboardLayoutList_H__

#include <os/Object.h>
#include <os/String.h>
#include <os/KeyboardLayout.h>
#include <vector>

namespace SkyGI
{

class KeyboardLayoutList : public Object
{
public:
	KeyboardLayoutList();
	~KeyboardLayoutList();

	static std::vector<KeyboardLayout> Get();

private:

} ;

}

#endif
