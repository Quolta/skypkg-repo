#ifndef __INC_CATALOG_H__
#define __INC_CATALOG_H__

#include <os/Object.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <gui/Window.h>
#include <os/DataCollection.h>
#include <os/Language.h>

namespace SkyGI
{

class Catalog : public Object
{
public:
	Catalog();

	bool Load(const String& szFilePath);
	bool LoadFromDirectory(const String &szDirectory, unsigned int uiLanguageCode);
	bool LoadFromDirectory(const String &szDirectory, const String &szLanguageCodeString);
	bool LoadFromDirectory(const String &szDirectory, Language nLanguage);

	const String& GetString(unsigned int uiStringID);

private:
	class Private;
	Private *m;
};

}

#endif
