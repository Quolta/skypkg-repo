#ifndef __INC_Job_H__
#define __INC_Job_H__

#include "os/Object.h"
#include "os/String.h"
#include "os/Package.h"
#include "gui/EventThread.h"
#include <vector>

namespace SkyGI
{

class JobManager;
class JobThread;

class Job
{
public:
	Job();
	~Job();

	void SetJobManager(JobThread *pJobThread, JobManager *pJobManager);

	virtual void Process() = 0;

	virtual void Abort();
	
	void Finish(int iErrorCode);

	int  GetErrorCode();

	bool Busy();

	bool Aborted();

	void Wait();

	signal1<Job*>			Finished;

private:
	
	class Private;
	Private *m;
};

}
#endif
