#ifndef	__INC_DirectoryWalker_H__
#define	__INC_DirectoryWalker_H__

#include <os/Object.h>
#include <os/String.h>

namespace SkyGI
{

class DirectoryWalker
{
public:
	DirectoryWalker();
	~DirectoryWalker();

	int		SetTo(const String& szPath);
	int		GetNextEntry(String &pEntry) const;

	int		GetFolderCount();
	int		GetFileCount();	

	String  Get();

private:
	class Private;

	Private *m;
};

}

#endif
