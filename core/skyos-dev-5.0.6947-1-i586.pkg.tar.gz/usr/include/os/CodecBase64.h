#ifndef __INC_CodecBase64_H__
#define __INC_CodecBase64_H__

#include "os/BufferIO.h"

namespace SkyGI
{
	class CodecBase64 
	{
	public:
		static ssize_t Decode( const char *encoded, size_t encoded_size, char **decoded );
		static ssize_t Encode( char **encoded, const char *decoded, size_t decoded_size );
	};

	class CodecQuotedPrintable
	{
	public:
		static ssize_t Decode( const char *encoded, size_t encoded_size, char **decoded );
		static ssize_t Encode( char **encoded, const char *decoded, size_t decoded_size );
	};


}

#endif

