#ifndef __INC_Repository_H__
#define __INC_Repository_H__

#include "os/Object.h"
#include "os/String.h"
#include "os/Package.h"
#include "gui/EventThread.h"
#include <vector>

namespace SkyGI
{

class RepositoryLoader : public EventThread
{
public:
	RepositoryLoader(Repository *pRepository);
	
	void Enable(bool bEnable);
	Package* GetPackage(int iIndex);
	int Size();
	void DownloadRepository();
	void ProcessPackage(const String& szPackage);
	bool    Busy();

private:
	bool				HandleMessage(const Message *pMessage);
	bool				Work();
	
	class Private;
	Private *m;
};

/** Manage software packages
 * \ingroup skygi
 * \par Description:
 *		With the Repository objects it is possible to manage local installed software as well as online software
 *		stores. Member functions include getting a list of available packages from online software stores as well
 *		as downloading and installing these packages. Futhermore it is very easy to create auto-update notifiers
 *		for your application.\n
 *		Internally the class creates a thread to not block the main thread while fetching the packages list
 *
 * \par Example:
 * \code
 *	...
 *	int i=0;
 * 	Package *pPackage;
 *
 *	Repository pRepository(Repository::ONLINE, "", "http://www.skyos.org/services/softwarestore");
 *	pRepository.FetchPackages();
 *
 *	while (pPackage = pRep.GetPackage(i++))
 *		printf("Available package: %s\n", pPackage->GetName().c_str());
 *		...
 * \endcode 
 * \sa Package
 *****************************************************************************/
class Repository
{
public:
	enum Type
	{
		LOCAL = 0,
		ONLINE
	};

	enum Error
	{
		NO_ERROR = 0,
		ERROR_CONNECT,
		ERROR_DOWNLOAD,
		ERROR_FORMAT
	};


	Repository(Type nType, const String& szName, const String& szURL, Window *pNotifyWindow=NULL, int iMessageType = 0);
	~Repository();

	String GetName();
	String GetURL();

	void   SetName(const String& szName);
	void   SetURL(const String& szURL);

	void  AddPackage(Package *pPackage);
	Package* GetPackage(int iIndex);

	void Clear();
	void FetchPackages();

	void SetStatus(Error nError, const String& szStatus);
	Error GetStatus(String &szStatus);

	Type GetType();

	void* GetCookie();
	void  SetCookie(void* pCookie);

	void  SetPackageCount(int iMaxPackages);
	void  GetPackageCount(int& iMaxPackages, int& iAvailablePackages);

	String GetPackageURL(const String& szPackageName);

	bool    Busy();


private:
	class Private;
	Private *m;
};

}

#endif
