#ifndef	__INC_NETWORKINTERFACELIST_H__
#define	__INC_NETWORKINTERFACELIST_H__

#include <os/Object.h>
#include <os/String.h>
#include <vector>

namespace SkyGI
{

class NetworkInterfaceList : public Object
{
public:
	NetworkInterfaceList();
	~NetworkInterfaceList();

	static std::vector<String> Get();

private:

} ;

}

#endif
