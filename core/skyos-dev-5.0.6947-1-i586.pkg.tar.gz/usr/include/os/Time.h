#ifndef __INC_TIME_H__
#define __INC_TIME_H__

#include "os/Object.h"
#include "os/String.h"

namespace SkyGI
{
	class Time : public Object
	{
	public:
		Time();

		static unsigned long long GetUsecCounter();
		static unsigned int       GetMsecCounter();
	};

	class Timing
	{
	public:
		Timing();

		void Reset(const char *szResult = NULL);
		void Stop(const char *szResult);
		void Result(const char *szResult);
		unsigned int GetMsec();
		unsigned long long GetUsec();
	private:
		unsigned long long m_ullStart;
		bool			   m_bStarted;
		unsigned long long m_ullEnd;
	};

}

#endif
