#ifndef __INC_PLUGIN_H__
#define __INC_PLUGIN_H__

#include <os/Object.h>

namespace SkyGI
{

class Plugin : public Object
{
public:
	Plugin(const String& szPath);
	bool	IsValid();
	void*	GetInstancedObject();
	void*	NewObject();
	String  GetPath();

private:
	class Private;
	Private *m;
};

}

#endif
