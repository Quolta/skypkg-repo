#ifndef __INC_PLUGINMANAGER_H__
#define __INC_PLUGINMANAGER_H__

#include <os/Object.h>
#include <os/Plugin.h>

namespace SkyGI
{

class PluginManager : public Object
{
public:
	PluginManager();

	int  LoadPlugins(const String &szDirectory);
	Plugin* LoadPlugin(const String &szPath);
	int Count();

	virtual Plugin* OnLoad(const String &szPath);
	virtual bool Filter(const String &szPath);

	Plugin* Get(int iIndex);

	signal2<Plugin *, const String&> Loaded;

private:
	class Private;
	Private *m;
};

}

#endif
