#ifndef __INC_Installer_H__
#define __INC_Installer_H__

#include <os/Object.h>
#include <os/String.h>
#include <os/PluginManager.h>
#include <gui/Point.h>
#include <gui/Rect.h>
#include <gui/Image.h>

namespace SkyGI
{
class Installer;


class InstallerThread : public EventThread
{
public:
	InstallerThread(Installer *pInstaller);
	bool    Busy();
	void Enable(bool bEnable);
	void AddPackage(const String& szPath);

	
private:
	bool				_Prepare();
	bool				_ExtractDescription();
	bool				_ExtractFiles();
	bool				_CreatePanelMenuEntries();

	bool				HandleMessage(const Message *pMessage);
	bool				Work();
	
	class Private;
	Private *m;
};

class Installer : public Object
{
public:
	enum Error
	{
		ERROR_OK		 = 0,
		ERROR_UNKNOWN_PACKAGE_FORMAT,
		ERROR_IO,
		ERROR_BAD_ARCHIVE,
		ERROR_INSTALLATION_DESCRIPTION_MISSING,
		ERROR_OUT_OF_DISK_SPACE,
		ERROR_ABORTED
	};

	Installer();
	~Installer();

	void AddPackage(const String& szPath);

	bool Install();

	bool Busy();

	void Abort();

	bool Aborted();

	Installer::Error GetError();

private:
	void	_SetError(Installer::Error);

	friend class InstallerThread;
	class Private;
	Private *m;

};

}

#endif
