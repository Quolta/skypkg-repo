#ifndef __INC_Variant_H__
#define __INC_Variant_H__

#include <os/Object.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <gui/Rect.h>

namespace SkyGI
{

enum VariantType
{
	VARIANT_UNDEFINED=0,
	VARIANT_BOOL,
	VARIANT_INT8,
	VARIANT_INT16,
	VARIANT_INT32,
	VARIANT_INT64,
	VARIANT_FLOAT,
	VARIANT_DOUBLE,
	VARIANT_STRING,
	VARIANT_DATA,
	VARIANT_POINT,
	VARIANT_RECT,
	VARIANT_COLOR
};

class Variant
{
public:
	Variant();
	Variant(bool      bValue);
	Variant(char      cValue);
	Variant(short     sValue);
	Variant(int		  iValue);
	Variant(long long llValue);
	Variant(float     fValue);
	Variant(double    dValue);
	Variant(const String& szString);
	Variant(const Point& pPoint);
	Variant(const Rect& rRect);
	Variant(const Color& nColor);
	Variant(void *vpData, int iSize); 
	Variant(const Variant& pVariant); 

	~Variant();

	void		Bool(bool		bValue);
	bool		Bool()  const;
	void		Int8(char       cValue);
	char		Int8()  const;
	void		Int16(short     sValue);
	short		Int16()  const;
	void		Int32(int       iValue);
	int			Int32()  const;
	void		Int64(long long llValue);
	long long	Int64()  const;
	void		Float(float     fValue);
	float		Float()  const;
	void		Double(double   dValue);
	double		Double()  const;
	void		_String(const String& szString);
	String		_String()  const;
	void		_Rect(const Rect& rRect);
	Rect		_Rect()  const;
	void		_Color(const Color& nColor);
	Color		_Color()  const;
	void		_Point(const Point& pPoint);
	Point		_Point() const;
	void		Data(void *vpData, int iSize);
	int			DataSize();
	void*		Data();

	operator bool() const;
	operator char() const;
	operator short() const;
	operator int() const;
	operator long long() const;
	operator float() const;
	operator double() const;
	operator String() const;
	operator Rect() const;
	operator Point() const;
	operator Color() const;

	Variant& operator=( bool		bValue ); 
	Variant& operator=( char		cValue ); 
	Variant& operator=( short		sValue ); 
	Variant& operator=( int			iValue ); 
	Variant& operator=( long long   llValue ); 
	Variant& operator=( float		fValue ); 
	Variant& operator=( double		dValue ); 
	Variant& operator=( const String& szString ); 
	Variant& operator=( const Rect& rRect ); 
	Variant& operator=( const Point& pPoint );
	Variant& operator=( const Color& nColor); 
	Variant& operator=( const Variant& pVariant); 

	void Invalidate();
	VariantType Type();
	void        Dump();

	void   SetName(const String& szName);
	String GetName() const;

	int    GetPackedSize() const;
	bool   Pack(void *vpBuffer, int iSize) const;
	bool   Unpack(void *vpBuffer, int iSize);

	String TypeAsString() const;

	bool   ConvertFromString(const String& szString);

private:
	int _StringToInt() const;
	VariantType enumVariantType;

	String      m_szName;

	union
	{
		bool		Bool;
		char		Int8;
		short		Int16;
		int			Int32;
		long long	Int64;
		float		Float;
		double		Double;
		char*		pString;
		struct
		{
			int l,t,r,b;
		} rRect;
		struct 
		{
			void *vpData;
			int iSize;
		} Data;
		struct
		{
			int x,y;
		} rPoint;
	} pContent;
};

}

#endif
