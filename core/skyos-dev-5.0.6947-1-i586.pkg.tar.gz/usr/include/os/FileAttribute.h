#ifndef	__INC_FILEATTRIBUTE_H__
#define	__INC_FILEATTRIBUTE_H__

#include <os/Object.h>
#include <os/String.h>
#include <gui/Image.h>

namespace SkyGI
{
#define MAKE_ATTR(a,b,c,d) (unsigned int)((a << 24) | (b<<16) | (c << 8) | d)

enum AttributeType
{
	ATTR_ANY_TYPE 					= MAKE_ATTR('A','N','Y','T'),
	ATTR_BOOL_TYPE 					= MAKE_ATTR('B','O','O','L'),
	ATTR_CHAR_TYPE 					= MAKE_ATTR('C','H','A','R'),
	ATTR_COLOR_8_BIT_TYPE 			= MAKE_ATTR('C','L','R','B'),
	ATTR_DOUBLE_TYPE 				= MAKE_ATTR('D','B','L','E'),
	ATTR_FLOAT_TYPE 				= MAKE_ATTR('F','L','O','T'),
	ATTR_GRAYSCALE_8_BIT_TYPE		= MAKE_ATTR('G','R','Y','B'),
	ATTR_INT64_TYPE 				= MAKE_ATTR('L','L','N','G'),
	ATTR_INT32_TYPE 				= MAKE_ATTR('L','O','N','G'),
	ATTR_INT16_TYPE 				= MAKE_ATTR('S','H','R','T'),
	ATTR_INT8_TYPE 					= MAKE_ATTR('B','Y','T','E'),
	ATTR_MESSAGE_TYPE				= MAKE_ATTR('M','S','G','G'),
	ATTR_MESSENGER_TYPE				= MAKE_ATTR('M','S','N','G'),
	ATTR_MIME_TYPE					= MAKE_ATTR('M','I','M','S'),
	ATTR_MONOCHROME_1_BIT_TYPE 		= MAKE_ATTR('M','N','O','B'),
	ATTR_OBJECT_TYPE 				= MAKE_ATTR('O','P','T','R'),
	ATTR_OFF_T_TYPE 				= MAKE_ATTR('O','F','F','T'),
	ATTR_PATTERN_TYPE 				= MAKE_ATTR('P','A','T','N'),
	ATTR_POINTER_TYPE 				= MAKE_ATTR('P','N','T','R'),
	ATTR_POINT_TYPE 				= MAKE_ATTR('B','P','N','T'),
	ATTR_RAW_TYPE 					= MAKE_ATTR('R','A','W','T'),
	ATTR_RECT_TYPE 					= MAKE_ATTR('R','E','C','T'),
	ATTR_REF_TYPE 					= MAKE_ATTR('R','R','E','F'),
	ATTR_RGATTR_32_BIT_TYPE 		= MAKE_ATTR('R','G','B','B'),
	ATTR_RGATTR_COLOR_TYPE 			= MAKE_ATTR('R','G','B','C'),
	ATTR_SIZE_T_TYPE	 			= MAKE_ATTR('S','I','Z','T'),
	ATTR_SSIZE_T_TYPE	 			= MAKE_ATTR('S','S','Z','T'),
	ATTR_STRING_TYPE 				= MAKE_ATTR('C','S','T','R'),
	ATTR_TIME_TYPE 					= MAKE_ATTR('T','I','M','E'),
	ATTR_UINT64_TYPE				= MAKE_ATTR('U','L','L','G'),
	ATTR_UINT32_TYPE				= MAKE_ATTR('U','L','N','G'),
	ATTR_UINT16_TYPE 				= MAKE_ATTR('U','S','H','T'),
	ATTR_UINT8_TYPE 				= MAKE_ATTR('U','B','Y','T'),
	ATTR_MEDIA_PARAMETER_TYPE		= MAKE_ATTR('B','M','C','T'),
	ATTR_MEDIA_PARAMETER_WEATTR_TYPE= MAKE_ATTR('B','M','C','W'),
	ATTR_MEDIA_PARAMETER_GROUP_TYPE = MAKE_ATTR('B','M','C','G'),

	 /* deprecated, do not use*/
	ATTR_ASCII_TYPE 				= MAKE_ATTR('T','E','X','T')	/* use ATTR_STRING_TYPE instead*/
};

class FileAttributeInfo
{
public:
	FileAttributeInfo()
	{
		Set("", ATTR_ANY_TYPE, 0);
	}
	FileAttributeInfo(const String &szName, AttributeType nAttributeType, size_t nLength )
	{
		Set(szName, nAttributeType, m_nLength);
	}

	void Set(const String &szName, AttributeType nAttributeType, size_t nLength)
	{
		m_szName		 = szName;
		m_nLength        = nLength;
		m_nAttributeType = nAttributeType;
	}

	String		  m_szName;
	size_t		  m_nLength;
	AttributeType m_nAttributeType;
};

/** FileAttribute
 * \ingroup skygi
 * \par Description:
 *		Represents a single file attribute
 *****************************************************************************/
class FileAttribute
{
public:
	FileAttribute();
	FileAttribute(const String& szAttributeName, AttributeType nAttributeType, int iLength, void *vpData);
	~FileAttribute();

public:
	String m_szAttributeName;
	int    m_nAttributeType;
	int    m_iAttributeLength;

	void*  GetData();
	void   SetData(void *vpData, int iDataSize);
	void   Keep(bool bKeep);

	Variant Get();

	void   Dump();

private:
	void  *m_vpData;
	bool m_bKeep;

};

typedef std::vector<FileAttribute> FileAttributeList;

}

#endif
