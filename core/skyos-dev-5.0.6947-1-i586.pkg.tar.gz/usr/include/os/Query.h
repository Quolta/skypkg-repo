#ifndef	__INC_QUERY_H__
#define	__INC_QUERY_H__

#include <os/Object.h>
#include <os/String.h>
#include <os/Thread.h>
#include <os/FileReference.h>

namespace SkyGI
{

class Query : public Object
{
public:
	Query();
	~Query();

	bool GetNextEntry(FileReference& pEntry);
	void Set(const String& szQueryString);
	void Rewind();
	void Abort();
	bool IsValid();

	bool Load(const FileReference& pFileReference);
	bool Save(const String& szName);
	String Get();
	String GetPath();

	String New(const String& szPath, bool bMakeUnique=false);
	String ParseQuery(const String& szQuery);
	static bool Delete(const String& szPath);

private:
	bool _HasTokens(const String& szString);
	bool _HasOperators(const String& szString);
	class Private;
	Private *m;
} ;

}

#endif
