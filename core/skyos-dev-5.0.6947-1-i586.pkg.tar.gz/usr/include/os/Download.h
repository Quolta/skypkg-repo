#ifndef __INC_Download_H__
#define __INC_Download_H__

#include "os/Object.h"
#include "os/NetworkProxy.h"
#include "os/BufferIO.h"

namespace SkyGI
{
	class Download : public Object
	{
	public:
		Download(bool bUsePrimaryProxy = true);
		virtual ~Download();

		bool Get(const String& szUrl);

		void SetDestination(BufferIO *pBufferIO);
		void SetProxy(const NetworkProxy *pNetworkProxy);

		bool IsDownloading();
		int  GetError();

		void Abort();
		bool Aborted();
		void Reset();

		int						    OnDataAvailable(void *vpData, int iSize)					__THREAD;
		void						OnProgress(float fPercent, double dTotal, double dNow)		__THREAD;

		signal3<Download*, void*, int>				DataAvailable								__THREAD;
		signal4<Download*, float, double, double>	Progress									__THREAD;

	private:
		void SetError(int iError);


		class Private;
		Private *m;

	};
}

#endif
