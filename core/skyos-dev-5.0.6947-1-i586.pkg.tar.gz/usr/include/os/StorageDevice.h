#ifndef	__INC_STORAGEDEVICE_H__
#define	__INC_STORAGEDEVICE_H__

#include <os/StorageDeviceList.h>

#endif
