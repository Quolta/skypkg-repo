#ifndef __INC_MemoryFile_H__
#define __INC_MemoryFile_H__

#include "os/SeekIO.h"

namespace SkyGI
{
	class MemoryFile : public SeekIO
	{
	public:
		MemoryFile(void *vpData = NULL, int iSize = 0);
		virtual ~MemoryFile();

		virtual bool IsValid();

		virtual ssize_t Read(void *vpBuffer, ssize_t iBytes);
		virtual ssize_t Write(const void *vpBuffer, ssize_t iBytes);

		virtual ssize_t ReadAt(off_t offPosition, void *vpBuffer, ssize_t iBytes);
		virtual ssize_t WriteAt(off_t offPosition, const void *vpBuffer, ssize_t iBytes);

		virtual off_t Seek(off_t offPosition, int iWhence);
		virtual off_t Tell();

		off_t				GetSize() const;

		int                 SetBufferSize(int iBufferSize);
		int				    GetBufferSize();

	private:
		class Private;
		Private *m;
	};


}

#endif
