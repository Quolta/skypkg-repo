#ifndef	__INC_FILEREFERENCE_H__
#define	__INC_FILEREFERENCE_H__

#include <os/Object.h>
#include <os/String.h>
#include <os/FileAttribute.h>
#include <gui/Image.h>

namespace SkyGI
{
typedef int MonitorID;

enum MonitorFlags
{
	MONITOR_FLAG_CREATED_IN_DIRECTORY			= 0x00000001,
	MONITOR_FLAG_CHANGED						= 0x00000002,
	MONITOR_FLAG_DELETED						= 0x00000004,
	MONITOR_FLAG_ATTRIBUTE_CHANGED				= 0x00000008,
	MONITOR_FLAG_DELETED_IN_DIRECTORY			= 0x00000010,
	MONITOR_FLAG_CHANGING						= 0x00000020,
	MONITOR_FLAG_CHANGING_IN_DIRECTORY			= 0x00000040,
	MONITOR_FLAG_CHANGED_IN_DIRECTORY			= 0x00000080,
	MONITOR_FLAG_ATTRIBUTE_CHANGED_IN_DIRECTORY = 0x00000100,
	MONITOR_FLAG_CREATED						= 0x00000200,

	MONITOR_FLAG_ALL							= 0xFFFFFFFF

};
/** FileReference
 * \ingroup skygi
 * \par Description:
 * A filereference is a logical reference to a filesystem node. Use this class to get node stats,
 * file icons or monitor file changes.
 *****************************************************************************/
class FileReference
{
public:
	FileReference(const String& cDirectory, const String& cFileName);
	FileReference(const String& pPath);
	FileReference();
	FileReference(const FileReference &pFileReference);
	FileReference(const String& szRoot, const String& szFileName, ino_t ino );
	FileReference(const String& szRoot, ino_t ino);
	FileReference(dev_t nDevice, ino_t ino);
	~FileReference();

	void				SetTo(const String& cPath);
	void				ConstructPath(const char* pFirstPart, ...);
	String				GetPath() const;
	Image*				GetFileIcon(int iSize = 16)  const;
	String				GetFileIconPath(int iSize = 16)  const;
	int					Stat(struct stat *st)  const;
	bool				IsDirectory()  const;
	bool				IsRegular()  const;
	bool				IsLink() const;
	virtual bool		IsValid() const;
	bool				IsQuery() const;
	bool				IsDesktopLink() const;
	String				GetFileType()  const;
	String				GetLast()  const;
	String				CutLast() const;
	MonitorID			Monitor(Window *pTarget, unsigned int uiMonitorFlags)  const;
	void				StopMonitor()  const;
    FileReference&		operator=( const FileReference& pFileReference );
	bool				operator==( const FileReference& pFileReference ) const;
	bool				operator==( const String &szPath) const;
	String				GetExtension() const;
	String				GetFileName() const;
	void				Normalize();
	static String       Normalize(const String &szPath);
	off_t				GetSize() const;
	time_t				GetAccessTime() const;
	time_t				GetCreateTime() const;
	time_t				GetModifyTime() const;

	bool				GetNextAttributeEntry(FileAttributeInfo& pAttributeInfo);
	FileAttribute*		ReadAttribute(const String& szAttributeName, AttributeType nAttributeType, off_t nPos, int iLength) const;
	size_t				ReadAttribute(const String& szAttributeName, AttributeType nAttributeType, void *vpBuffer, off_t nPos, int iLength);
	size_t				WriteAttribute(const String& szAttributeName, AttributeType nAttributeType, const void *pBuffer, off_t nPos, int iLength);
	bool				RemoveAttribute(const String& szAttributeName);
	void				RewindAttribute();

	Variant				GetAttribute(const String& szAttributeName) const;
	Variant				GetAttributeAndType(const String& szAttributeName, AttributeType& nAttributeType) const;
	AttributeType		GetAttributeType(const String& szAttributeName) const;
	

	String				GetMimeType() const;
	bool				SetMimeType(const String& szMimeType);
	bool				ReadMimeTypeAttribute(String &szMimeType) const;

	bool				Identify(bool bForce = false, bool bWait = false);

	static String		MakePath(const char* pFirstPart, ...);

	static String		MakeRelativePath(const String& szPath, const String& szRelativeTo);

private:
	class Private;

	Private *m;
};

}

#endif
