#ifndef __INC_LOCALIZEDSTRING_H__
#define __INC_LOCALIZEDSTRING_H__

#include <os/Object.h>
#include <os/Catalog.h>

namespace SkyGI
{

class LocalizedString : public String
{
public:
	LocalizedString(unsigned int uiStringID);
	LocalizedString(unsigned int uiStringID, Catalog *pCatalog);
};

}

#endif

