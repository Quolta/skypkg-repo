#ifndef __INC_BufferIO_H__
#define __INC_BufferIO_H__

#include "os/Object.h"

namespace SkyGI
{
	class BufferIO
	{
	public:
		BufferIO();
		virtual ~BufferIO();

		virtual ssize_t Read(void *vpBuffer, ssize_t iBytes) = 0;
		virtual ssize_t Write(const void *vpBuffer, ssize_t iBytes) = 0;
	};
}

#endif
