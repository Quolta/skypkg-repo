#ifndef __INC_Service_H__
#define __INC_Service_H__

#include <os/Object.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <gui/Window.h>
#include <os/DataCollection.h>
#include <os/DesktopCommunication.h>

namespace SkyGI
{

enum enumServiceStartMode
{
	MANUAL_START=0,
	ON_SYSTEM_START
};
	
/** ServiceManager communication class
 * \ingroup skygi
 *
 * This class is used internally to connect to the service manager
 **************************************************************************************************************/
class ServiceManagerInterface
{
public:
	ServiceManagerInterface();
	~ServiceManagerInterface();

	static ServiceManagerInterface* Get();
	bool   IsValid();

	bool SendMessage(DesktopCommunicationMessage* pMessage);
	DesktopCommunicationMessage* NewMessage(const String& szType, int& uiTransactionID);
	DesktopCommunicationMessage* WaitMessage(int iTimeoutInMsecs, int uiTransactionID);
private:
	class Private;
	Private *m;
};

class ServiceInterface : public Object
{
public:
	ServiceInterface(const String& szServiceName);
	~ServiceInterface();

	bool   Start();
	bool   Stop();
	bool   IsRunning();
	String GetName();
	Image* GetIcon(int iSize);
	String GetInfo();
	enumServiceStartMode    GetStartMode();
	bool					SetStartMode(enumServiceStartMode nStartMode);

	bool   IsConfigurable();
	bool   MustBeConfigured();
	bool   StartConfiguration();

private:
	class Private;
	Private *m;
};

class ServiceManager
{
public:
	ServiceManager();
	~ServiceManager();

	static std::vector<String> GetServiceList(); 
};

}

#endif
