#ifndef __INC_SeekIO_H__
#define __INC_SeekIO_H__


#include "os/BufferIO.h"

namespace SkyGI
{
	class SeekIO : public BufferIO
	{
	public:
		SeekIO();
		virtual ~SeekIO();

		virtual ssize_t ReadAt(off_t nPos, void *vpBuffer, ssize_t iBytes) = 0;
		virtual ssize_t WriteAt(off_t nPos, const void *vpBuffer, ssize_t iBytes) = 0;
		virtual off_t Seek(off_t nPos, int iWhence) = 0;
		virtual off_t Tell() = 0;
		virtual off_t GetSize() const = 0;
	};
}

#endif

