#ifndef __INC_DATACOLLECTION_H__
#define __INC_DATACOLLECTION_H__

#include <os/Object.h>
#include <os/Variant.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <gui/Window.h>

namespace SkyGI
{

enum DataCollectionFlags
{
	DATACOLLECTION_FLAG_USER_LOCAL = 0x00000001,
	DATACOLLECTION_FLAG_OWN_PATH   = 0x00000002,
	DATACOLLECTION_FLAG_MUST_EXIST = 0x00000004
};

class DataCollection : public Object
{
typedef struct sSerializedHeader
{
	unsigned int uiMagic;
	int			 iHeaderSize;
	int			 iItems;
	int			 iVersion;
} sSerializedHeader;

typedef struct sSerializedItemHeader
{
	int			  iSizeOfStructureOnDisk;
	int			  iType;
	int			  iSize;
	char		  szKey[255];
} sSerializedItemHeader;

public:
	DataCollection();
	DataCollection(void *vpPackedData, int iPackedSize);
	~DataCollection();

	void		Add(const String& cKey, const Variant& pVariant);
	void		Set(const String& cKey, const Variant& pVariant);

	bool		Get(const String& cKey, Variant& pVariant, int iIndex = 0);
	bool		Get(const String& cKey, String& cString, int iIndex = 0);
	bool		Get(const String& cKey, int& iValue, int iIndex = 0);
	bool		Get(const String& cKey, long long& llValue, int iIndex = 0);
	bool		Get(const String& cKey, bool& bBool, int iIndex = 0);
	bool		Get(const String& cKey, Color& nColor, int iIndex = 0);

	bool		Has(const String& cKey, int iIndex = 0);
	bool		Remove(const String& cKey, int iIndex = 0);
	void*		Pack(int& iSize) const;
	bool		Unpack(void *vpPackedData, int iPackedSize);
	bool		IsValid();

	bool		Load(const String& szVendorName, const String& szApplicationName, const String& szDataCollectionName, unsigned int uiDataCollectionFlags);
	bool		Write(const String& szVendorName, const String& szApplicationName, const String& szDataCollectionName, unsigned int uiDataCollectionFlags);
	static bool	Exists(const String& szVendorName, const String& szApplicationName, const String& szDataCollectionName, unsigned int uiDataCollectionFlags);
	static bool IsDataCollection(const String& szVendorName, const String& szApplicationName, const String& szDataCollectionName, unsigned int uiDataCollectionFlags);

	void		Clear();

	void*		GetNative();
	void		SetNative(void *vpData);

	Variant		GetVariant(const String& cKey, int iIndex=0);

	void		Dump();

	bool		Get(int iIndex, String& szName, Variant& pVariant);
	bool		True(const String& cKey, int iIndex = 0);

	bool		Attach(const String& szVendorName, const String& szApplicationName, const String& szDataCollectionName, unsigned int uiDataCollectionFlags);


private:
	bool		_SerializeFromFile(const String& szPath, bool bClear);
	bool		_SerializeToFile(const String& szPath);
	bool		_Add(const String& cKey, const Variant& pVariant, bool bOverwrite);
	char*		_AddPackedData(char *pBuffer, void *pData, int iSize, int &iOffset, int& iBufferSize) const;
	class Private;
	Private *m;
};

}

#endif
