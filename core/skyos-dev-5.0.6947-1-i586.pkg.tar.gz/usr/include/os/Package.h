#ifndef __INC_Package_H__
#define __INC_Package_H__

#include "os/Object.h"
#include "os/String.h"
#include "os/File.h"
#include "os/Archiver.h"
#include "gui/Image.h"
#include <vector>


namespace SkyGI
{
	class Repository;

	class PackageDescriptionPanelEntry
	{
	public:
		String m_szMenu;
		String m_szFile;
		String m_szName;
		String m_szLink;
		String m_szArgument;
		String m_szFolder;
		String m_szIcon;
		String m_szType;
	};

	class PackageDescriptionFileIcons
	{
	public:
		String m_szFile;
		String m_szIcon;
	};

	class PackageDescriptionAttributes
	{
	public:
		String m_szFile;
		String m_szName;
		String m_szType;
		String m_szValue;
	};

	class PackageDescription
	{
	public:
		PackageDescription();
		~PackageDescription();

		bool SetFromBuffer(const String& szBuffer);
		bool ReadFromFile(const String& szPath);

		bool WriteToFile(const String& szPath);

		void Clear();

		bool IsValid();

		// ------

		String GetProduct();
		String GetDetail();
		String GetVersion();
		String GetDate();
		String GetLicense();
		String GetCategory();
		String GetSoftwareStoreDescription();

		bool GetPanelMenuEntries(std::vector<PackageDescriptionPanelEntry> &arrPanelEntries);
		bool GetFileIconEntries(std::vector<PackageDescriptionFileIcons> &arrFileEntries);
		bool GetAttributeEntries(std::vector<PackageDescriptionAttributes> &arrAttributeEntries);
		void   Dump();
	private:
		bool _Write(File *pFile, const String& szString);
		bool _WriteSection(File *pFile, const String& szSection);
		bool _WriteKey(File *pFile, const String& szKey, const String& szString);
		bool _WriteKeyEmpty(File *pFile, const String& szKey, const String& szString);

		bool _Parse(const String& szContent);
		bool _ParseGetSection(void *hHandle, const String& szSection);
		bool _ParseGet(void *hHandle, const String& szKey, String& szString);
		bool _ParseGetLine(void *hHandle, const String& szUntil, String& szString);

		class Private;
		Private *m;
	};

	class Package : public Object
	{
	public:
		enum Error
		{
			ERROR_OK		 = 0,
			ERROR_UNKNOWN_PACKAGE_FORMAT,
			ERROR_IO,
			ERROR_BAD_ARCHIVE,
			ERROR_INSTALLATION_DESCRIPTION_MISSING,
			ERROR_OUT_OF_DISK_SPACE,
			ERROR_ABORTED,
			ERROR_INSTALLATION_DESCRIPTION_PARSE_FAILED
		};

		enum Action
		{
			CREATE_DIRECTORY,
			CREATE_LINK,
			CREATE_FILE,
			WRITE_FILE,
			CREATE_PANEL_ENTRY,
			WRITE_FILE_ATTRIBUTE,
			UNKNOWN
		};

		Package();
		virtual ~Package();

		virtual bool				 SetPackageDescription(const String& szDescription);
		virtual bool				 SetPackageDescriptionFromFile(const String& szPath);
		virtual PackageDescription*  GetPackageDescription();
		
		virtual void				 SetImageFromFile(const String& szPath);
		virtual Image*				 GetImage();
		
		virtual void				 SetName(const String& szName);
		virtual String				 GetName();

		void	SetCookie(void *pCookie);
		void*   GetCookie();

		// Installation
	public:
		bool						 Open(const String& szPath);
		bool						 SetRoot(const String& szRoot);
		Package::Error				 GetError();
		bool						 ExtractFiles();
		bool						 WriteFileIcons();
		bool						 WriteAttributes();
		bool						 WritePanelEnties();
		void						 Abort();
		bool						 Aborted();
		void						 Reset();
		bool						 Busy();
		bool						 Install();
		bool						 GetPackageSize(off_t& llSize);
		bool						 GetProgressTotal(off_t& llSize, off_t& llTotalSize);
		bool						 RegisterPackage();


		static bool					 IsInstalled(const String& szPackage);
		static std::vector<Package*> GetInstalledPackages();
	private:
		void						 _SetError(Package::Error);


		// Repository
	public:
		Repository *				 GetRepository();
		void						 SetRepository(Repository *pRepository);

		// callbacks, signals
	public:
		virtual bool OnProcessEntry(Package::Action nAction, 
									const String& szFile,
									const String& szAttribute,
									off_t iSize, off_t iTotalSize);
		virtual bool OnError(Package::Action nAction, 
									const String& szFile,
									const String& szAttribute,
									off_t iSize, off_t iTotalSize);

		signal6<Package *, Package::Action, const String&, const String&, off_t, off_t>	_Process;
		signal6<Package *, Package::Action, const String&, const String&, off_t, off_t>	_Error;

		// General
	private:
		void _ArchiveOnProcessEntry(Archiver* pArchiver, Archiver::Action nAction, const ArchiveEntry &nEntry, off_t iSize, off_t iTotalSize);
		void _ArchiveOnError(Archiver* pArchiver, Archiver::Action nAction, const ArchiveEntry &nEntry, off_t iSize, off_t iTotalSize);

		class Private;
		Private *m;
	};

	
}

#endif
