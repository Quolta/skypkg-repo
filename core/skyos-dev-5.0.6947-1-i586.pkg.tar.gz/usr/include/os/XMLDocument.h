#ifndef	__INC_XMLDOCUMENT_H__
#define	__INC_XMLDOCUMENT_H__

#include <os/Object.h>
#include <os/String.h>
#include <gui/Image.h>
#include <vector>

namespace SkyGI
{

class XMLNode
{
public:
	XMLNode();
	XMLNode(void *_node);

	void SetTo(void *_node);

	bool AddProperty(const String& szName, const String& szValue);
	bool GetPropertyValue(const String& szProperty, String& szValue);
	bool GetNextProperty(String& szProperty, String& szValue);

	bool GetChild(XMLNode &pNode);
	bool GetNextChild(XMLNode &pNode);
	bool GetNext(XMLNode &pNode);

	void Rewind();

	String	Name() const;
	String	Content() const;

	void* GetNode() const;


private:
	void* node;
	void* node_iter;
	void* node_child_iter;

	void* node_property_iter;
};

class XMLDocument
{
public:
	XMLDocument();
	~XMLDocument();

	bool New(const String& szRoot, XMLNode& pRootNode);

	bool Load(const String& szPath);
	bool Save(const String& szPath);

	bool AddNode(const XMLNode& pParent, const String& szName, XMLNode &pNode, const String& szContent="");

	bool    GetRootNode(XMLNode& pNode);


private:
	class Private;
	Private *m;
};

}

#endif
