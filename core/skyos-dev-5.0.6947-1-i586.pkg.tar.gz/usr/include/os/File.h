#ifndef __INC_File_H__
#define __INC_File_H__

#include "os/SeekIO.h"
#include "os/FileReference.h"

namespace SkyGI
{
	class File : public SeekIO, public FileReference
	{
	public:
		File();
		File(const String& szPath, int iMode = O_RDONLY);
		File(const FileReference& pFileReference, int iMode = O_RDONLY);
		virtual ~File();

		virtual bool IsValid();

		virtual ssize_t Read(void *vpBuffer, ssize_t iBytes);
		virtual ssize_t Write(const void *vpBuffer, ssize_t iBytes);

		virtual ssize_t ReadAt(off_t offPosition, void *vpBuffer, ssize_t iBytes);
		virtual ssize_t WriteAt(off_t offPosition, const void *vpBuffer, ssize_t iBytes);

		virtual off_t Seek(off_t offPosition, int iWhence);
		virtual off_t Tell();

		virtual int   Flush();

		off_t				GetSize() const;
		int                 SetBufferSize(int iBufferSize);
		int				    GetBufferSize();
	
	private:
		virtual int   _ReFill(off_t offPosition);

		class Private;
		Private *m;
	};

	class FileReader
	{
	public:
		static ssize_t Read(const String& szPath, String& szBuffer);
		static ssize_t Read(const String& szPath, char **ppBuffer);
		static ssize_t Read(SeekIO& pIO, String &szBuffer);
		static ssize_t Read(SeekIO& pIO, char **ppBuffer);
	};

}

#endif
