#ifndef	__INC_SpellCheck_H__
#define	__INC_SpellCheck_H__

#include <os/Object.h>
#include <os/String.h>
#include <gui/Image.h>
#include <vector>

namespace SkyGI
{

class SpellCheck
{
public:
	SpellCheck();
	~SpellCheck();

	bool IsCorrect(const String& szWord);
	std::vector<String> GetSuggestions(const String& szWord);


private:
	class Private;
	Private *m;
};

}

#endif
