#ifndef __INC_ProtocolSmtp_H__
#define __INC_ProtocolSmtp_H__

#include "os/BufferIO.h"

namespace SkyGI
{
	class ProtocolSmtpMessage
	{
	public:
		ProtocolSmtpMessage();
	
		int SetMessage(const String& szMessage);
		int SetSender(const String& szSender);
		int AddRecipiant(const String& szSendTo);
	
	private:
		friend class ProtocolSmtp;
		class Private;
		Private *m;
	};

	class ProtocolSmtp 
	{
	public:
		ProtocolSmtp();
		~ProtocolSmtp();

		int Connect(const String& szServer, const String& szUserName, const String& szPassword, int iPort = 25);

		int WaitFor(const String& szWaitCode, int iDelay = 0);
		int ClearBuffer();

		int Send(const ProtocolSmtpMessage& pMessage);
	private:
		int _ConnectAsSMTP();
		int _ConnectAsESMTP();
		int _Authenticate();
		int _AuthenticatePlain();
		int _AuthenticateLogin();
		int _AuthenticateESMTP(const char *pBuffer);

		int write_data(int fd, const void *data, int length);

		class Private;
		Private *m;
	};
}

#endif

