#ifndef	__INC_DIRECTORY_H__
#define	__INC_DIRECTORY_H__

#include <os/Object.h>
#include <os/String.h>

namespace SkyGI
{

enum PredefinedDirectoryID
{
	PREDEFINED_DIRECTORY_USERBASE = 0,
	PREDEFINED_DIRECTORY_SYSTEM_SETTINGS ,
	PREDEFINED_DIRECTORY_APPLICATION_DATA,
	PREDEFINED_DIRECTORY_TEMP ,
	PREDEFINED_DIRECTORY_DESKTOP ,
	PREDEFINED_DIRECTORY_PANEL_PROGRAM ,
	PREDEFINED_DIRECTORY_PANEL_SETTINGS ,
	PREDEFINED_DIRECTORY_STARTUP ,
};

class Directory
{
public:
	Directory();
	~Directory();

	int		SetTo(const String& szPath);
	int		Predefined(unsigned int uiPredefinedDirectoryID, const char *pLoginName = NULL);
	int		GetNextEntry(String &pEntry) const;
	int		Rewind();
	String  Get() const;
	int     Create(const String& szPath, bool bRecursive = false);
	int     Close();

private:
	class Private;

	Private *m;
};

}

#endif
