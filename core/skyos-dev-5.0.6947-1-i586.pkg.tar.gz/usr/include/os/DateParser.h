#ifndef __INC_DateParser_H__
#define __INC_DateParser_H__

#include "os/Object.h"
#include "os/String.h"

namespace SkyGI
{
	class DateParser : public Object
	{
	public:
		DateParser();

		static time_t Parse(const String& szString);
	};

}

#endif
