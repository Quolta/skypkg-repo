#ifndef __INC_NOTIFICATION_H__
#define __INC_NOTIFICATION_H__

#include <os/Object.h>

namespace SkyGI
{

class Notification : public Object
{
public:
	Notification(const String& szSource, const String &szShort, const String& szLong);
	~Notification();

	void EmitAsWarning();
	void EmitAsNote();
	void EmitAsError();
	void EmitAsSecurity();

private:
	class Private;
	Private *m;
};

}

#endif
