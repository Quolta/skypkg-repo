#ifndef	__INC_WINDOWTHREAD_H__
#define	__INC_WINDOWTHREAD_H__

#include <os/Thread.h>

namespace SkyGI
{

/** Thread
 * \ingroup skygi
 * \par Description:
 *		This virtual base class can be used to create threads. 
 * \par Note:
 *		This thread class will handle windows, meaning the if you create windows from within this thread, the thread itself is resposible for
 *		handling its MessageQueue.
 *
 * \par Example:
 * \code
 *		class MyThread : public Thread
 *		{
 *		public:
 *			MyThread();
 *			int Run() { printf("Hello from thread!\n");
 *		};
 *
 *		MyThread::MyThread() : Thread("mythread") {};
 *
 *		...
 *		MyThread *pThread = new MyThread();
 *		MyThread->Start();
 *		...
 * \endcode
 * \sa
 *		WindowThread, WindowThread::GetMessageQueue, MessageQueue
 *****************************************************************************/
class WindowThread : public Thread
{
public:
	WindowThread(const String& szName);
	~WindowThread();

	MessageQueue *GetMessageQueue();

	class Private;
	Private *m;

private:
	static int	  _WindowThreadEntry(WindowThread *pThread, unsigned int uiFlags);
};

}

#endif
