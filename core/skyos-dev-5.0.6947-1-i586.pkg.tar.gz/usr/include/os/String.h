#ifndef __INC_STRING_H__
#define __INC_STRING_H__

#include <string>
#include <stdarg.h>

namespace SkyGI
{
class String
{
public:
    typedef std::string::iterator iterator;
    typedef std::string::const_iterator const_iterator;
    enum { iPos = -1 };
public:
    String();
    String( int iLen, char iFiller );
    String( const char* pString );
    String( const char* pString, int iLen );
    String( const std::string& cString );
    String( const std::string& cString, int iPos, int iLen );
    String( const String& cString );
    String( const String& cString, int iPos, int iLen );
    String( const_iterator cBegin, const_iterator cEnd );
    
    size_t	Length() const;
    size_t	CountChars() const;
    
    String& Resize( int iNewLen );

    
    String& Format( const char* pFormat, va_list pArgs );
    String& Format( const char* pFormat, ... );

    String& Strip();
    String& LStrip();
    String& RStrip();

    String& Lower();
    String& Upper();
    
    int	Compare( const char* pString ) const;
    int	Compare( const std::string& cOther ) const;
    int	Compare( const String& cOther ) const;

    int CompareNoCase( const char* pString ) const;
    int CompareNoCase( const std::string& cOther ) const;
    int CompareNoCase( const String& cOther ) const;

    int	CompareN( const char* pString, int iLen ) const;
    int	CompareN( const std::string& cOther , int iLen) const;
    int	CompareN( const String& cOther, int iLen ) const;

    int CompareNoCaseN( const char* pString, int iLen ) const;
    int CompareNoCaseN( const std::string& cOther, int iLen ) const;
    int CompareNoCaseN( const String& cOther, int iLen ) const;

    String& operator=( const char* pString );
    String& operator=( const std::string& cString );
    String& operator=( const String& cString );
    
    String& operator+=( const char* pString );
    String& operator+=( const char nChar );
    String& operator+=( const std::string& cString );
    String& operator+=( const String& cString );
    
    String operator+( const char* pString ) const;
	String operator+( const char nChar ) const;
    String operator+( const std::string& cString ) const;
    String operator+( const String& cString ) const;

    bool operator==( const char* pString ) const;
    bool operator==( const std::string& cString ) const;
    bool operator==( const String& cString ) const;

    bool operator!=( const char* pString ) const;
    bool operator!=( const std::string& cString ) const;
    bool operator!=( const String& cString ) const;

    bool operator<( const char* pString ) const;
    bool operator<( const std::string& cString ) const;
    bool operator<( const String& cString ) const;

    bool operator>( const char* pString ) const;
    bool operator>( const std::string& cString ) const;
    bool operator>( const String& cString ) const;

    char  operator[]( size_t iPos ) const;
    char& operator[]( size_t iPos );
    
    operator const std::string&() const;
    std::string& str();
    const std::string& const_str() const;

public: 
    const char* c_str() const;
    iterator begin();
    iterator end();
    const_iterator begin() const;
    const_iterator end() const;
    size_t	   size() const;
    bool	   empty() const;
    void	   resize( size_t iLen );
    void	   resize( size_t iLen, char iFiller );
    void	   reserve( size_t iLen );

    String& 	erase( size_t iPos = 0, size_t iLen = iPos );
    iterator 	erase( iterator i );
    iterator 	erase( iterator cFirst, iterator cLast );

	String		substr( size_t iPos = 0, size_t iLen = iPos ) const;

    size_t		find( const String& cStr, size_t iPos = 0 ) const;

    size_t		findNoCase( const String& cStr, size_t iPos = 0 ) const;

	size_t		insert(size_t iPos, const char *str);
	size_t		insert(size_t iPos, const String& pString);

	void		replace(size_t iPos, size_t iLen, const String& s);
	String		Replace(const String& szFind, const String& szReplace);

	void		AssignAndRemoveChars(const char *str, int iLen, const char *chars);

private:
    std::string m_cString;
};

}

#endif

