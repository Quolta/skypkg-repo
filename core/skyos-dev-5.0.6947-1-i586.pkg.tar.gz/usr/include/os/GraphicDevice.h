#ifndef __INC_GraphicDevice_H__
#define __INC_GraphicDevice_H__

#include "os/Object.h"
#include "os/String.h"
#include "gui/Point.h"
#include <vector>

namespace SkyGI
{
	class GraphicMode : public Object
	{
	public:
		GraphicMode(const Point& pResolution, int iBPP, int iRefreshRate = 60);

		Point Resolution() const;
		int   BitsPerPixel() const;
		int   RefreshRate() const;
	private:
		class Private;
		Private *m;
	};

	class GraphicDevice : public Object
	{
	public:
		GraphicDevice(const String& szGraphicDeviceName);
		~GraphicDevice();

		std::vector<GraphicMode> GetAvailableModes();
		std::vector<int> GetAvailableRefreshRates();

		bool		IsActive();
		GraphicMode GetActiveMode();
		bool		SetMode(const GraphicMode& pGraphicMode);
		String		GetDeviceName();
		String		GetDriverName();
		bool		IsValid();

		static GraphicDevice *GetActive();

	private:
		class Private;
		Private *m;
	};

	class GraphicDeviceList : public Object
	{
	public:
		GraphicDeviceList();
		~GraphicDeviceList();

		static std::vector<String> GetGraphicDevices();
	};


}

#endif
