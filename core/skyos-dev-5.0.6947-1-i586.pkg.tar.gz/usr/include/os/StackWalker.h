#ifndef __INC_StackWalker_H__
#define __INC_StackWalker_H__

#include "os/Object.h"

namespace SkyGI
{
	class StackWalker : public Object
	{
	public:
		StackWalker();

		static void DumpToStdOut(int iMaxLevels = -1);
		static void DumpToDebugLog(int iMaxLevels = -1);
	};
}

#endif
