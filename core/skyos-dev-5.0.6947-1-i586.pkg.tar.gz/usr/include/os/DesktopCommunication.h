#ifndef __INC_DESKTOPCOMMUNICATION_H__
#define __INC_DESKTOPCOMMUNICATION_H__

#include <os/Object.h>
#include <os/DataCollection.h>
#include <os/Variant.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <gui/Window.h>

namespace SkyGI
{

class DesktopCommunicationInterface;

class DesktopCommunicationMessage : public Object
{
public:
	DesktopCommunicationMessage(const String& szType);
	DesktopCommunicationMessage(DataCollection *pDataCollection);
	~DesktopCommunicationMessage();

	DataCollection *GetDataCollection();

	void		Add(const String& cKey, const Variant& pVariant);
	void		Set(const String& cKey, const Variant& pVariant);

	bool		Get(const String& cKey, Variant& pVariant, int iIndex=0);
	bool		Get(const String& cKey, String& cString, int iIndex = 0);
	bool		Get(const String& cKey, int& iValue, int iIndex = 0);
	bool		Get(const String& cKey, long long& llValue, int iIndex = 0);

	Variant     GetVariant(const String& cKey, int iIndex=0);

	bool		Ok();
	bool		Failed();
	int			GetErrorCode();

	void*		GetNative();
	void		SetNative(void *vpData);

	void		SetSender(const String& szString);
	String		GetSender(void);

	bool		SenderIsWaiting();

	bool		Send(DesktopCommunicationInterface *pInterface, const String& szDestinationInterfacePath, bool bWantReply = false);
	bool		Send(const String& szDestinationInterfacePath, bool bWantReply = false);
	DesktopCommunicationMessage* Wait(DesktopCommunicationInterface *pInterface, int iTimeOutInMsecs=0);
	DesktopCommunicationMessage* Wait(int iTimeOutInMsecs=0);

	bool		Reply(DesktopCommunicationInterface *pInterface, DesktopCommunicationMessage &pMessage, int ErrorCode);
	bool		Reply(const String& szDestinationInterfacePath, int ErrorCode);
	bool		Reply(DesktopCommunicationMessage *pMessage, int ErrorCode);


	void		Dump();
private:
	class Private;
	Private *m;
};

#include "os/DesktopCommunicationFunction.h"


class DesktopCommunicationInterface : public Object
{
public:
	DesktopCommunicationInterface(const String& szInterfacePath,  bool bThreadUnique=false);
	~DesktopCommunicationInterface();

	bool IsValid();
	void SetBlocking(bool bBlock);
	bool SendMessage(const String& szDestinationInterfacePath, DesktopCommunicationMessage *pMessage, bool bWantReply = false);

	DesktopCommunicationMessage *Wait(int iTimeOutInMsecs = 0);

	int GetDataExchangePortID();

	bool Idle();

	void Clear();

	virtual void OnReceived(DesktopCommunicationMessage *pMessage);
	signal2<DesktopCommunicationInterface*, DesktopCommunicationMessage*> Received;

	std::vector<DesktopCommunicationFunctionBase*> pDesktopCommunicationFunctions;

	bool RegisterFunction(DesktopCommunicationFunctionBase *pFunction);

	bool ProcessFunctions(DesktopCommunicationMessage *pMessage);

private:
	void		_Parse(DataCollection *pDataCollection, char *str);
	class Private;
	Private *m;
};

}

#endif
