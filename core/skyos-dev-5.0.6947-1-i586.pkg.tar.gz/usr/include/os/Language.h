#ifndef __INC_LANGUAGE_H__
#define __INC_LANGUAGE_H__

#include <os/Object.h>
#include <gui/Point.h>
#include <gui/Color.h>
#include <gui/Window.h>
#include <os/DataCollection.h>

namespace SkyGI
{

class Language : public Object
{
public:
	Language();
	Language(unsigned int uiLanguageCode);
	Language(const String& szLanguageCodeString);

	static Language GetActive();
	static std::vector<Language> GetLanguages();

	void SetTo(const String& szLanguageCodeString);
	void SetTo(unsigned int uiLanguageCode);
	unsigned int   GetLanguageCode();
	unsigned short GetLanguage();
	unsigned short GetCountry();
	String GetLanguageCodeString();
	String GetLanguageString();
	String GetCountryString();
	String GetLanguageName();

	bool SetActive();

private:
	unsigned int m_uiLanguageCode;
};

}

#endif
