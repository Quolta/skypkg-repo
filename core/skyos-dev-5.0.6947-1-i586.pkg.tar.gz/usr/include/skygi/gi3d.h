#ifndef __INCLUDE_SKYGI_DIRECT_GFX_
#define __INCLUDE_SKYGI_DIRECT_GFX_


#ifdef __cplusplus
extern "C" {
#endif

typedef struct sDirectGFXAccess
{
	int iWidth;
	int iHeight;
	int iStrideX;
	void *vpVirtualAddress;
	int iBPP;
	int iColorSpace;
	unsigned int uiFrameBufferSize;
	unsigned int uiFrameBufferOffset;


} sDirectGFXAccess;

typedef struct sGI3D
{
	sDirectGFXAccess pDirectAccess;
	DIB *hDirectAccessDIB;
} sGI3D;

typedef struct sGI3DVideoMode
{
	int iWidth;
	int iHeight;
	int iVirtualWidth;
	int iVirtualHeight;
	int iBPP;
	int iRefreshRate;
	unsigned int uiReserved[16];
} sGI3DVideoMode;

typedef struct sGI3DBuffer
{
	unsigned int uiFlags;
	DIB *hDIB;
} sGI3DBuffer;

#define GI3D_REQUEST_FULLSCREEN_USE_CURRENT_MODE 0x00000001

#define GI3D_CREATE_BUFFER_USE_VIDEOMEM			 0x00000001
#define GI3D_CREATE_BUFFER_USE_SYSTEMMEM		 0x00000002
#define GI3D_CREATE_BUFFER_USE_DIRECT_ACCESS	 0x00000004

#ifdef __cplusplus
}
#endif

#endif

