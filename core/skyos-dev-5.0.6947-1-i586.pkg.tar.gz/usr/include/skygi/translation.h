#ifndef __INCLUDE_SKYGI_TRANSLATION_
#define __INCLUDE_SKYGI_TRANSLATION_

#define TRANSLATION_LOADFLAG_APPLICATION_PATH    0x00000000
#define TRANSLATION_LOADFLAG_APPLICATION_SUBPATH 0x00000001
#define TRANSLATION_LOADFLAG_ABSOLUTE_PATH		 0x00000002

#define GI_TranslationLoad(ucLan) GI_TranslationLoadInternal(&_pMapTable, ucLan)

typedef struct sTextMapTable
{
	int iID;
	char *pText;
} sTextMapTable;

char *GI_TranslationGetString(int iID);

#endif
