#ifndef __MSG_WIDGET_H_
#define __MSG_WIDGET_H_


/*!
  \ingroup WM
  Sent when enter was pressed in the textfield

  \Widget: TextField

  \param uiPara1		hWnd of widget
  \param uiPara2		undefined
  \param rect			undefined
  \since 3.9.6c
  \author Robert Szeleney
*/
#define WM_WG_TEXTFIELD_ENTER			(WM_WG_RANGE_TEXTFIELD_START + 0)

/*!
  \ingroup WM
  Sent when text changed

  \Widget: TextField

  \param uiPara1		hWnd of widget
  \param uiPara2		undefined
  \param rect			undefined
  \since 3.9.6c
  \author Robert Szeleney
*/
#define WM_WG_TEXTFIELD_CHANGED			(WM_WG_RANGE_TEXTFIELD_START + 1)
#define WM_WG_TEXTFIELD_CANCEL 			(WM_WG_RANGE_TEXTFIELD_START + 2)


/*!
  \ingroup WM
  Sent when check box value changed

  \Widget: CheckBox

  \param uiPara1		hWnd of widget
  \param uiPara2		New value
  \param rect			undefined
  \since 5.0.0
  \author Chris Marshall
*/
#define WM_WG_CHECKBOX_CHANGED			(WM_WG_RANGE_CHECKBOX_START + 0)

/*!
  \ingroup WM
  Sent when radio button value changed

  \Widget: Radio Button

  \param uiPara1		hWnd of widget
  \param uiPara2		New value
  \param rect			undefined
  \since 5.0.0
  \author Chris Marshall
*/
#define WM_WG_RADIOBUTTON_CHANGED	(WM_WG_RANGE_RADIOBUTTON_START + 0)

/*!
  \ingroup WM
  Sent to retrieve number of text lines

  \Widget: TextField

  \param uiPara1		undefined
  \param uiPara2		undefined
  \param rect			undefined
  \since 3.9.6c
  \author Robert Szeleney
*/
#define WM_WG_TEXTFIELD_GET_NUMLINES			(WM_WG_RANGE_TEXTFIELD_START + 2)

/*!
  \ingroup WM

  \par Description:
  \Widget:  TextField
  \param	hWidget Textfield window of which to get the amount of text lines
  \return  Number of lines
  \sa WM_WG_SET_MESSAGE_TARGET
  \since 3.9.6c
  \author Robert Szeleney
*/
/*extern inline HRESULT GI_WidgetTextField_GetNumLines(HANDLE hWidget)
{
	return GI_MessageBuildAndSend(hWidget, WM_WG_TEXTFIELD_GET_NUMLINES, 0, 0);
}
*/

/*!
  \ingroup WM
	  Sent when a new item was selected  

  \Widget: Listbox
  \sa 
  \since 3.9.6c
  \author Robert Szeleney
*/
#define MSG_LISTBOX_SELECTED						(WM_WG_RANGE_LISTBOX_START + 0)

/*!
  \ingroup WM
	  Sent when a new item was selected with a doubleclick
  
  \Widget: Listbox
  \sa 
  \since 3.9.6c
  \author Robert Szeleney
*/
#define MSG_LISTBOX_SELECTED_WITH_DBLCLICK			(WM_WG_RANGE_LISTBOX_START + 1)
#define MSG_LISTBOX_EDIT_NOTIFY						(WM_WG_RANGE_LISTBOX_START + 2)
#define MSG_LISTBOX_RIGHT_LB						(WM_WG_RANGE_LISTBOX_START + 3)
#define MSG_LISTBOX_RIGHT_ITEM						(WM_WG_RANGE_LISTBOX_START + 4)
#define MSG_LISTBOX_HEADER							(WM_WG_RANGE_LISTBOX_START + 5)
#define MSG_LISTBOX_DRAG_REQUEST					(WM_WG_RANGE_LISTBOX_START + 6)
#define MSG_LISTBOX_HIGHLIGHT						(WM_WG_RANGE_LISTBOX_START + 7)

/*!
  \ingroup WM
	  Sent when the a new item was selected
  
  \Widget: Treeview
  \sa 
  \since 3.9.6c
  \author Robert Szeleney
*/
#define MSG_TREEITEM_SELECTED						(WM_WG_RANGE_TREE_START    + 2)


/*!
  \ingroup WM
  Sent when the message target should be modified.

  \Widget: Common
  \sa GI_MessageTargetSet
  \since 3.9.6c
  \author Robert Szeleney
*/
#define WM_WG_SET_MESSAGE_TARGET								 10800


/*!
  \ingroup WM

  Use the background picture from the client window
  
  \par Description:

  \Widget: Common
  \sa GI_UseSkin
  \since 3.9.6c
  \author Robert Szeleney
*/
#define WM_WG_USE_SKIN											10802

/*!
  \ingroup WM

  Use the background picture from the client window
  
  \par Description:

  \Widget: Common
  \return HRESULT
  \sa WM_WG_USE_SKIN
  \since 3.9.6c
  \author Robert Szeleney
*/
/*
extern inline HRESULT GI_UseSkin(HANDLE hWidget,
											char bEnable)
{
	//return GI_MessageBuildAndSend(hWidget, WM_WG_USE_SKIN, bEnable, 0);
}
*/
/*!
  \ingroup WM
 
  Set background for a widget.
  The widget will blit this background image at the specified position into the widget.
  
  \par Description:

  \Widget: Common
  \sa GI_WidgetBackgroundSet
  \since 3.9.6c
  \author Robert Szeleney
*/
/*
*/
#define WM_WG_SET_BACKGROUND									 10801
#define WM_WG_SET_BACKGROUND_IMAGE								 10802
typedef struct sWgSetBackgound
{
	void *hDIB;					//!< DIB to use as background image
	unsigned int uiColor;		//!< Color to usa as background color
	int iPosX;					//!< Relative X position for DIB
	int iPosY;					//!< Relative Y position for DIB
	unsigned int uiFlags;
	int iWidth;					//!< Relative X position for DIB
	int iHeight;					//!< Relative Y position for DIB
} sWgSetBackgound;

#define MSG_PROPERTY_SHEET_CHANGED						WM_WG_RANGE_PROP_START
#endif


