typedef struct s_clipboard_entry
{
	char ucType[255];
	char *data;
	unsigned int size;
} s_clipboard_entry;


#define CLIPBOARD_NOT_VALID				0
#define CLIPBOARD_TYPE_TEXT				1
#define CLIPBOARD_TYPE_URL 				2


HRESULT clipboard_add(s_clipboard_entry *entry);
HRESULT clipboard_get(s_clipboard_entry *entry);


