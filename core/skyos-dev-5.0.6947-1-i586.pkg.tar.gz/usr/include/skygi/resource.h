#ifndef __INCLUDE_SKYGI_RESOURCE_
#define __INCLUDE_SKYGI_RESOURCE_

#include "skygi/skygi.h"


typedef struct sGetResource
{
	unsigned char* ucData;
	unsigned int*  uiSize;
	unsigned int  uiResourceType;
	unsigned int  uiResID;
	unsigned int  uiLanguage;
	unsigned char * pDllName;
} sGetResource;

#define CLASS_BUTTON   0x0080
#define CLASS_EDIT     0x0081
#define CLASS_STATIC   0x0082
#define CLASS_LISTBOX  0x0083
#define CLASS_SCROLL   0x0084
#define CLASS_COMBO    0x0085
#define CLASS_BITMAP   0x0090
#define CLASS_GROUP    0x0091
#define CLASS_PROGRESS 0x0092
#define CLASS_PROPERTY 0x0093
#define CLASS_CHECK    0x0094
#define CLASS_TREE     0x0095
#define CLASS_COLOR_SHOW 0x00B0


#define IDOK                1
#define IDCANCEL            2
#define IDABORT             3
#define IDRETRY             4
#define IDIGNORE            5
#define IDYES               6
#define IDNO                7

#define RESOURCE_SOURCE_FILE	0x00000000
#define RESOURCE_SOURCE_PROCESS 0x00000001
#define RESOURCE_SOURCE_DLL     0x00000002

#define RESOURCE_TYPE_BITMAP          2
#define RESOURCE_TYPE_MENU			  4
#define RESOURCE_TYPE_DIALOG		  5
#define RESOURCE_TYPE_STRING_TABLE    6

typedef struct sResFile
{
	unsigned int uiSize;
	unsigned char *ucData;
	unsigned int uiResourceSource;
} sResFile;

typedef struct sResHeader
{
	unsigned int uiDataSize;
	unsigned int uiHeaderSize;
} sResHeader;

typedef struct sResDialogTemplate
{ 
  unsigned int uiStyle; 
  unsigned int uiExtendedStyle; 
  unsigned short  usWidgets; 
  short x; 
  short y; 
  short cx; 
  short cy; 
} sResDialogTemplate;

typedef struct sResDialogItemTemplate
{
  unsigned int uiStyle; 
  unsigned int uiExtendedStyle; 
  short x; 
  short y; 
  short cx; 
  short cy; 
  unsigned short usId;
} sResDialogItemTemplate;

typedef struct sDialogItemTemplate 
{
	unsigned char ucTitle[255];
	unsigned int  hWnd;
	unsigned int uiX;
	unsigned int uiY;
	unsigned int uiWidth;
	unsigned int uiHeight;
	unsigned int uiClass;
	unsigned int uiID;
} sDialogItemTemplate ;

typedef struct sDialogTemplate
{
	unsigned int uiX;
	unsigned int uiY;
	unsigned int uiWidth;
	unsigned int uiHeight;
	unsigned char ucTitle[255];
	unsigned int uiWidgets;
	HANDLE hWnd;

	sDialogItemTemplate pWidget[1];
	
} sDialogTemplate;

typedef struct win32_BITMAPINFOHEADER {
    unsigned int  biSize;
    unsigned int biWidth;
    unsigned int biHeight;
    unsigned short biPlanes;
    unsigned short biBitCount;
    unsigned int biCompression;
    unsigned int biSizeImage;
    unsigned int biXPelsPerMeter;
    unsigned int biYPelsPerMeter;
    unsigned int biClrUsed;
    unsigned int biClrImportant;
} win32_BITMAPINFOHEADER;

#define DCS_NO_WINDOW	0x00000001

typedef struct sResourceDialogCreate
{
	unsigned int uiStyle;
	unsigned int uiFlags;
	HANDLE       hUseParentDialog;
} sResourceDialogCreate;


HRESULT GI_ResourceOpen(unsigned int uiSource,
						unsigned char *pPath,
						sResFile **ppResFile);

HRESULT GI_DialogCreateFromResource(sResFile *pResFile,
							        unsigned int  uiDialogID,
									unsigned int  uiWindowFunction,
									sDialogTemplate **pDialogTemplate,
									sResourceDialogCreate *pDialogCreate);
HRESULT GI_ResourceToHandle(sDialogTemplate *pDialog,
						unsigned int uiWidgetID,
						HANDLE *phWnd);

HRESULT GI_ResourceLoadMenu(sResFile *pResFile,
						 unsigned int uiID,
						 HANDLE *hMenu);
unsigned char *GI_ResourceLoadStringPtr(sResFile *pResFile, unsigned int uiID, char *pTemp);
HRESULT GI_ResourceLoadString(sResFile *pResFile,
					  unsigned int uiID,
					  unsigned char *pUTF8,
					  unsigned int *uiMaxSize);


#endif



