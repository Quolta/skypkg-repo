#ifndef _INC_WGSTYLE_
#define _INC_WGSTYLE_
#include "iss/iss.h" 

#ifdef __cplusplus
extern "C" {
#endif

#define WIDGET_STYLE_SCROLL_TO_BEGIN 0
#define WIDGET_STYLE_SCROLL_TO_END   1

#define MAX_CACHE_DIBS  255
#define MAX_CACHE_MEDIA 50

#define MAX_STACK_DEPTH 16
#define MAX_LINKS		100

enum
{
	STYLE_COMMAND_COLOR = 0,
	STYLE_COMMAND_FONT,
	STYLE_COMMAND_STYLE,
	STYLE_COMMAND_COLUMN,
	MAX_STYLE_COMMANDS
};

enum
{
	LINK_TYPE_NONE=0,
	LINK_TYPE_LINK,
	LINK_TYPE_LAUNCH,
	LINK_TYPE_COMMAND,
	LINK_TYPE_WEB
};


enum
{
	KEY_TYPE_COLOR = 0,
	KEY_TYPE_LONG,
	KEY_TYPE_STRING
};

#define WGF_STYLE_HAS_VSCROLL	 0x00000001
#define WGF_STYLE_IGNORE_NEWLINE 0x00000002

typedef struct sStyleTags
{
	char *ucStyle;
	char *ucExpandOpen;
	char *ucExpandClose;
} sStyleTags;


typedef struct sLink
{
	char bUsed;
	s_region region;
	unsigned int uiLinkType;
	unsigned int uiLinkCommand;
	char pDestination[255];
	char ucParam[255];
} sLink;

typedef struct sStyleMediaCache
{
	HANDLE hWnd;
	int bUsed;
	int bAudio;
	int bVideo;
	int bPlay;
	int iWidth;
	int iHeight;
	sISSPlayBack *pISSPlayBack;
} sStyleMediaCache;

typedef struct sStyleCommandUndoStack
{
	struct 
	{
		unsigned int uiColorText;
		unsigned int uiColorBack;
	} pText;

	struct 
	{
		unsigned int uiIndex;
		unsigned int uiFontAlign;
		sFont *hFont;
	} pFont;

	struct
	{
		int iPixel;
	} pColumn;
} sStyleCommandUndoStack;

typedef struct sStyle
{
	HANDLE hWnd;
	GC *pGCBack;
	char *pDocumentText;


	unsigned int uiBackColor;
	unsigned int uiTextColor;
	sFont *hDefaultFont;
	sFont *hCurrentFont;
	int iLineGap;

	int x;
	int y;
	int uiMaxWidth;
	int uiMaxHeight;

	unsigned int uiDefaultBackColor;
	unsigned int uiDefaultTextColor;
	unsigned int uiCurrentTextColor;
	unsigned int uiCurrentBackColor;
	
	unsigned int iCurrentFontAlign;
	unsigned int uiStyleFlags;
	int iOffsetY;
	HANDLE hScrollVert;
	char bInternSizeMessage;

	int iStackIndex[MAX_STYLE_COMMANDS];
	sStyleCommandUndoStack pStack[MAX_STYLE_COMMANDS][MAX_STACK_DEPTH];

	int iWidthBack;
	int iHeightBack;
	int bDraw;

	sStyleTags *pStyleTags;

	int iMarginsTop;
	int iMarginsLeft;

	int iUserLineGap;

	sLink *pLinks;
	int iNextLink;

	char ucLink[255];
	unsigned int uiLinkCommand;
	char ucLinkParam[255];
	int iLinkX, iLinkY;

	int iLastDrawHeight;
	unsigned int uiLinkType;

	DIB* hCacheDIB[MAX_CACHE_DIBS];
	int  iCacheIndexDIB;

	sStyleMediaCache hCacheMedia[MAX_CACHE_MEDIA];
	int  iCacheIndexMedia;

	int bShowFrame;
	unsigned int uiDefaultFrameColor;
	int bFreeStyleTagsOnClose;
	char ucStyleCloseTag[4096];

	int iColumnPixel;
} sStyle;

#define STYLE_FLAG_NEW_LINE		   0x00000001
#define STYLE_FLAG_END_OF_DOCUMENT 0x00000002
#define STYLE_FLAG_COMMAND         0x00000004

HANDLE GI_WidgetStyleCreate(HANDLE parent,
							  char *name,
							  int x, int y, int width, int height,
							  int uiWindowFlags, unsigned int uiStyleFlags);
HRESULT GI_WidgetStyleSetDocument(HANDLE hWnd,
								  char *pDocumentText);
HRESULT GI_WidgetStyleClearDocument(HANDLE hWnd);
HRESULT GI_WidgetStyleScrollTo(HANDLE hWnd, int enumScrollTo);
HRESULT GI_WidgetStyleSetLineGap(HANDLE hWnd, int iLineGap);
#ifdef __cplusplus
}
#endif

#endif
