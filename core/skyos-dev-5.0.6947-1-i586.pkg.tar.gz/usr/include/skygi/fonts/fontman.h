#ifndef _INC_FONTMAN_H
#define _INC_FONTMAN_H

#ifdef __cplusplus
extern "C" {
#endif


#ifndef KERNEL

#define FONT_FLAG_INTERNAL_PERSISTANT	0x00000001
#define FONT_FLAG_INTERNAL_CONST		0x00000002
#define FONT_FLAG_INTERNAL_DEBUG		0x00000004

#include "skyos/types.h"

#define DEFAULT_DPI 96


#define MAX_FONTS 1024


extern inline int utf8_char_length( unsigned char nFirstByte )
{
    return( ((0xe5000000 >> ((nFirstByte >> 3) & 0x1e)) & 3) + 1 );
} 

extern inline int utf8_to_unicode( const char* pzSource )
{
    if ( (pzSource[0]&0x80) == 0 ) 
	{
		return( *pzSource );
    } 
	else if ((pzSource[1] & 0xc0) != 0x80) 
	{
        return( 0xfffd );
    } 
	else if ((pzSource[0]&0x20) == 0) 
	{
		return( ((pzSource[0] & 0x1f) << 6) | (pzSource[1] & 0x3f) );
    } 
	else if ( (pzSource[2] & 0xc0) != 0x80 ) 
	{
        return( 0xfffd );
    } 
	else if ( (pzSource[0] & 0x10) == 0 ) 
	{
		return( ((pzSource[0] & 0x0f)<<12) | ((pzSource[1] & 0x3f)<<6) | (pzSource[2] & 0x3f) );
    } 
	else if ((pzSource[3] & 0xC0) != 0x80) 
	{
        return( 0xfffd );
    } 
	else 
	{
		int   nValue;
		nValue = ((pzSource[0] & 0x07)<<18) | ((pzSource[1] & 0x3f)<<12) | ((pzSource[2] & 0x3f)<<6) | (pzSource[3] & 0x3f);
		return( ((0xd7c0+(nValue>>10)) << 16) | (0xdc00+(nValue & 0x3ff)) );
    }
} 

typedef struct sDoubleLinkedList 
{
	struct sDoubleLinkedList *pNext;
	struct sDoubleLinkedList *pPrev;
} sDoubleLinkedList;

typedef struct sFontStyle
{
	int iFontIndex;
	char ucStyle[255];
	char ucFileName[255];
	struct sFontFamily *pFontFamilyLink;
	
	sDoubleLinkedList lFontStyleLink;
	sDoubleLinkedList lFontFilesLink;

}  sFontStyle;

typedef struct sFontFamily
{
	char ucFamily[255];
	sDoubleLinkedList lFontFamiliesLink;
	sDoubleLinkedList lFontStyleHead;
}  sFontFamily;

#endif

typedef struct sFontFace
{
	void *face;
	int iCurrentSize;
	int iRefCount;
	char bScalable;
	char bFixedWidth;

} sFontFace;


typedef struct sFontPhysical
{
	int iRefCount;
	void *vpAddress;
	int  iSize;
	char ucFamily[255];
    char ucStyle[255];
    char ucFileName[255];
	sFontFace *pFontFace;
	void *pCache;
} sFontPhysical;

typedef struct sFont
{
	int iSize;
	int iAscend;
	int iDescend;
	int iLineGap;
	int iAdvance;
	sFontPhysical *pPhysical;
	sFontFace *pFontFace;
	unsigned int uiInternalFontFlags;
	unsigned int uiReserved[15];
} sFont;

typedef struct sFontInfo
{
	char ucFamily[255];
	char ucStyle[255];
	char ucFileName[255];
	int iSize;
	unsigned int uiFontFlags;
	unsigned int uiReserved[16];
} sFontInfo;

typedef struct sFontMetrics
{
	int iSize;
	int iAscend;
	int iDescend;
	int iLineGap;
	int iAdvance;
	unsigned int uiReserved[16];
} sFontMetrics;

typedef struct sFontGlyph
{
	void *vpBitmap;
	unsigned int iBitmapStride;
    unsigned int iBitmapWidth;
	unsigned int iBitmapHeight;

	unsigned int iBitmapTop;
	unsigned int iBitmapLeft;
	unsigned int iBitmapBottom;
	unsigned int iBitmapRight;
	unsigned int iAscendY;
	int iAdvanceX;
	char bAlpha;
} sFontGlyph;

typedef struct sFontGlyphCache
{
	sFontGlyph pGlyph;
	unsigned int face_flags;
	int face_max_advance;
	int face_slot_advance_x;
	int face_ascender;
	int face_descender;

	char data[1];
} sFontGlyphCache;


#ifdef __cplusplus
}
#endif

#endif

