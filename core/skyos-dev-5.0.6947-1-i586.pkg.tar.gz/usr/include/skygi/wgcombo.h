/*
\defgroup wgCombo Combo box
*/
#ifndef _INC_wgCombo_
#define _INC_wgCombo_

#define WM_WG_COMBO_GET_LISTBOX			10100
#define WM_WG_COMBO_CREATE				10101
#define WM_WG_COMBO_GET_TEXTFIELD		10102

/*!
   \ingroup wgCombo
   The the handle of the listbox when the listbox window is opened.
   You may call this function, when the combo widget sends you a MSG_LISTBOX_SELECTED
   message.
*/
#define GI_WidgetComboGetListbox(hWnd)  \
	SkyGI_SendMessage(hWnd, WM_WG_COMBO_GET_LISTBOX, 0, 0)

/*!
   \ingroup wgCombo
 Get the textfield of the combo widget
*/
#define GI_WidgetComboGetTextfield(hWnd)  \
	SkyGI_SendMessage(hWnd, WM_WG_COMBO_GET_TEXTFIELD, 0, 0)

#endif


