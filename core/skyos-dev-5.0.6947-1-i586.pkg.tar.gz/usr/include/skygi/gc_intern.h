#ifndef __GC_INTERN_H_
#define __GC_INTERN_H_

int GC_WindowDrawPixel(GC *gc,  int x,  int y);
int GC_WindowDrawRectFill(GC *gc,
			 int x,
			int y,
			int width,
			int height);
int GC_win_draw_rect(GC *gc,
			 int x,
			int y,
			int width,
			int height);
#endif


