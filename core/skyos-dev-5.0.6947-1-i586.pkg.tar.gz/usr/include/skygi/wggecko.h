#ifndef _INC_WGGECKO_
#define _INC_WGGECKO_

#ifdef __cplusplus
extern "C" {
#endif


#include "skyos/libskyos.h" 

typedef struct sGecko
{
	HANDLE hWnd;
	unsigned int uiStyleFlags;
	unsigned int uiDefaultFrameColor;
	unsigned int bShowFrame;
} sGecko;

HRESULT GI_WidgetGeckoPropertySet(HANDLE hWnd, 
								  char bSet,
								  unsigned int uiProperty,
								  unsigned int uiValue);

/*
   interface
*/

typedef struct sInterfaceWidgetGecko
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wggecko

	empty
	*/
	HRESULT (*OnRemoveRow)(HANDLE hWnd, HANDLE hRow);

	unsigned int uiReserved[31];
} sInterfaceWidgetGecko;
 

/*
   private functions
*/
int _GeckoInitialize(void);
int _GeckoCreate(sGecko *pGecko);
int _GeckoLoadURI(sGecko *pGecko, char *pURI);
int _GeckoResize(sGecko *pGecko);

#ifdef __cplusplus
}
#endif

#endif
