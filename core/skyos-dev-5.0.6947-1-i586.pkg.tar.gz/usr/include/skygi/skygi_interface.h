/*!
\defgroup winintf libskygi - Window interface functions

Each SkyGI window has an window interface associated with it. An interface function gets called whenever SkyOS 
sends a message to a window. For the most common messages like MSG_GUI_REDRAW, MSG_MOUSE_BUT1_PRESSED, .... there 
is a seperate interface function like OnRedraw, OnMousePressed.

All other messages are processed by the window specific window function.

Widgets may have additional widget specific interface functions like OnClick, OnEntrySelected, ...

*/

#ifndef __INCLUDE_SKYGI_INTERFACE_
#define __INCLUDE_SKYGI_INTERFACE_

#ifdef __cplusplus
extern "C" {
#endif

void GI_InterfaceDummyFunction(void);

/*!
	\ingroup winintf
	  
	Override a window function. If you override a window function you should always call the original
	window function (if one was set) before or after processing your desired code.

	\param[in] _window Window handle
	\param[in] _interface Interface function to override
	\param[in] _function Function which will be called when interface function gets called
	\param[out] _oldfunction Return address of old interface function
	\since  5.0-beta8.5
	
	<b>Example:</b>
	\code
	GI_InterfaceSet(hWnd, OnCommand, MyOnCommand, &fOldOnCommand);
	\endcode
		
*/
#define GI_InterfaceSet(_window, _interface, _function, _oldfunction) \
	{ \
		if (_oldfunction) \
		*((unsigned int*)_oldfunction) = (unsigned int)0; \
		\
		if ((_window) && (((s_window*)_window)->pInterface)) \
		{ \
			if (_oldfunction) \
				*(unsigned int*)_oldfunction = (unsigned int)((s_window*)_window)->pInterface->pWindow->_interface;\
			((s_window*)_window)->pInterface->pWindow->_interface = (void*)_function; \
		}\
		if (_oldfunction) \
		{ \
			if ( *((unsigned int*)_oldfunction) == NULL) \
				*((unsigned int*)_oldfunction) = GI_InterfaceDummyFunction; \
		}\
	}

/*!
	\ingroup winintf
	  
	Override a widget specific function. By overriding a widget specific function you can 
	react on events which are fired by widgets themself. (e.g. OnTextChanged..)

	\param[in] _window Window handle
	\param[in] _interfacetype Interface Type, e.g.: sInterfaceListbox
	\param[in] _interface Interface function to override
	\param[in] _function Function which will be called when interface function gets called
	\param[out] _oldfunction Return address of old interface function
	\since  5.0-beta8.5
	
	<b>Example:</b>
	\code
	GI_InterfaceSetWidget(hWnd, sInterfaceListbox, OnSelected, MyOnSelected, NULL);
	\endcode
		
*/
#define GI_InterfaceSetWidget(_window, _interfacetype, _interface, _function, _oldfunction) \
	{ \
		if (_oldfunction) \
		*((unsigned int*)_oldfunction) = (unsigned int)0; \
		\
		if ((_window) && (((s_window*)_window)->pInterface)) \
		{ \
			if (_oldfunction) \
				*(unsigned int*)_oldfunction = (unsigned int)  ((_interfacetype*)((s_window*)_window)->pInterface)->_interface;\
			((_interfacetype*)((s_window*)_window)->pInterface)->_interface = (void*)_function; \
		}\
		if (_oldfunction) \
		{ \
			if ( *((unsigned int*)_oldfunction) == NULL) \
				*((unsigned int*)_oldfunction) = GI_InterfaceDummyFunction; \
		}\
	}

typedef struct sInterfaceWindow
{
	unsigned int uiInterfaceVersion;
	HANDLE hWnd;
	void             *pPrivate;

	/*!
	\ingroup winintf
	  
	Called whenever the mouse button is pressed in a window
	  
	\param[in] hWnd Window handle
	\param[in] pPoint Window relative point where mouse was pressed
	\param[in] uiButtonID ID of pressed mouse button
	\since  5.0-beta8.5
	*/
	HRESULT (*OnMousePress)(HANDLE hWnd, s_point *pPoint, unsigned int uiButtonID, int bDoubleClick);

	/*!
	\ingroup winintf
	  
	Called whenever the mouse button is released in a window
	  
	\param[in] hWnd Window handle
	\param[in] pPoint Window relative point where mouse was released
	\param[in] uiButtonID ID of released mouse button
	\since  5.0-beta8.5
	*/
	HRESULT (*OnMouseRelease)(HANDLE hWnd, s_point *pPoint, unsigned int uiButtonID);

	/*!
	\ingroup winintf

	Called before the main message loop exits.

	\param[in] hWnd Window handle
	\since  5.0-beta8.5	
	*/
	HRESULT (*OnQuit)(HANDLE hWnd);

	/*!
	\ingroup winintf

	Called whenever the entire or parts of the window must be redrawn.

	\param[in] hWnd Window handle
	\param[in] GC GC which must be used for drawing
	\param[in] pClipRegion Clip region to use. This clip region should be set with GC_ClipSet.
	\since  5.0-beta8.5	
	*/
	HRESULT (*OnRedraw)(HANDLE hWnd, GC *pGC, s_region *pClipRegion);

	/*!
	\ingroup winintf

	Called when a request to close the window was sent. If you want to actually close the window, call GI_MessageQuitPost(HANDLE hWnd)
	in this function.

	\param[in] hWnd Window handle
	\since  5.0-beta8.5	
	*/
	HRESULT (*OnDestroy)(HANDLE hWnd);

	/*!
	\ingroup winintf

	Called when a key was pressed
	  
	\param[in] hWnd Window handle
	\param[in] uiAscii     UTF8 keycode
	\param[in] uiVKey      Bits  32-16 ... Virtual Key code\n
						   Bit		 2 ... ALT was down while key was pressed\n
						   Bit		 1 ... CTRL was down while key was pressed\n
						   Bit		 0 ... SHIFT was down while key was pressed\n
	\since  5.0-beta8.5
	*/
	HRESULT (*OnKeyDown)(HANDLE hWnd, unsigned int uiAscii, unsigned int uiVKey);

	/*!
	\ingroup winintf

	Called when a key was released
	  
	\param[in] hWnd Window handle
	\param[in] uiAscii     UTF8 keycode
	\param[in] uiVKey      Bits  32-16 ... Virtual Key code\n
						   Bit		 2 ... ALT was down while key was pressed\n
						   Bit		 1 ... CTRL was down while key was pressed\n
						   Bit		 0 ... SHIFT was down while key was pressed\n
	\since  5.0-beta8.5
	*/
	HRESULT (*OnKeyUp)(HANDLE hWnd, unsigned int uiAscii, unsigned int uiVKey);

	/*!
	\ingroup winintf

	Called when a timer has expired
	  
	\param[in] hWnd Window handle
	\param[in] uiTimerID ID of the expired timer

	\since  5.0-beta8.5
	*/
	HRESULT (*OnTimerReached)(HANDLE hWnd, unsigned int uiTimerID);

	/*!
	\ingroup winintf

	Called just before a window gets resized. You have to chance to adjust the requested window position and size here.
	  
	\param[in] hWnd Window handle
	\param[in,out] rRequestedSize Requested size

	\since  5.0-beta8.5
	*/	
	HRESULT (*OnSize)(HANDLE hWnd, s_region *rRequestedSize);

	/*!
	\ingroup winintf

	Called when a window has been resized.
	  
	\param[in] hWnd Window handle
	\param[in] rNewSize New window dimension

	\since  5.0-beta8.5
	*/	
	HRESULT (*OnSized)(HANDLE hWnd, s_region *rNewSize);

	/*!
	\ingroup winintf

	Called when the mouse was moved. This function will not be called until you enable mouse tracking with 
	GI_MouseTrackingEnable(HANDLE hWnd);
	  
	\param[in] hWnd Window handle
	\param[in] Current mouse position

	\since  5.0-beta8.5
	*/	
	HRESULT (*OnMouseMoved)(HANDLE hWnd, s_point *pPoint);

	/*!
	\ingroup winintf

	Called when a child window fired an event. Events are normally fired from child widgets like menus, buttons, ...
	  
	\param[in] hWnd Window handle
	\param[in] HEventWindow Handle of window which fired the event
	\param[in] uiEventID Event ID
	\param[in] uiEventButton ID of mouse button/key which caused the event to fire
	\param[in] uiData Event specific data

	\since  5.0-beta8.5
	*/	
	HRESULT (*OnCommand)(HANDLE hWnd, HANDLE hEventWindow, unsigned int uiEventID, unsigned int uiEventButton, unsigned int uiData);

	/*!
	\ingroup winintf

	empty
	*/
	HRESULT (*OnDragMotion)(HANDLE hWnd);

	/*!
	\ingroup winintf

	empty
	*/
	HRESULT (*OnDragDrop)(HANDLE hWnd);

	/*!
	\ingroup winintf

	empty
	*/
	HRESULT (*OnFocusWantSwitch)(HANDLE hWnd, HANDLE *hTarget);

	/*!
	\ingroup winintf

	empty
	*/
	HRESULT (*OnFocusGet)(HANDLE hWnd);

	/*!
	\ingroup winintf

	empty
	*/
	HRESULT (*OnFocusLost)(HANDLE hWnd);

	/*!
	\ingroup winintf

	Called when a window gets destroyed. Free window specific resources here

	\param[in] hWnd Window handle
	\since  5.0-Build 5550
	*/
	HRESULT (*OnDestroyWindow)(HANDLE hWnd);
} sInterfaceWindow;

typedef struct sInterfaceText
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgtext

	Called when the user pressed escape inside the textfield
	  
	\param[in] hWnd Window handle

	\since  5.0
	*/	
	HRESULT (*OnCancel)(HANDLE hWnd);

	/*!
	\ingroup wgtext

	Called when the user confirms the input by pressing the enter key inside the text field
	  
	\param[in] hWnd Window handle

	\since  5.0
	*/	
	HRESULT (*OnConfirm)(HANDLE hWnd);

	/*!
	\ingroup wgtext

	Called when the user changes the text inside a text field
	  
	\param[in] hWnd Window handle

	\since  5.0
	*/	
	HRESULT (*OnChanged)(HANDLE hWnd);

	/*!
	\ingroup wgtext

	Called a popup window should be displayed
	  
	\param[in] hWnd Window handle
	\param[in] x Horizontal coordinate where mouse button was pressed
	\param[in] y Vertical coordinate where mouse button was pressed
	\return S_OK is a menu was displayed. S_FALSE if default text popup menu should be displayed

	\since  5.0-beta8.5
	*/	
	HRESULT (*OnPopupMenu)(HANDLE hWnd, int x, int y);

	/*!
	\ingroup wgtext

	\param[in] hWnd Window handle

	\since  5.0-beta10
	*/	
	HRESULT (*OnCursorPosChanged)(HANDLE hWnd);

	/*!
	\ingroup wgtext

	\since  5.0-beta10
	*/	
	HRESULT (*OnSwitchFocusOnEnter)(HANDLE hWnd);

	unsigned int uiReserved[31];
} sInterfaceText;

#define sInterfaceEdit sInterfaceText

typedef struct sInterfaceCombo
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgcombo

	empty
	*/
	HRESULT (*OnChanged)(HANDLE hWnd);

	/*!
	\ingroup wgcombo

	empty
	*/
	HRESULT (*OnEdit)(HANDLE hWnd);

	/*!
	\ingroup wgcombo

	empty
	*/
	HRESULT (*OnSelected)(HANDLE hWnd);

	/*!
	\ingroup wgcombo

	empty
	*/
	HRESULT (*OnPopup)(HANDLE hWnd, HANDLE hListbox);

	unsigned int uiReserved[31];
} sInterfaceCombo ;


typedef struct sInterfaceListbox
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wglist

	empty
	*/
	HRESULT (*OnDrag)(HANDLE hWnd, HANDLE hItem, void *pItemData);

	/*!
	\ingroup wglist

	empty
	*/
	HRESULT (*OnSelected)(HANDLE hWnd, HANDLE hItem, char *ucItemText, void *pItemData);

	/*!
	\ingroup wglist

	empty
	*/
	HRESULT (*OnSelectedWithDoubleclick)(HANDLE hWnd, HANDLE hItem, char *ucItemText, void *pItemData);

	/*!
	\ingroup wglist

	empty
	*/
	HRESULT (*OnHightlighted)(HANDLE hWnd, HANDLE hItem, char *ucItemText, void *pItemData);

	/*!
	\ingroup wglist

	empty
	*/
	HRESULT (*OnPopup)(HANDLE hWnd, HANDLE hItem, HANDLE *hMenu);

	unsigned int uiReserved[31];
} sInterfaceListbox;


typedef struct sInterfaceFileView
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgfilevw

	empty
	*/
	HRESULT (*OnDrag)(HANDLE hWnd, HANDLE hItem, void *pItemData);

	/*!
	\ingroup wgfilevw

	empty
	*/
	HRESULT (*OnSelected)(HANDLE hWnd, HANDLE hItem, char *ucItemText, void *pItemData);

	/*!
	\ingroup wgfilevw

	empty
	*/
	HRESULT (*OnSelectedWithDoubleclick)(HANDLE hWnd, HANDLE hItem, char *ucItemText, void *pItemData);

	/*!
	\ingroup wgfilevw

	empty
	*/
	HRESULT (*OnChangeDirectory)(HANDLE hWnd, char *ucNewDirectory);

	/*!
	\ingroup wgfilevw

	empty
	*/
	HRESULT (*OnPopup)(HANDLE hWnd, HANDLE hItem, HANDLE *hMenu);

	unsigned int uiReserved[31];
} sInterfaceFileView;

typedef struct sInterfaceCategory
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgcategory

	empty
	*/
	HRESULT (*OnDrag)(HANDLE hWnd, HANDLE hEntry, void *pItemData);

	/*!
	\ingroup wgcategory

	empty
	*/
	HRESULT (*OnSelected)(HANDLE hWnd, HANDLE hEntry);

	/*!
	\ingroup wgcategory

	empty
	*/
	HRESULT (*OnSelectedWithDoubleclick)(HANDLE hWnd, HANDLE hEntry);

	/*!
	\ingroup wgcategory

	empty
	*/
	HRESULT (*OnPopup)(HANDLE hWnd, HANDLE hItem, int x, int y);

	/*!
	\ingroup wgcategory

	empty
	*/
	HRESULT (*OnDeleteEntry)(HANDLE hWnd, HANDLE hEntry);

	unsigned int uiReserved[31];
} sInterfaceCategory;

typedef struct sInterfaceButton
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgbutton

	empty
	*/	
	HRESULT (*OnClick)(HANDLE hWnd, unsigned int uiMouseButton, unsigned int uiButtonID);

	unsigned int uiReserved[31];
} sInterfaceButton;

typedef struct sInterfaceFrame
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgframe

	empty
	*/	
	HRESULT (*OnReShape)(HANDLE hWnd);

	unsigned int uiReserved[31];
} sInterfaceFrame;

typedef struct sInterfaceStatic
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgstatic

	empty
	*/	
	HRESULT (*OnClick)(HANDLE hWnd, unsigned int uiButtonID, unsigned int uiID, int iX, int iY);

	unsigned int uiReserved[31];
} sInterfaceStatic;


typedef struct sInterfacePropertySheet
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgprop

	empty
	*/	
	HRESULT (*OnShow)(HANDLE hWnd);

	/*!
	\ingroup wgprop

	empty
	*/	
	HRESULT (*OnHide)(HANDLE hWnd);

	/*!
	\ingroup wgprop

	empty
	*/	
	HRESULT (*OnClick)(HANDLE hProperty, 
							 HANDLE hSheet, int iX, int iY, int iButton, int iDouble, int iPressed);

	unsigned int uiReserved[30];
} sInterfacePropertySheet;

typedef struct sInterfaceScrollbar
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgscroll

	empty
	*/	
	HRESULT (*OnScroll)(HANDLE hWnd, int iNewPosition, int iDelta);

	unsigned int uiReserved[30];
} sInterfaceScrollbar;

typedef struct sInterfaceCheckbox
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgcheck

	empty
	*/	
	HRESULT (*OnChanged)(HANDLE hWnd, int bChecked);

	/*!
	\ingroup wgcheck

	empty
	*/	
	HRESULT (*OnChecked)(HANDLE hWnd);

	/*!
	\ingroup wgcheck

	empty
	*/	
	HRESULT (*OnUnChecked)(HANDLE hWnd);

	unsigned int uiReserved[30];
} sInterfaceCheckbox;

typedef struct sInterfaceFavoriteNavigation
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgfavnav

	empty
	*/	
	HRESULT (*OnClick)(HANDLE hWnd, char *cName, char *cLocation);

	unsigned int uiReserved[31];
} sInterfaceFavoriteNavigation;

typedef struct sInterfaceStyle
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgfavnav

	empty
	*/	
	HRESULT (*OnLinkClicked)(HANDLE hWnd, unsigned int uiLinkType, unsigned int uiLinkCommand, char *pDestination, char *pParameter);

	unsigned int uiReserved[31];
} sInterfaceStyle;


typedef struct sInterface
{
	sInterfaceWindow *pWindow;
} sInterface;

#define WINDOW_IMPLEMENTS(_window, _function) ((_window) && (((s_window*)_window)->pInterface) && (((s_window*)_window)->pInterface->pWindow->_function))

#ifdef __cplusplus
}
#endif

#endif



