#ifndef _INC_WGGraph_
#define _INC_WGGraph_
#include "iss/iss.h" 
#include "skyos/libskyos.h" 

#define MAX_COUNTERS 20

enum
{
	GRAPH_COUNTER_TYPE_ABSOLUTE=0,
	GRAPH_COUNTER_TYPE_DELTA
};

typedef unsigned int (*tGraphSample)(HANDLE hCounter);
typedef unsigned int (*tGraphScale)(HANDLE hWnd, HANDLE hCounter, int iHeight, unsigned int uiValue);

HRESULT GI_WidgetGraphSetRedrawTime(HANDLE hWnd, 
										  int iMsecs);
void GI_WidgetGraphAdvance(HANDLE hWnd, int iValue);

typedef struct sGraphCounter
{
  int *pData;
  
  unsigned int uiColor;
  unsigned int uiType;

  struct sGraph *pGraph;
  volatile unsigned int *pSampleAddress;
  tGraphSample fpSample;
  tGraphScale  fpScale;
  void *vpData;
  unsigned int uiSampleType;
  unsigned int uiLastValue;
  int bFirstSample;

} sGraphCounter;

typedef struct sGraph
{
	HANDLE hWnd;
	GC *pGCBack;

	unsigned int uiBackColor;
	sFont *hDefaultFont;

	int uiMaxWidth;
	int uiMaxHeight;

	unsigned int uiGraphFlags;

	int iWidthBack;
	int iHeightBack;

	int iMsecs;
	int iTimer;
	int iTimerSample;
	int bRunning;
	sGraphCounter *pCounter[MAX_COUNTERS];

	int iSamplePos;
	int iSampleMax;

	void *lock;

} sGraph;

HRESULT 	GI_WidgetGraphAddCounter (HANDLE hWnd, HANDLE hCounter);
void 	GI_WidgetGraphAdvance (HANDLE hWnd, int iValue);
void * 	GI_WidgetGraphCounterGetPrivate (HANDLE hCounter);
HRESULT 	GI_WidgetGraphCounterReset (HANDLE hCounter);
HRESULT 	GI_WidgetGraphCounterSample (HANDLE hCounter, int iValue);
HRESULT 	GI_WidgetGraphCounterSetColor (HANDLE hCounter, unsigned int uiColor);
HRESULT 	GI_WidgetGraphCounterSetPrivate (HANDLE hCounter, void *vpData);
HRESULT 	GI_WidgetGraphCounterSetSampleAddress (HANDLE hCounter, unsigned int *vpuiAddress);
HRESULT 	GI_WidgetGraphCounterSetSampleFunction (HANDLE hCounter, tGraphSample fpFunction);
HRESULT 	GI_WidgetGraphCounterSetSampleType (HANDLE hCounter, unsigned int uiType);
HRESULT 	GI_WidgetGraphCounterSetScaleFunction (HANDLE hCounter, tGraphScale fpFunction);
HANDLE 	GI_WidgetGraphCreate (HANDLE parent, char *name, int x, int y, int width, int height, int uiWindowFlags, unsigned int uiGraphFlags);
HRESULT 	GI_WidgetGraphCreateCounter (HANDLE hGraph, HANDLE *phCounter);
HRESULT 	GI_WidgetGraphPropertySet (HANDLE hWnd, char bSet, unsigned int uiProperty, unsigned int uiValue);
HRESULT 	GI_WidgetGraphRemoveCounter (HANDLE hWnd, HANDLE hCounter);
HRESULT 	GI_WidgetGraphSetRedrawTime (HANDLE hWnd, int iMsecs);
HRESULT 	GI_WidgetGraphStartStop (HANDLE hWnd, int bStart);
HRESULT 	GI_WidgetGraphUseAutoSample (HANDLE hWnd, int uiMsecs);
#endif
