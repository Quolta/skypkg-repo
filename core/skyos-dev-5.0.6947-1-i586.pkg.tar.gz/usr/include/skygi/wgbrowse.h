#ifndef _INC_WGBROWSE_
#define _INC_WGBROWSE_

#include "skygi/wgcategory.h"

typedef struct sWidgetBrowseInfo
{
	unsigned int uiFlags;
	char ucQuery[255];
	char ucCaptionWindow[255];
	char ucCaptionOK[255];
	char ucCaptionCancel[255];
	char ucHomeDirectory[4096];
	char ucSelectedFileName[4096];
	char bCanceled;
} sWidgetBrowseInfo;


typedef struct sBrowse
{
	HANDLE hWnd;
	HANDLE hLayoutMain;
	HANDLE hLayoutRight;
	HANDLE hPanelInfo;
	HANDLE hFormButtons;
	
	HANDLE hPanelTypes;
	HANDLE hPanelPreview;
	HANDLE hPanelPreviewForm;

	HANDLE hPanelRight;
	HANDLE hPanelSearch;

	HANDLE hPanelBrowse;

	HANDLE hButtonOK;
	HANDLE hButtonCancel;

	/*
	   Search box
    */
	HANDLE hFormSearch;
	HANDLE hStaticQuery;
	HANDLE hEditQuery;
	HANDLE hFavoritesNavigation;

	/*
	  Query
    */
	HANDLE hCategoryQuery;
	char ucQueryString[1024];
	HANDLE hQueryCurrentSearch;
	sCategorySearchInfo *hQueryCurrentSearchInfo;

	/*
	  Browse
    */
	HANDLE hPanelBrowseForm;
	HANDLE hFileViewBrowse;
	char ucRoot[1024];

	HANDLE hStaticFilename;
	HANDLE hEditFilename;
	HANDLE hButton;

	tWindowFunction fWndFuncPreview;
	tWindowFunction fWndFuncType;
	tWindowFunction fWndFuncFormSearch;
	tWindowFunction fWndFuncFormBrowse;
	tWindowFunction fWndFuncFormButtons;
	tWindowFunction fWndFuncFavorites;

	sWidgetBrowseInfo *pInfo;

	int bOperationFinishedSuccessful;

	HANDLE hPanelFavorites;
	HANDLE hPanelFavoritesForm;
	
	HANDLE hArrow;


} sBrowse;

enum
{
	WIDGET_BROWSE_INFO_CAPTION_ID_WINDOW,
	WIDGET_BROWSE_INFO_CAPTION_ID_BUTTON_OK,
	WIDGET_BROWSE_INFO_CAPTION_ID_BUTTON_CANCEL
};

#define WIDGET_BROWSE_INFO_FLAG_EXPAND_QUERY  0x00000001
#define WIDGET_BROWSE_INFO_FLAG_EXPAND_BROWSE 0x00000002

#define WIDGET_BROWSE_INFO_FLAG_OPEN		  0x80000000
#define WIDGET_BROWSE_INFO_FLAG_SAVE		  0x40000000
#define WIDGET_BROWSE_INFO_FLAG_NEW			  0x20000000
#define WIDGET_BROWSE_INFO_FLAG_OPEN_FOLDER	  0x10000000

HANDLE 	GI_QueryHelperBuildMenu (void);
HANDLE 	GI_WidgetBrowseCreate (HANDLE hParent, sWidgetBrowseInfo *pInfo);
HANDLE 	GI_WidgetBrowseInfoAlloc (void);
HANDLE 	GI_WidgetBrowseInfoCreate (unsigned int uiFlags, char *ucTitle, char *ucInitialDir, char *ucCategory, char *ucInitialQuery);
HRESULT 	GI_WidgetBrowseInfoFree (HANDLE pInfo);
int 	GI_WidgetBrowseInfoGetCancelled (HANDLE pInfo);
char * 	GI_WidgetBrowseInfoGetFileName (HANDLE pInfo);
char * 	GI_WidgetBrowseInfoGetHomeDirectory (HANDLE pInfo);
HRESULT 	GI_WidgetBrowseInfoSetCaption (HANDLE pInfo, char bButtonID, char *ucCaption);
HRESULT 	GI_WidgetBrowseInfoSetCategory (HANDLE pInfo, char *ucCategory);
HRESULT 	GI_WidgetBrowseInfoSetFlags (HANDLE pInfo, unsigned int uiFlags);
HRESULT 	GI_WidgetBrowseInfoSetHomeDirectory (HANDLE pInfo, char *ucHomeDirectory);
HRESULT 	GI_WidgetBrowseInfoSetQuery (HANDLE pInfo, char *ucQuery);
int 	GI_WidgetBrowseRun (HANDLE hParent, HANDLE pInfo, int *piState);

#endif
