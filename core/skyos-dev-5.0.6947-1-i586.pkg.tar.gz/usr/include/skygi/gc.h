#ifndef __GC_H_
#define __GC_H_

#ifndef KERNEL
typedef struct sRGBColor
{
	unsigned char red;
	unsigned char green;
	unsigned char blue;
	unsigned char cAlpha;
} sRGBColor;

static inline void CONVERT_32_TO_COLOR(unsigned int color, struct sRGBColor *pRGBColor)
{
	pRGBColor->red   = (color>>16) & 0xFF; 
	pRGBColor->green = (color>>8)  & 0xFF; 
	pRGBColor->blue  =  color      & 0xFF; 
	pRGBColor->cAlpha = (color>>24) & 0xFF;
}
#endif

#define GC_RESET_FLAG_CLIP		    0x00000001
#define GC_RESET_FLAG_COLOR			0x00000002
#define GC_RESET_FLAG_FLAGS			0x00000004
#define GC_RESET_FLAG_TRANSPARENT	0x00000008
#define GC_RESET_FLAG_FONTS			0x00000010
#define GC_RESET_FLAG_ORIGIN		0x00000020
#define GC_RESET_FLAG_ROP			0x00000040

#define GC_RESET_FLAG_ALL			0xFFFFFFFF

/*!
  \ingroup gc

*/
#define GC_RESET_FLAG_DRAWING		(GC_RESET_FLAG_COLOR |					\
									 GC_RESET_FLAG_FLAGS |					\
									 GC_RESET_FLAG_TRANSPARENT |			\
									 GC_RESET_FLAG_FONTS |					\
									 GC_RESET_FLAG_ROP |					\
									 GC_RESET_FLAG_ALL )	

#define ADJUST_GC_ORIGIN(gc, x, y) \
	{\
		if (gc->window) \
		{ \
		x+=((s_window*)gc->window)->origin_x; \
		y+=((s_window*)gc->window)->origin_y; \
		} \
		x += gc->origin_x; \
		y += gc->origin_y; \
	}

#define ADJUST_GC_ORIGIN_RECT(gc, x1, y1,x2,y2) \
	{\
		if (gc->window) \
		{ \
		x1+=((s_window*)gc->window)->origin_x; \
		y1+=((s_window*)gc->window)->origin_y; \
		x2+=((s_window*)gc->window)->origin_x; \
		y2+=((s_window*)gc->window)->origin_y; \
		} \
		x1 += gc->origin_x; \
		y1 += gc->origin_y; \
		x2 += gc->origin_x; \
		y2 += gc->origin_y; \
	}

#define GC_TYPE_BUFFER	0x00000001			//!< Memory buffer graphic context
#define GC_TYPE_WINDOW  0x00000002			//!< Physical window graphic context
#define GC_TYPE_DIB		0x00000004

/*!
  \ingroup gc

  If set, only pixels which doesn't match transparent color are drawn
*/
#define GC_FLAG_TRANSPARENT_COLOR 0x000000001	

/*!
  \ingroup gc
*/
#define GC_FLAG_FILL			  0x000000002	

/*!
  \ingroup gc

  If set, pixels are drawn with alpha value
*/
#define GC_FLAG_TRANSPARENT_ALPHA 0x000000004	

/*!
  \ingroup gc

  If set, font is draw transparent
*/
#define GC_FLAG_TRANSPARENT_FONT  0x000000008	

/*!
  \ingroup gc

  If set, raster operations are used when drawing
*/
#define GC_FLAG_ROP				  0x000000010

/*!
  \ingroup gc

  Copy source pixels over destination pixels
*/
#define GC_ROP_COPY				  0x000000000

/*!
  \ingroup gc

  Invert destionation pixels, ignore source pixels
*/
#define GC_ROP_INVERT			  0x000000001

/*!
  \ingroup gc

  XOR source and destionation pixels

*/
#define GC_ROP_XOR				  0x000000002

#define GC_ROP_BLEND			  0x000000004

/*!
  \ingroup gc

   If set, a transparent value is assigned to each pixel in a blit operation.
   This flag must be set with GC_FlagSet. The desired transparent level can
   be set with GC_TransparentLevelSet.
*/
#define GC_FLAG_TRANSPARENT_LEVEL 0x000000010

#define GC_PIPELINE_MAX_COMMAND_SIZE 64
#define DEFAULT_GC_PIPELINE_COMMANDS 24

typedef struct sGC_PipelineCommand
{
	int uiCommand;
	char pData[GC_PIPELINE_MAX_COMMAND_SIZE];
} sGC_PipelineCommand;

typedef struct sGC_Pipeline
{
	int bEnabled;
	unsigned int uiPipelineSize;
	unsigned int uiCommands;
	unsigned int uiNextCommand;
	unsigned int uiNextCommandFlush;
	sGC_PipelineCommand *pCommands;
}
sGC_Pipeline;

typedef struct GC
{
	unsigned int type;						//!< Type of GC. (buffer or windowed)


	HANDLE window;							//!< Windowed GC: Handle to physical window
	DIB			   *hDIB;					//!< Buffer   GC: Address of memory buffer

	unsigned int   width;					//!< Buffer GC: Width  of memory buffer in pixel
	unsigned int   height;					//!< Buffer GC: Height of memory buffer in pixel
    s_region       *clip;					//!< Current clip rectangle
	COLOR		   fg_color;				//!< Current foreground color
	COLOR		   bg_color;				//!< Current background color
	COLOR		   trans_color;				//!< Current transparent colorkey
	unsigned int   uiTransparentLevel;
	unsigned int   flags;					//!< GC flags. (Transparent,....)

    int (*draw_pixel)(struct GC* gc,  int x,  int y);
    int (*draw_line) (struct GC *gc, int x1, int y1, int x2, int y2);


    int (*draw_rect)(struct GC *gc, int x, int y, int width, int height);
    
	int (*draw_rect_fill)(struct GC *gc, int x, int y, int width, int height);

    int (*draw_text)(struct GC *gc, s_region *rect, char *text);

	unsigned int uiROP;

	int origin_x;
	int origin_y;
	sGC_Pipeline pPipeline;
	
	unsigned int bNoFreeDIB;

	sFont *pFont;
	unsigned int uiFontAlignment;
	unsigned int uiFontFlags;
	HANDLE hGCForWindow;
	unsigned int uiReserved[7];

} GC;

typedef struct sPolygonPoint
{
	int x;
	int y;
} sPolygonPoint;

typedef struct sPolygon
{
	sPolygonPoint *pPoints;
	int iNumPoints;
} sPolygon;

#define GC_TEXTHANDLE_FLAG_MULTICOLORS	0x00000001
#define GC_TEXTHANDLE_FLAG_DRAW_OUTLINE	0x00000002

typedef struct sTextHandlePositions
{
	COLOR uiColor;
	int iOffsetX;
	int iOffsetY;
	unsigned int uiReserved[4];
} sTextHandlePositions;

typedef struct sTextHandle
{
	unsigned int uiFlags;

	sTextHandlePositions *pTextHandlePositions;
	unsigned int uiPositions;
	int iColorOffsetX;
	int iColorOffsetY;
} sTextHandle;



/**************************************** GC Prototypes ************************************/
#ifndef KERNEL
int 	GC_FontSet (GC *gc, sFont *pFont);
HRESULT GC_FontFree(GC *gc);

sFont* GC_FontGet(GC *gc);
int GC_FontSetSize(GC *gc,	int iSize);
int GC_FontGetSize(GC *gc);
int 	GC_FontSetAlignment (GC *gc, unsigned int uiAlignment);
DIB * 	GI_ImageLoadBMP (char *filename, s_window *win);
DDB * 	GI_create_DDB_from_DIB_clip (DIB *dib, s_region *pClip);
int 	GI_DIBPaletteSet (DIB *dib, COLOR *palette);
int 	GI_DIBConvert8to8 (DIB *dib, DDB *ddb, s_region *pClip);
int 	GI_DIBDestroy (DIB *dib);
int 	GI_DDBDestroy (DDB *ddb);
int 	GI_BlitBitmap (HANDLE win, s_region *clip, unsigned int x, unsigned int y, DDB *ddb);
int 	GI_clip_DIB_to_GC (GC *pGC, int x, int y, DIB *hDIB, s_region *pClip);
int 	GI_BlitDIB (GC *gc, int x, int y, DIB *dib);
int 	GI_DIBConvert8to32 (DIB *dib, DDB *ddb, s_region *pClip);
int 	GI_DIBConvert24to32 (DIB *dib, DDB *ddb, s_region *pClip);
int 	GI_DIBConvert32to32 (DIB *dib, DDB *ddb, s_region *pClip);
unsigned int 	GI_ImageWrite (unsigned int x, unsigned int y, unsigned int bpp, char *filename, unsigned char *bitmap, unsigned char *palette);
int 	GI_Screenshot (char *filename);
DIB * 	GI_DIBRotate (DIB *dib, unsigned int uiAngle);
int 	GI_DIBConvert16to32 (DIB *sDIB, DIB *dDIB, int ro, int rm, int go, int gm, int bo, int bm, s_region *pClip);
DIB * 	GI_DIBCreate (void *data, int width, int height, int bpp, void *palette, unsigned int palette_size);
void 	GI_SetFlagDIB (DIB *hDIB, unsigned int uiFlags);
DIB * 	GI_ImageLoad (char *filename, unsigned int ImageIndex);
DIB * 	GI_ImageLoadIcon (char *filename, unsigned int uiWidth, unsigned int uiHeight, unsigned char bpp, unsigned int uiIndex);
DIB *   GI_ImageLoadIconFile(char *filename, 
					  unsigned int uiWidth,
					  unsigned int uiHeight,
					  unsigned char ucBpp,
					  unsigned int ImageIndex);

void 	GI_DIBSetPixel (DIB *hDIB, unsigned int x, unsigned int y, unsigned int color);
unsigned int 	GI_DIBGetPixel (DIB *hDIB, unsigned int x, unsigned int y);
DIB * 	GI_ConvertDIB (DIB *hSource, unsigned int uiNewBPP);
DIB * 	GI_DIBScale (DIB *_srcbitmap, int iWidth, int iHeight, int filtertype, float filterwidth);
DIB * 	GI_scale_DIB (DIB *hDIB, unsigned int uiWidth, unsigned int uiHeight);
DIB * 	GI_filter_DIB (DIB *hDIB, unsigned int uiFilterFlags, unsigned int uiFilterData1, unsigned int uiFilterData2);
DIB * 	GI_DIBDuplicate (DIB *hDIBSource, char bCopyData, char bCopyAndMask);
DIB * 	GI_DIBColorize (DIB *hDIBSource, COLOR uiColor);
DIB * 	GI_BitmapEffectColorize (DIB *hDIBSource, COLOR uiColor);
void 	GI_BitmapEffectBlurDo (unsigned char *src, int src_w, int src_h, unsigned char *dst, float *ker, int k);
GC * 	GC_Create (unsigned int type);
int 	GC_Destroy (GC *gc);
int 	GC_ConnectWindow (GC *gc, HANDLE win);
int 	GC_ConnectBuffer (GC *gc, int width, int height);
int 	GC_ConnectDIB (GC *gc, DIB *hDIB);
GC * 	GC_CreateConnected (unsigned int type, unsigned int width, unsigned int height, HANDLE win);
HRESULT GC_Swap(GC *pGC, s_region *pDirty);
int 	GC_ClipSet (GC *gc, s_region *clip);
int 	GC_ClipIntersect (GC *gc, s_region *pClip);
int 	GC_ClipIntersectGetOld (GC *gc, s_region *pClip, s_region *pOld);
int 	GC_RegionAdjustBy (s_region *pSource, s_region *pDest, int x1, int y1, int x2, int y2);
int 	GC_ClipAdjust (GC *gc, int x1, int y1, int x2, int y2);
int 	GC_ClipClear (GC *gc);
int 	GC_ColorForegroundSet (GC *gc, COLOR col);
int 	GC_ColorBackForeSet (GC *gc, COLOR fg, COLOR bg);
int 	GC_ColorBackForeTransSet (GC *gc, COLOR fg, COLOR bg, COLOR tr);
int 	GC_ColorBackgroundSet (GC *gc, COLOR col);
int 	GC_ColorTransparentSet (GC *gc, COLOR col);
int 	GC_DrawPixel (GC *gc, int x, int y);
int 	GC_DrawRect (GC *gc, int x, int y, int width, int height);
int 	GC_DrawRectFill (GC *gc, int x, int y, int width, int height);
int 	GC_DrawLine (GC *gc, int x1, int y1, int x2, int y2);
int 	GC_FontSizeSet (GC *gc, unsigned int fontSize);
int 	GC_FontFlagsSet (GC *gc, unsigned int flags);
int 	GC_FontFlagsClear (GC *gc, unsigned int flags);
int 	GC_FontParameterSet (GC *gc, unsigned int font, unsigned int fontsize, unsigned int flags, unsigned int trans);
int 	GC_FlagSet (GC *gc, unsigned int flags);
int 	GC_FlagClear (GC *gc, unsigned int flags);
int 	GC_FlagClearAll (GC *gc);
int 	GC_DrawText (GC *gc, s_region *rect, char *text);
int 	GC_DrawTextMultiline (GC *gc, s_region *rect, char *text);
int 	GC_DrawTextAdv (GC *gc, s_region *rect, char *text, sAdvTextStyle *pStyle);
int 	GC_BlitIntoGC (GC *gc, int x, int y, int w, int h, unsigned int *source, int src_x, int src_y, int src_w, int src_h);
int 	GC_blit_into_gc_tr (GC *gc, int x, int y, int w, int h, unsigned int *source, int src_x, int src_y, int src_w, int src_h, unsigned int uiTransColor);
int 	GC_BlitFromDIB (GC *gc, DIB *dib, int x, int y);
int 	GC_BlitIntoWindow (GC *gc, HANDLE win, int x, int y);
int 	GC_DrawIcon (GC *gc, char *icon, int x, int y);
int 	GC_DrawIconAdv (GC *gc, s_gi_icon *icon, int x, int y);
int 	GC_DrawCircle (GC *gc, int midx, int midy, int radx, int rady);
int 	GC_DrawCircleFill (GC *gc, int midx, int midy, int radx, int rady);
int 	GC_TransparentLevelSet (GC *gc, unsigned int uiLevel);
HRESULT 	GC_BlitAlloc (sBlit **ppBlit);
HRESULT 	GC_BlitReset (sBlit *pBlit);
HRESULT 	GC_Blit (GC *gc, sBlit *pBlit);
HRESULT 	GC_ClipGet (GC *gc, s_region *clip);
HRESULT 	GC_DrawRoundedRectFill (GC *gc, int x1, int y1, int width, int height, int r);
HRESULT 	GC_DrawRoundedRect (GC *gc, int x1, int y1, int width, int height, int r);
HRESULT 	GC_DrawGradient (GC *gc, s_region *rect, int direction, COLOR cStart, COLOR cEnd);
HRESULT 	GC_BlitDIBShape (GC *gc);
unsigned int 	GC_SetROP (GC *gc, unsigned int uiROP);
int 	GC_DrawBox (GC *pGC, s_region *pRegion, DIB *hTL, DIB *hT, DIB *hTR, DIB *hR, DIB *hBR, DIB *hB, DIB *hBL, DIB *hL, DIB *hFill, DDB *hddbTL, DIB *hddbT, DDB *hddbTR, DIB *hddbR, DDB *hddbBR, DDB *hddbB, DDB *hddbBL, DDB *hddbL, DDB *hddbFill);
int 	GC_DrawButton (GC *pGC, s_region *pRegion, DIB *hL, DIB *hFill, DIB *hR);
int 	GC_SetOrigin (GC *pGC, int x, int y);
int 	GC_GetOrigin (GC *pGC, int *x, int *y);
int 	GC_DrawFillPolygon (GC *pGC, sPolygon *pPolygon);
HRESULT 	GC_DrawRectInvert (GC *pGC, int x, int y, int width, int height);
HRESULT 	GI_ResetWindowGC (HANDLE hWnd, GC *gc, unsigned int uiFlags);
HRESULT 	GC_Get (HANDLE hWnd, GC **ppGC);
int 	GC_BufferDrawRect (GC *gc, int x, int y, int width, int height);
int 	GC_BufferDrawRectFill (GC *gc, int x, int y, int width, int height);
int 	GC_DIBConvertTo8 (GC *gc, DIB *dib, int x, int y);
HRESULT 	GI_DIBReverseLines (DIB *hDIB);
int 	GC_DIBConvertColor (DIB *hDIB, unsigned int uiNewBPP);
void 	GC_DIBSet (DIB *hDIB, int iX, int iY, unsigned int uiColor);
void 	DIB_set_rop (DIB *hDIB, int iX, int iY, unsigned int uiColor, unsigned int uiROP);
unsigned int 	GC_DIBGet (DIB *hDIB, int iX, int iY);
int 	RegionIncludesPoint (s_region *rect, int x, int y);
int 	pt_infield (int x1, int y1, int x2, int y2, int x, int y);
void 	RegionSet (s_region *region, int x1, int y1, int x2, int y2);
void 	RegionSetWin (s_region *region, s_window *win);
int 	pt_inwin (s_window *win, int x, int y);
int 	GI_RegionInRegion (s_region *b1, s_region *b2);
int 	RegionFit (s_region *fitrect, s_region *source);
int 	RegionAdjustToWindow (s_window *win, s_region *region);
int 	GC_ClipIntersects (GC *gc, s_region *pRegion);
int 	GC_ClipIntersectRegion (GC *gc, s_region *pRegion);
int 	GC_ClipIntersectsXY (GC *gc, int x1, int y1, int x2, int y2);
GC*		GC_Duplicate(GC *pOld);
int		GC_DrawTextMax(GC *gc, s_region *rect, char *text, int iBytes);
HRESULT GC_TextHandleDraw(GC *pGC, s_region *rect, HANDLE hTextHandle, char *pText, ...);
HRESULT GC_TextHandleSetPositions(HANDLE hTextHandle, sTextHandlePositions *pPositions, unsigned int uiPositions);
HRESULT GC_TextHandleSetFlag(HANDLE hTextHandle, unsigned int uiFlags);
HANDLE	GC_TextHandleAlloc(GC *pGC);
HANDLE GC_TextHandleFree(GC *pGC, sTextHandle *pTextHandle);
#endif

#endif


