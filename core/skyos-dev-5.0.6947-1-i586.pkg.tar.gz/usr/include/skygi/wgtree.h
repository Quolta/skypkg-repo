#ifndef _INC_WGTREE__
#define _INC_WGTREE__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct sTreeColumn
{
	s_region rBoundary;
	char *pHeader;
	int iWidth;
} sTreeColumn;

typedef struct sTreeColumnEntry
{
	s_region rBoundary;
	char bShow;

	HANDLE hWnd;
	void *pCookie;

	int iWidth;
	int iHeight;

	HANDLE hNode;

	struct sTreeRow *pRow;

	struct sTreeEntryInterface *pInterface; 

	union
	{
		struct
		{
			char *str;
		} pText;

		struct 
		{
			char *pBuffer;
			int iLength;
			HANDLE hEdit;
		} pEdit;

		struct
		{
			HANDLE hDropDown;
			HANDLE hListOptions;
			char *pSelected;
		} pDropDown;
	} u;

	void *pData;
} sTreeColumnEntry;

typedef struct sTreeRow
{
	s_region rBoundary;
	char bShow;

	HANDLE hChildren;

	HANDLE hColumns;

	HANDLE hNode;
	HANDLE hWnd;

	struct sTreeRow *pParent;
	struct sTreeColumnEntry *pSelected;
	int iExpanded;
	int iHeight;

	DIB *hIcon;
	void *pData;
	COLOR colBack;
} sTreeRow;

typedef struct sWidgetTree
{
	HANDLE hWnd;

	GC *pGCBack;

	int bInternSizeMessage;

	COLOR uiDefaultBackColor,uiDefaultTextColor;
	COLOR uiHeaderDefaultBack, uiHeaderDefaultFore;

	sFont *hDefaultFont;

	int iMarginsLeft, iMarginsTop;

	int iScrollOffsetY;
	HANDLE hScrV;

	sTreeRow *pRoot;

	sTreeRow *pSelected;
	sTreeRow *pFirstDisplayed;

	int iMaxHeight;

	int iMarginInitialTop;
	int iMarginInitialLeft;

	int bShowSkeleton;
	int iIconWidth;
	int bShowIcons;
	int iMarginLevel;
	int iMarginSkeleton;
	int iMarginIcon;
	int bShowHeader;

	int iColumns;
	HANDLE hColumns;
	int iColumnHeight;
	int iVisibleHeight;
	int iVisibleLastY;
	int iVisibleFirstY;
	sTreeColumn *hColumnToResize;
	int iResizeReference;
	int iResizeReferenceMouseX;

	int bCanSelectColumns;
	int bShowGrid;
	int iLineGap;
} sWidgetTree;

typedef struct sInterfaceTree
{
	sInterfaceWindow *pWindow;

	/*!
	\ingroup wgtreeview

	empty
	*/
	HRESULT (*OnDrag)(HANDLE hWnd, HANDLE hRow, HANDLE hEntry);

	/*!
	\ingroup wgtreeview

	empty
	*/
	HRESULT (*OnSelected)(HANDLE hWnd, HANDLE hRow, HANDLE hEntry, int iButton);

	/*!
	\ingroup wgtreeview

	empty
	*/
	HRESULT (*OnSelectedWithDoubleclick)(HANDLE hWnd, HANDLE hRow, HANDLE hEntry, int iButton);

	/*!
	\ingroup wgtreeview

	empty
	*/
	HRESULT (*OnPopup)(HANDLE hWnd, HANDLE hRow, HANDLE hEntry, int x, int y);

	/*!
	\ingroup wgtreeview

	empty
	*/
	HRESULT (*OnDeleteEntry)(HANDLE hWnd, HANDLE hRow, HANDLE hEntry);

	/*!
	\ingroup wgtreeview

	empty
	*/
	HRESULT (*OnChanged)(HANDLE hWnd, HANDLE hRow, HANDLE hEntry);

	/*!
	\ingroup wgtreeview

	empty
	*/
	HRESULT (*OnRemoveRow)(HANDLE hWnd, HANDLE hRow);

	unsigned int uiReserved[31];
} sInterfaceTree;
 

typedef struct sTreeEntryInterface
{
	char *ucEntryType;
	HRESULT (*Draw)(HANDLE hWnd, sTreeColumnEntry *pEntry);
	HRESULT (*OnMouse)(HANDLE hWnd, sTreeColumnEntry *pEntry, int iX, int iY, int bButton, int bPress, int bDbl, int bMotion);
	HRESULT (*Free)(HANDLE hWnd, sTreeColumnEntry *pEntry);
	HRESULT (*OnSelect)(HANDLE hWnd, sTreeColumnEntry *pEntry);
	HRESULT (*OnUnSelect)(HANDLE hWnd, sTreeColumnEntry *pEntry);
	HRESULT (*OnBoundaryChanged)(HANDLE hWnd, sTreeColumnEntry *pEntry);

} sTreeEntryInterface;
 
/*! 
	ingroup wgtreeview

	empty
*/
enum
{
	PROP_TREE_SHOW_SKELETON = 0x10000,
	PROP_TREE_SHOW_ICONS,
	PROP_TREE_ICON_WIDTH,
	PROP_TREE_MARGIN_SKELETON,
	PROP_TREE_MARGIN_LEVEL,
	PROP_TREE_MARGIN_ICON,
	PROP_TREE_SHOW_HEADER,
	PROP_TREE_CAN_SELECT_COLUMNS,
	PROP_TREE_SHOW_GRID,
	PROP_TREE_LINE_GAP
};


HANDLE 	GI_WidgetTreeViewCreate (HANDLE parent, char *name, int x, int y, int width, int height, int uiWindowFlags, unsigned int uiStyleFlags);
HRESULT 	GI_WidgetTreeViewEntryDestroy (HANDLE hWnd, sTreeColumnEntry *pEntry);
HRESULT 	GI_WidgetTreeViewEntryDropDownNew (HANDLE hWnd, char *pSelected, HANDLE hList, HANDLE *hEntry);
HRESULT 	GI_WidgetTreeViewEntryEditNew (HANDLE hWnd, char *pBuffer, int iLength, HANDLE *hEntry);
HRESULT 	GI_WidgetTreeViewEntryExpandToogle (HANDLE hWnd, HANDLE hEntry);
HRESULT 	GI_WidgetTreeViewEntryGetBoundary (HANDLE hWnd, HANDLE hEntry, s_region *pRegion);
HRESULT 	GI_WidgetTreeViewEntryGetCookie (HANDLE hWnd, HANDLE hEntry, void **ppCookie);
void * 	GI_WidgetTreeViewEntryGetData (HANDLE hEntry);
HRESULT 	GI_WidgetTreeViewEntryGetType (HANDLE hEntry, char **ppType);
HANDLE 	GI_WidgetTreeViewEntryGetWindow (HANDLE hEntry);
int 	GI_WidgetTreeViewEntryIsExpanded (HANDLE hWnd, HANDLE hEntry);
HRESULT 	GI_WidgetTreeViewEntryNew (HANDLE hWnd, int iWidth, int iHeight, HANDLE *phEntry);
HRESULT 	GI_WidgetTreeViewEntrySetCookie (HANDLE hWnd, HANDLE hEntry, void *pCookie);
HRESULT 	GI_WidgetTreeViewEntrySetData (HANDLE hEntry, void *vpData);
HRESULT 	GI_WidgetTreeViewEntrySetHeight (HANDLE hWnd, HANDLE hEntry, int iHeight);
HRESULT 	GI_WidgetTreeViewEntrySetIcon (HANDLE hEntry, DIB *hDIB);
HRESULT 	GI_WidgetTreeViewEntrySetInterface (HANDLE hEntry, void *vpInterface);
char * 	GI_WidgetTreeViewEntryTextGet (HANDLE hWnd, HANDLE hEntry);
HRESULT 	GI_WidgetTreeViewEntryTextNew (HANDLE hWnd, char *pText, HANDLE *hEntry);
int 	GI_WidgetTreeViewEntryVisible (HANDLE hWnd, HANDLE hEntry);
HRESULT 	GI_WidgetTreeViewExpandAll (HANDLE hWnd);
HRESULT 	GI_WidgetTreeViewExpandRow (HANDLE hWnd, HANDLE hRow, int bExpandChilden);
HRESULT 	GI_WidgetTreeViewGetDefaultBackcolor (HANDLE hWnd, COLOR *puiColor);
HRESULT 	GI_WidgetTreeViewGetFont (HANDLE hWnd, sFont **ppFont);
HRESULT 	GI_WidgetTreeViewGetNextChild (HANDLE hWnd, HANDLE hRowParent, HANDLE hRowIter, HANDLE *phRow);
HRESULT 	GI_WidgetTreeViewGetNextEntry (HANDLE hWnd, HANDLE hRow, HANDLE hEntryIter, HANDLE *phEntry);
HANDLE 	GI_WidgetTreeViewGetParent (HANDLE hWnd, HANDLE hRow);
HRESULT 	GI_WidgetTreeViewGetSelectedEntry (HANDLE hWnd, HANDLE pRow, HANDLE *phEntry);
HRESULT 	GI_WidgetTreeViewGetSelectedRow (HANDLE hWnd, HANDLE *phRow);
HRESULT 	GI_WidgetTreeViewInsertColumn (HANDLE hWnd, int iWidth, char *pHeader);
HRESULT 	GI_WidgetTreeViewInsertRow (HANDLE hWnd, HANDLE hParent, HANDLE hRow, HANDLE hReference, int iWhere);
HRESULT 	GI_WidgetTreeViewPropertySet (HANDLE hWnd, char bSet, unsigned int uiProperty, unsigned int uiValue);
HRESULT 	GI_WidgetTreeViewRebuildLayout (HANDLE hWnd);
HRESULT 	GI_WidgetTreeViewRemoveAll (HANDLE hWnd);
HRESULT 	GI_WidgetTreeViewRemoveRow (HANDLE hWnd, HANDLE hRow);
HANDLE 	GI_WidgetTreeViewReparentRow (HANDLE hWnd, HANDLE hRow, HANDLE hParent, int bHead);
void * 	GI_WidgetTreeViewRowGetData (HANDLE hRow);
int 	GI_WidgetTreeViewRowHasChildren (HANDLE hWnd, HANDLE hRow);
HRESULT 	GI_WidgetTreeViewRowInsertEntry (HANDLE hWnd, HANDLE hRow, HANDLE hEntry);
HRESULT 	GI_WidgetTreeViewRowRemoveEntry (HANDLE hWnd, HANDLE hRow, HANDLE hEntry);
HRESULT 	GI_WidgetTreeViewRowSetData (HANDLE hRow, void *vpData);
HRESULT 	GI_WidgetTreeViewSetSelected (HANDLE hWnd, HANDLE hRow, HANDLE hEntry);
int 	GI_WidgetTreeViewSizeInProgress (HANDLE hWnd);
HRESULT 	GI_WidgetTreeViewUnlink (HANDLE hWnd, sTreeRow *pEntry);



#ifdef __cplusplus
}
#endif

#endif 