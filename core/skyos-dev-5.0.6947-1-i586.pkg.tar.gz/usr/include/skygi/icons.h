#ifndef __ICONS_H_
#define __ICONS_H_

#define GI_ICON_BUTTON_CLOSE       1
#define GI_ICON_APP_NORMAL  2
#define GI_ICON_APP_SHELL   3
#define GI_ICON_BUTTON_MINI 4
typedef struct s_gi_icon
{
	DIB *dib;
	unsigned int width;
	unsigned int height;
	unsigned char *data;
} s_gi_icon;

#endif


