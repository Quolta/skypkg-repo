#ifndef INC_THEME__
#define INC_THEME__

#include "skyos/libskyos.h"
#include "skyos/syscall.h"
#include "skyos/types.h"

enum _WIDGETTYPES
{
	WIDGET_DEFAULT = 0,
	WIDGET_FRAME,
	WIDGET_BUTTON
};

typedef struct sThemeProperties
{
	unsigned int uiTitleHeightSmall;
	unsigned int uiTitleHeightNormal;
	unsigned int uiMenuBarHeight;
	unsigned int uiToolbarHeight;
	unsigned int uiStatusBarHeight;
	unsigned int uiMinFrameWidth;
	unsigned int uiPropertyTabHeight;
	unsigned int uiStatusBarOffset;
} sThemeProperties;

typedef struct sThemeInterface
{
	HRESULT (*Init)(unsigned int *puiVersion);
	HRESULT (*DrawBackground_Button)(GC *gc, s_window *hWnd, s_region *pRegion, char bPressed, char bHover);
	HRESULT (*DrawFrameBackground)(GC *gc, s_window *hWnd, s_region *pRegion);
	HRESULT (*DrawTitle)(GC *gc, s_window *win, s_region *pRegion, unsigned int uiIcon);
	HRESULT (*DrawFrame)(GC *gc, s_window *hWnd, s_region *pRegion, char bInvers);
	HRESULT (*GetBoundary)(s_window *hWnd, s_region *pRegion);
	HRESULT (*DrawMainWindowFrame)(GC *gc, s_window *hWnd, s_region *pRegion);
	HRESULT (*GetMainWindowBoundary)(s_window *hWnd, s_region *pRegion);
	HRESULT (*CreateFrameWindow)(s_window *hWnd, sCreateApplication *pCreate);
	HRESULT (*GetMainWindowShadowWidth)(unsigned int uiFrameStyle, int *width, int *height);
	HRESULT (*MainWindowMessage)(s_window *hWnd, s_gi_msg *pMsg);
	HRESULT (*MainWindowApply)(s_window *hWnd);
	HRESULT (*Changed)(s_window *hWnd);
	HRESULT (*GetThemeProperties)(sThemeProperties *pThemeProperties);
	HRESULT (*DrawScrollbarIndicator)(s_window *hWnd, GC *gc, int iStart, int iEnd, char bShow);
	HRESULT (*DrawScrollbarBack)(s_window *hWnd, GC *gc);
	HRESULT (*GetScrollbarProperties)(s_window *hWnd, int *pWidth, int *pHeight, int *pMinSize,
		int *pButtonWidth,
		int *pButtonHeight);
	HRESULT (*DrawListboxCaption)(GC *gc, s_window *hWnd, int y,
								int ts, int te, sFont *pFont,
								char *text);
	unsigned int (*TitleMouseAction)(s_window *hWnd,
								int mx, int my, int but, int pressed, int dbl, int leaved);
	HRESULT (*ThemeInitOnce)(void);
	HRESULT (*ThemeCheckFrameMousePointer)(HANDLE hWnd, int x, int y);
	HRESULT (*InitFrameWindow)(s_window *hWnd, sCreateApplication *pCreate);
	HRESULT (*InitTitleWindow)(s_window *hWnd);
	char *(*MakeResourcePath)(char *ucBuffer, char *ucRelative);
	HRESULT (*GetClientBoundary)(s_window *hWnd, s_region *pRegion);
	HRESULT (*DrawWidgetBackground)(GC *gc, s_window *hWnd, s_region *pRegion);
	unsigned int (*GetFrameWidth)(s_window * win, int *uiYOffset, int *uiYEnd);
	HRESULT (*DrawClientBackground)(GC *gc, s_window *hWnd, s_region *pRegion);
	HRESULT (*DrawInnerFrame)(GC *gc, s_window *hWnd);
	HRESULT (*CreateButtonWindowShape)(s_window *hWnd);
	HRESULT (*DrawButtonFrame)(GC *gc, s_window *win, s_region *pRegion, char bInvers, char bInner);
	unsigned int (*GetColor)(unsigned int uiID);
	HRESULT (*GetIcon)(unsigned int uiID);
	HRESULT (*GetMinimumButtonSize)(s_region *r);
	HRESULT (*DrawFrameBox)(GC *gc, s_window *win);
	HRESULT (*DrawEditField)(GC *gc, s_window *win);
	HRESULT (*DrawCheck)(GC *gc, s_window *win);
	HRESULT (*DrawRadio)(GC *gc, s_window *win);
	HRESULT (*CreateCombo)(HANDLE parent,
							char *name,
							int x, int y, int width, int height,
							int uiEditWidth, int uiEditHeight,
							int style, unsigned int uiID, void* fp);
	HRESULT (*DrawCombo)(GC *gc, s_window *win);
	HRESULT (*ComboMouse)(s_window *win, int x, int y);
	int (*GetShadowSize)(HANDLE hWnd, int ucWhere);
	HRESULT (*DrawSplitter)(GC *gc, s_window *win);
	HRESULT (*DrawPropertyBorder)(GC *gc, s_window *win);
	HRESULT (*DrawPropertyTabs)(GC *gc, s_window *win);
	unsigned int (*GetPropertyTabHeight)(s_window *win);
	HRESULT (*DrawProgressBar)(GC *gc, s_window *win);
	unsigned int (*GetProperty)(unsigned int uiProperty);
	HRESULT (*DrawStatusBar)(GC *gc, s_window *win); 
	int (*GetTitleWidth)(char *pTitle);

} sThemeInterface;

typedef struct sTheme
{
	char ucPath[255];
	char ucName[255];
	char ucStyleName[255];
	sThemeInterface pInterface;
	unsigned char *pStyleBuffer;
} sTheme;

extern sTheme *pActiveTheme;

#endif


 
