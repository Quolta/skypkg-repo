/*
\defgroup wgIcon Icon box
*/
#ifndef _INC_wgIcon_
#define _INC_wgIcon_

typedef struct widget_icon_item
{
	struct widget_icon_item *pNext;
	struct widget_icon_item *pPrev;
	char pText[255];
	unsigned int  uiID;
	DIB           *hDIB;
	unsigned int  uiWidth;
	unsigned int  uiHeight;
	unsigned int  uiX;
	unsigned int  uiY;
	s_region      rRect;
} widget_icon_item;


typedef struct widget_icon
{
	HANDLE hWnd;

	widget_icon_item *pFirst;
    unsigned int uiFont;
	unsigned int uiFontSize;
	unsigned int uiBackGroundColor;
	unsigned int uiTextColor;
	unsigned int uiTextBackColor;
	unsigned int uiStyle;
} widget_icon;

#endif


