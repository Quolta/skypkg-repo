#ifndef __INCLUDE_SKYGI_KEYS_
#define __INCLUDE_SKYGI_KEYS_

#define KEY_INSERT		0x52
#define KEY_DEL			0x53
#define KEY_HOME		0x47
#define KEY_END			0x4F
#define KEY_PGUP		0x49
#define KEY_PGDOWN		0x51

#define KEY_UP			0x48
#define KEY_DOWN		0x50
#define KEY_LEFT		0x4B
#define KEY_RIGHT		0x4D

#define KEY_BACKSPACE   0x08
#define KEY_ENTER         13

#define KEY_F1			59
#define KEY_F2			60
#define KEY_F3			61
#define KEY_F4			62
#define KEY_F5			63
#define KEY_F6			64
#define KEY_F7			65
#define KEY_F8			66
#define KEY_F9			67
#define KEY_F10			68
#define KEY_F11			87
#define KEY_F12			88

#define KEY_MOD_SHIFT		0x01
#define KEY_MOD_CTRL		0x02
#define KEY_MOD_ALT			0x04
#define KEY_MOD_ALTGR		0x08
#endif



