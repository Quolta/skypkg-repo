#ifndef __INCLUDE_PROPERTY_
#define __INCLUDE_PROPERTY_
#ifdef __cplusplus

extern "C" {
#endif

/*
   Widget specific properties must start with 0x10000
*/
enum
{
	PROP_COLOR_FOREGROUND = 1,
	PROP_COLOR_BACKGROUND,
	PROP_COLOR_TEXT_FOREGROUND,
	PROP_COLOR_TEXT_BACKGROUND,
	PROP_COLOR_FILL,
	PROP_COLOR_FRAME,
	PROP_COLOR_CAPTION_FILL,
	PROP_COLOR_CAPTION_FRAME,
	PROP_COLOR_CAPTION_TEXT,
	PROP_COLOR_MAIN_TEXT,
	PROP_COLOR_FILL_SELECTED,
	PROP_COLOR_FILL_NOTSELECTED,
	PROP_COLOR_TEXT_SELECTED,
	PROP_COLOR_TEXT_NOTSELECTED,
	PROP_SHOW_HYPERLINK_UNDERSCORE,
	PROP_ICON_DIB,
	PROP_HEIGHT_ITEM,
	PROP_SHOW_FRAME,
	PROP_USE_PARENT_BACKGROUND,
	PROP_FONT,

	STYLE_PROP_MARGIN_LEFT,
	STYLE_PROP_MARGIN_TOP


};

typedef int (*fpProperty)(HANDLE hWnd, char bSet, unsigned int uiProperty, unsigned int uiData);
	
HRESULT GI_WidgetSetProperty(HANDLE hWnd,
							 fpProperty func,
							 unsigned int uiProperty,
							 ...);

HRESULT GI_WidgetStaticPropertySet(HANDLE hWnd, 
								  char bSet,
								  unsigned int uiProperty,
								  unsigned int uiValue);

HRESULT GI_WidgetListboxPropertySet(HANDLE hWnd, 
								  char bSet,
								  unsigned int uiProperty,
								  unsigned int uiValue);

HRESULT GI_WidgetPanelPropertySet(HANDLE hWnd, 
								  char bSet,
								  unsigned int uiProperty,
								  unsigned int uiValue);

#ifdef __cplusplus
}
#endif

#endif


