#ifndef _INC_CTRLC_
#define _INC_CTRLC_

#include <syscall.h>
#include <skygi/skygi.h>
#include <skygi/ctrlc.h>
#include <skygi/icons.h>

typedef struct sSkyGI_WindowClass
{
	unsigned char szName[255];
	unsigned int (*pWindowFunction)(HANDLE win, s_gi_msg *m);
} sSkyGI_WindowClass;

HRESULT SkyGI_RegisterWindowClass(sSkyGI_WindowClass *wndclass);
HRESULT SkyGI_WindowClass_Init(void);
HRESULT SkyGI_RegisterDefaultWindowClasses(void);


#endif

