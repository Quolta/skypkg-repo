#ifndef __INCLUDE_GILAYER_
#define __INCLUDE_GILAYER_

enum
{
	GI_LAYER_TYPE_MEMORY = 0,
	GI_LAYER_TYPE_SCREEN,
	GI_LAYER_TYPE_VRAM
};

enum
{
	GI_LAYER_COMMAND_CREATE = 0,
	GI_LAYER_COMMAND_BLIT,
	GI_LAYER_COMMAND_MAP
};


typedef struct sGILayerCommand
{
	int iCommand;
	int iLayerType;
	int iWidth;
	int iHeight;
	unsigned int uiSize;
	void *vpAddr;
	void *vpLayerHandle;
	int iX;
	int iY;
	void *hGIWM;
	s_region rClip;
} sGILayerCommand;


typedef struct sGILayer
{
	int iRefCount;
	DIB *hDIB;
	void *vpLayerHandle;

} sGILayer;
#endif
