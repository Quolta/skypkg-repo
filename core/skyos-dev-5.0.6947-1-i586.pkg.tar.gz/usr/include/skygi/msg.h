#ifndef _INC_MSG_
#define _INC_MSG_

/*!
  \defgroup WM libskygi - Window messages

  SkyOS messages.

  00000 - 10099			SkyGI WM / Kernel message\n
  10100 - 10199			wgCombo\n
  10200 - 10299			wgText  \n
  10300 - 10399			wgListbox \n 
  10400 - 10499			wgClient \n
  10500 - 10599			wgTitle  \n
  10800 - 11999			Common widget messages\n
  12000 - 12099			wgTree\n
  13000 - 13099			wgPopup\n
  14000 - 14099			wgCheck\n
  14100 - 14199			wgStyle\n

  Note: Widget messages are defined in msg_widget.h
*/
#define WM_WG_RANGE_WGCOMBO_START		10100
#define WM_WG_RANGE_LISTBOX_START		10300
#define WM_WG_RANGE_TEXTFIELD_START		10200
#define WM_WG_RANGE_TREE_START			12000
#define WM_WG_RANGE_POPUP				13000
#define WM_WG_RANGE_PROP_START  		14000
#define WM_WG_RANGE_CHECKBOX_START		15000
#define WM_WG_RANGE_RADIOBUTTON_START	16000


#define MSG_MOUSE_INT                                            160
#define MSG_MOUSE_MOVE                                           161
        #define MSGT_MOUSE_X                     u.lpara1
        #define MSGT_MOUSE_Y                     u.lpara2


#define MSG_GUI_REDRAW_ALL                                       171
#define MSG_GUI_REDRAW_WINDOW                                    172
#define MSG_GUI_WINDOW_CREATED                                   173
#define MSG_GUI_WINDOW_CLOSE                                     174
#define MSG_GUI_WINDOW_MOVED                                     175
#define MSG_GUI_WINDOW_SIZED                                     176
#define MSG_GUI_CREATE_WINDOW                                    179
        #define MSGT_GUI_X                       u.lpara2
        #define MSGT_GUI_Y                       u.lpara3
        #define MSGT_GUI_LENGTH                  u.lpara4
        #define MSGT_GUI_WIDTH                   u.lpara5
        #define MSGT_GUI_TASK                    u.vppara1
        #define MSGT_GUI_WNAME                   u.cppara1
        #define MSGT_GUI_WINADR                  u.vppara2
        #define MSGT_GUI_FLAGS                   u.cpara1
#define MSG_GUI_CLOSE_WIN                                        180
        #define MSGT_GUI_WINDOW                  u.vppara1
	    #define MSGT_GUI_WINFUNC				 u.vppara2

#define MSG_GUI_WINDOW_CLOSE_REPLY                               181
#define MSG_GUI_WINDOW_SWITCH					  182
#define MSG_GUI_DRAW_VLINE                                       183
        #define MSGT_GUI_X1                      u.lpara1
        #define MSGT_GUI_Y1                      u.lpara2
        #define MSGT_GUI_X2                      u.lpara3
        #define MSGT_GUI_Y2                      u.lpara4
        #define MSGT_GUI_COLOR                   u.lpara5
#define MSG_GUI_REDRAW_EX                                        184
        #define MSGT_GUI_RECT                    u.vppara1

#define MSG_GUI_REDRAW_CONTROL                                   185

#define MSG_INPUT_SOURCE_EVENT								 186

/************************ Message Window messages ********************/
#define MSG_SHOW_MSG                                             202
        #define MSGT_STRING_ADDRESS              u.lpara1
		#define MSGT_SHOW_ERROR					 u.lpara2

/**************************** Console messages ***********************/
#define MSG_CONSOLE_GETCH                                        203
#define MSG_CONSOLE_GETCH_REPLY                                  204
        #define MSGT_CONSOLE_CHAR                u.cpara1
#define MSG_CONSOLE_PRINT                                        205
        #define MSGT_CONSOLE_STR                 u.lpara1
#define MSG_CONSOLE_CLEAR                                        206
#define MSG_CONSOLE_HIDE_OUTPUT                                  207
#define MSG_CONSOLE_SHOW_OUTPUT                                  208

/**************************** SKY Panel messages ***********************/
#define MSG_SKYPANEL_ADD_APP                                        209
#define MSG_SKYPANEL_DEL_APP                                        210
        #define MSGT_GUI_WID                       u.lpara1

#define MSG_TRASH                                                   245
#define MSG_TRASH_PAGE                                              246
        #define MSGT_TRASH_ADDR                    u.lpara1

#define MSG_REAP                                                   247
        #define MSG_REAP_PID						u.lpara1

/***************************** Timer messages ************************/
#define MSG_TIMER_CLOCKS                                         300

/************************* Msgbox messages ***************************/
#define MSG_SHOW	                                             301
#define MSG_ALERT_CHECKED                                        302

#define MSG_TIMER                                               420
#define MSG_REPLY                                               540

#define MSG_CRITICAL                                            500

#define MSG_SOUND_PLAY_BUFFER                                   700
#define MSG_SOUND_PLAY_SYSTEM                                   700
        #define MSGT_SOUND_PLAY_BUF               u.cppara1
        #define MSGT_SOUND_PLAY_SIZE              u.lpara1
#define MSG_SOUND_PLAY_FIN                                      701

/*! 
  \ingroup WM

  Sent to a window when the focus is about to be switched away from the window. This message 
  is only sent when the uses presses the TAB key.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		Receiving window can store the desired destination window here. 
*/
#define MSG_WANT_FOCUS_SWITCH									720

/*! 
  \ingroup WM

  Sent to a window when the focus is about to be switched away from a child window. This message 
  is only sent when the uses presses the TAB key.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		Receiving window can store the desired destination window here. 
  \param uiPara2		Child window which is about to lose the focus
*/
#define MSG_CHILD_WANT_FOCUS_SWITCH								721

#define MSG_FOCUS_ACCELERATOR									722

#define MSG_EXCEPTION                                           800

#define MSG_MSGBOX_REPLY                                        900

#define MSG_LOGON                                               1000
#define MSG_LOGON_REPLY                                         1001

#define MSG_DEBUG_EVENT                                         2000
        #define MSGT_DEBUG_TASK                   u.lpara1

#define MSG_PERFORMANCE                                         2050
#define MSG_PROMPT								3000

/*! 
  \ingroup WM

  Sent to a window when the window region or a part of it must be redrawn

  \par Description:

  \par Sender:
  - SkyGI\n
  Sends this message for the inital draw of a window after it has been created and
  whenever some regions of the window become dirty or the window was moved/sized\n

  \param uiPara1		GC which must be used when drawing. Type: GC
  \param uiPara2		undefined
  \param rect			Contains the dirty rectangle or NULL when the entire window should be redrawn.\n
						This parameter can used for GI_set_clip() the set the clip rectangle to the dirty rectangle
*/
#define MSG_GUI_REDRAW                                           170
#define MSG_GUI_MAXIMIZE										 189
/*! 
  \ingroup WM

  Sent to a window when the window region or a part of it must be redrawn, but the content should be
  drawn into a foreign window.

  \par Description:

  \par Sender:
  - SkyGI\n
  Sends this message for the inital draw of a window after it has been created and
  whenever some regions of the window become dirty or the window was moved/sized\n

  \param uiPara1		GC which must be used when drawing. Type: GC
  \param uiPara2		undefined
  \param rect			Contains the dirty rectangle or NULL when the entire window should be redrawn.\n
						This parameter can used for GI_set_clip() the set the clip rectangle to the dirty rectangle
*/
#define MSG_GUI_REDRAW_FOREIGN									 198


#define MSG_OWNER_DRAW											 171
#define MSG_GUI_DRAW_CHILD										 2060

/*! 
  \ingroup WM

  Sent to a window when it lost the focus.

  \par Description:
*/
#define MSG_GUI_WINDOW_FOCUS_LOST                                177

/*! 
  \ingroup WM

  Sent to a window when it got the focus.

  \par Description:
*/
#define MSG_GUI_WINDOW_FOCUS_GET                                 178

/*! 
  \ingroup WM

  Sent to a window when the mouse button 1 was pressed.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		X coordinate
  \param uiPara2		Y coordinate
*/
#define MSG_MOUSE_BUT1_PRESSED                                   162

/*! 
  \ingroup WM

  Sent to a window when the mouse button 2 was pressed.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		X coordinate
  \param uiPara2		Y coordinate
*/
#define MSG_MOUSE_BUT2_PRESSED                                   163

/*! 
  \ingroup WM

  Sent to a window when the mouse button 1 was released.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		X coordinate
  \param uiPara2		Y coordinate
*/

#define MSG_MOUSE_BUT1_RELEASED                                  164

/*! 
  \ingroup WM

  Sent to a window when the mouse button 2 was released.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		X coordinate
  \param uiPara2		Y coordinate
*/

#define MSG_MOUSE_BUT2_RELEASED                                  165

/*! 
  \ingroup WM

  Sent when the mouse is moved inside the window. This message is only sent when mouse tracking
  for this window was activated with GI_MouseTrackingEnable.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		X coordinate
  \param uiPara2		Y coordinate

  \sa
	GI_MouseTrackingEnable
*/
#define MSG_MOUSE_MOVED											 166

/*! 
  \ingroup WM

  Sent when the mouse enters the window

  \par Description:

  \par Sender:
  - SkyGI\n

  \sa
	GI_MouseTrackingEnable
*/
#define MSG_MOUSE_ENTER											 167

/*! 
  \ingroup WM

  Sent when the mouse leaves the window

  \par Description:

  \par Sender:
  - SkyGI\n

  \sa
	GI_MouseTrackingEnable
*/
#define MSG_MOUSE_LEAVE											 168

/*! 
  \ingroup WM

  Sent to a window when the mouse button 1 was doubeclicked.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		X coordinate
  \param uiPara2		Y coordinate
*/
#define MSG_MOUSE_BUT1_DOUBLE                                    290

/*! 
  \ingroup WM

  Sent to a window when the mouse button 2 was doubeclicked.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		X coordinate
  \param uiPara2		Y coordinate
*/
#define MSG_MOUSE_BUT2_DOUBLE                                    291


/*! 
  \ingroup WM

  Sent to all windows when the desktop resolution was changed

  \par Description:

  \par Sender:
  - SkyGI\n
*/
#define MSG_GEOMETRY_CHANGED									 2100

/*! 
  \ingroup WM

  Sent to all windows when the theme was changed.

  \par Description:

  \par Sender:
  - SkyGI\n
*/
#define MSG_THEME_CHANGED										 2101


/*! 
  \ingroup WM

  Sent to all windows when the theme was changed.

  \par Description:

  \par Sender:
  - SkyGI\n
*/
#define MSG_THEME_DLL_CHANGED										 2102

#define MSG_TRANSLATION_CHANGED										2103

#define MSG_FONTS_CHANGED											2104
/*!
  \ingroup WM
*/
#define MSG_PARENT_SIZED										 2105


/*! 
  \ingroup WM

  Sent to a window when a key was pressed.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		UTF8 keycode
  \param uiPara2		Bits 32-16 ... Virtual Key code\n
						Bit		 2 ... ALT was down while key was pressed\n
						Bit		 1 ... CTRL was down while key was pressed\n
						Bit		 0 ... SHIFT was down while key was pressed\n
*/
#define MSG_KEY_DOWN											 2500

/*! 
  \ingroup WM

  Sent to a window when a key was released.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		UTF8 keycode
  \param uiPara2		Bits 32-16 ... Virtual Key code\n
						Bit		 2 ... ALT was down while key was released\n
						Bit		 1 ... CTRL was down while key was released\n
						Bit		 0 ... SHIFT was down while key was released\n
*/
#define MSG_KEY_UP												 2501

/*! 
  \ingroup WM

  Sent to a window from a child button like window which can fire a command.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		ID sent from button
*/
#define MSG_COMMAND												 2505

/*! 
  \ingroup WM

  Sent to a window from a child button like window when rightclicking on it.

  \par Description:

  \par Sender:
  - SkyGI\n

  \param uiPara1		ID sent from button
*/
#define MSG_COMMAND_RIGHT										 2506

#define MSG_KEY_ACCELERATOR										 2507

/*!
  \ingroup WM
*/
#define MSG_ENABLE												 2510


/*!
  \ingroup WM
*/
#define MSG_TIMER_REACHED										 2520

/*!
  \ingroup WM
*/
#define MSG_QUIT												 2600

/*!
  \ingroup WM
*/
#define MSG_DESTROY												 2700
#define MSG_PRE_DESTROY											 MSG_WINDOW_DESTROY
#define MSG_DESTROY_WINDOW												 2701

/*!
  \ingroup WM
*/
#define MSG_MOUSE_BUT3_PRESSED                                  2820

/*!
  \ingroup WM
*/
#define MSG_MOUSE_BUT3_RELEASED                                  2821

/*!
  \ingroup WM
*/
#define MSG_MOUSE_BUT3_DOUBLE                                    2822

/*!
  \ingroup WM
*/
#define MSG_MOUSE_WHEEL_MOVED									  2823

#define MSG_DRAG_AND_DROP_MOTION								  2824
#define MSG_DRAG_AND_DROP_DROP									  2825


#define MSG_APPLICATION_WINDOW_FOCUS_GET						  2826
#define MSG_APPLICATION_WINDOW_FOCUS_LOST						  2827
#define MSG_WINDOW_REBUILD										  2828
/*!
  \ingroup WM
*/
#define MSG_GUI_GFX_SETUP										 3000

/*!
  \ingroup WM
*/
#define MSG_GUI_GFX_SETUP_DONE									 3001


/*!
  \ingroup WM
*/
#define MSG_SB_NOTIFY											 4000

/*!
  \ingroup WM
*/
#define MSG_SLIDER_NOTIFY										 4005

#define MSG_POPUP_CLOSE											  4023
#define MSG_POPUP_CLOSE_DONE								      4024
#define MSG_REQUEST_MENU_HANDLE									  4025
#define MSG_POPUP_CLOSE_CHAIN									  4026
/*!
  \ingroup WM
*/
#define MSG_APPLICATIONS_CHANGED								 4100
#define MSG_APPLICATIONS_SWITCHED								 4101

#define MSG_WINDOW_SHOW											 4389
#define MSG_CHILD_NOTIFY										 4390

#define MSG_DESKTOP_CHANGED										 4391

#define MSG_WINDOW_ACTIVATE										 4392
#define MSG_WINDOW_DEACTIVATE									 4393

#define MSG_COMPOSE_REQUEST										 4394
/*! 
  \ingroup WM

  Sent to a window when it was resized

  \par Description:
  When a window was resized with GI_WindowDimensionSetNotify and the notify parameter was TRUE,
  this message is sent to the resized window.

  \par Sender:

  \param uiPara1		Delta width change value
  \param uiPara2		Delta height change value
  \param rect			Contains the new window rectangle.

  \sa GI_WindowDimensionSetNotify
*/
#define MSG_WINDOW_SIZED										 4123
#define MSG_WINDOW_MOVED										 4124
#define MSG_WINDOW_FRAME_SIZED									 4125
#define MSG_WINDOW_SIZED_PRE									 4126
#define MSG_WINDOW_FRAME_MOVED									 4127
#define MSG_WINDOW_SIZE_CHANGED									 4128
#define MSG_WINDOW_POSITION_CHANGED								 4129
#define MSG_MOUSE_CAPTURE_LOST									 4155



/*! 
  \ingroup WM

  Sent to a window before it gets resized

  \par Description:
  A window function can adjust the size parameters passed in a s_region structure in para1.
  x1 and y1 are the top-left coordinates, x2 and y2 specifies the width and height

  \par Sender:

  \param uiPara1		resize parameters passed as s_region
  \sa GI_WindowDimensionSetNotify
*/
#define MSG_WINDOW_SIZE											 4156

#define MSG_REQUEST_APPLICATION_HELP							 4157


/*! 
  \ingroup WM

  Sent to a window before it the calling GI_WindowCreate function returns.

  \par Description:
  Whenever a new window is created, GI_WindowCreate posts this message into the
  message queue.

  \par Sender:

  \sa GI_WindowCreate
*/
#define MSG_WINDOW_CREATE										 4158

/*!
  \ingroup WM
*/
#define MSG_PALETTE_CHANGED										 4700
#define MSG_DATA												 4701
#define MSG_DATA_TRAY_ICON_ADD									 4702
#define MSG_TRAY_ICON_LEFT										 4703
#define MSG_TRAY_ICON_RIGHT										 4704

#define MSG_SYSTEM_SHUTDOWN_REQUESTED							 4750
#define MSG_LISTEN_NOTIFY										 4810

#define MSG_POPUP_BACKGROUND_DRAW									4811


/*! 
  \ingroup WM

  Sent to a window when it gets destroyed

  \par Description:
  On receive of this message, the parent window (if there is one) is still valid.
*/
#define MSG_WINDOW_DESTROY											4812

/*! 
  \ingroup WM

  Sent to a window when one of its children gets destroyed

  \par Description:
  
  \par Sender:

  \param uiPara1		HANDLE of child window

  \sa
*/
#define MSG_WINDOW_DESTROY_CHILD									4813

#define MSG_RELAYOUT												4814
/*!
  \ingroup WM
*/
#define MSG_DEBUG_NOTIFY									     4999

/*
  SkyGI V2+
*/
#define WM_CREATE												 10000

#define MSG_POPUP_KEEP_OPEN										 13000

#define MSG_STYLE_LINK_PRESSED									  14100
struct ipc_message
{
  volatile int type;
  unsigned int   sender;
  unsigned int   reciever;

  struct sTask *source;

  struct
  {
    int lpara1;
    int lpara2;
    int lpara3;
    int lpara4;
    int lpara5;
    int cpara1;
    int cpara2;
    char* cppara1;
    char* cppara2;
    char* cppara3;
    char* cppara4;
    char* cppara5;
    void *vppara1;
    void *vppara2;
    int *ippara1;
  }u;
  struct ipc_message *next;
} ;

#define MT_GUI_RESID						u.lpara1


#define MID_GUI_BUTTON_PRESSED					5100
#define MID_GUI_TEXT_CHANGED  					5200
#define MID_GUI_MENU_SELECTED					5300


void wait_msg(struct ipc_message * message, int type);
int send_msg(struct sTask *t,   struct ipc_message *m);
unsigned int recvEvent(unsigned int mask, unsigned int *event);
unsigned int sendEvent(struct sTask *t,   unsigned int event);
unsigned int recvEventMsg(unsigned int mask, unsigned int *event);

#ifndef KERNEL
#ifndef __SKYGI_CPP__
#include "skygi/msg_widget.h"
#endif
#endif
#endif


