#ifndef __INC_ENCODING_H__
#define __INC_ENCODING_H__

#include <string>

namespace SkyGI
{

inline int utf8_char_length( unsigned char ucFirstByte )
{
    return( ((0xe5000000 >> ((ucFirstByte >> 3) & 0x1e)) & 3) + 1 );
} 

inline int utf8_to_unicode( const char* pzSource )
{
    if ( (pzSource[0]&0x80) == 0 ) 
	{
		return( *pzSource );
    } 
	else if ((pzSource[1] & 0xc0) != 0x80) 
	{
        return( 0xfffd );
    } 
	else if ((pzSource[0]&0x20) == 0) 
	{
		return( ((pzSource[0] & 0x1f) << 6) | (pzSource[1] & 0x3f) );
    } 
	else if ( (pzSource[2] & 0xc0) != 0x80 ) 
	{
        return( 0xfffd );
    } 
	else if ( (pzSource[0] & 0x10) == 0 ) 
	{
		return( ((pzSource[0] & 0x0f)<<12) | ((pzSource[1] & 0x3f)<<6) | (pzSource[2] & 0x3f) );
    } 
	else if ((pzSource[3] & 0xC0) != 0x80) 
	{
        return( 0xfffd );
    } 
	else 
	{
		int   iValue;
		iValue = ((pzSource[0] & 0x07)<<18) | ((pzSource[1] & 0x3f)<<12) | ((pzSource[2] & 0x3f)<<6) | (pzSource[3] & 0x3f);
		return( ((0xd7c0+(iValue>>10)) << 16) | (0xdc00+(iValue & 0x3ff)) );
    }
} 
}

#endif

