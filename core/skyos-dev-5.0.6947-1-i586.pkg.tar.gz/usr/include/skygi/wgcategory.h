#ifndef _INC_WGCATEGORY__
#define  _INC_WGCATEGORY__

#define CATEGORY_TYPE_APPLICATIONS			 "Applications"
#define CATEGORY_TYPE_ARCHIVES				 "Archives"
#define CATEGORY_TYPE_IMAGES				 "Images"
#define CATEGORY_TYPE_MULTIMEDIA			 "Multimedia"
#define CATEGORY_TYPE_VIDEOS				 "Videos"
#define CATEGORY_TYPE_MUSIC					 "Music"
#define CATEGORY_TYPE_DOCUMENTS				 "Documents"
#define CATEGORY_TYPE_FONTS					 "Fonts"
#define CATEGORY_TYPE_SOURCES_AND_PROJECTS	 "Sources and project"

#ifdef __cplusplus
extern "C" {
#endif

enum
{
	CATEGORY_INSERT_WHERE_END = 0,
	CATEGORY_INSERT_WHERE_SORTED_ASC,
};

#define ID_CATEGORY_COLLAPSE_ALL 10000
#define ID_CATEGORY_EXPAND_ALL 10001

#define INDENT_WIDTH 20

#define MAX_CATEGORY_HEADERS 20

enum
{
	SEARCH_CALLBACK_FOUND,
	SEARCH_CALLBACK_DONE
};

typedef struct sCategoryDescription
{
	char *pDescription;
	char *pSearchString;
} sCategoryDescription;

typedef struct sCategorySearchCallbackInfo 
{ 
	HANDLE hMenu;
	void   *pEntryCookie;
} sCategorySearchCallbackInfo;

typedef struct sCategorySearchInfo
{ 
	int iThread;
} sCategorySearchInfo;

typedef HRESULT (*fpWidgetCategorySearchCallback)(HANDLE hWnd,
												  HANDLE hSearch,
												  void   *pCookie,
												  char   *pPath,
												  unsigned int uiDevice,
												  unsigned long long vnode,
												  sCategorySearchCallbackInfo *pInfo);

typedef HRESULT (*fpWidgetCategorySearchCallbackDone)(HANDLE hWnd,
													  HANDLE hSearch,
													  void   *pCookie,
													  int iFiles);

typedef struct sCategoryHeaders
{
	HANDLE hEntry;
	int iDisplayType;
	char *ucCaption;
	char *pSearchQuery;
	char **ucExtensions;
	char **ucMimeTypes;
} sCategoryHeaders;


typedef struct sEntry
{
	s_region rBoundary;
	char bShow;

	struct sCategoryInterface *pInterface;

	void *pCookie;
	HANDLE hMenu;

	int iWidth;
	int iHeight;

	struct sEntry *pHeader;
	struct sEntry *pNext;
	struct sEntry *pPrev;
	struct sEntry *pFirstChild;

	HANDLE hWnd;

	int iChilds;
	int iItems;
	char bAccountItem;

	union
	{
		struct sHeader
		{
			char *ucCaption;
			unsigned int uiBackColor;
			unsigned int uiForeColor;
			char bShowChildren;
		} pHeader;

		struct sFile
		{
			char *ucPath;
			char *ucMimeType;
			char *ucSize;
			
			unsigned int uiBackColor;
			unsigned int uiForeColor;
		} pFile;

		struct sImage
		{
			char *ucPath;
			DIB *hDIB;
			int x,y;
			char *ucDesc;
		
		} pImage;

		struct sForeign
		{
			void *vpData;
		} sForeign;
	} u;
} sEntry;

typedef struct sCategory
{
	HANDLE hWnd;
	GC *pGCBack;

	COLOR uiDefaultBackColor,uiDefaultTextColor;
	COLOR uiHeaderDefaultBack, uiHeaderDefaultFore;

	sFont *hDefaultFont;
	int iMarginsLeft, iMarginsTop;


	char bInternSizeMessage;

	int iScrollOffsetY;

	sEntry *pFirst;
	sEntry *pSelected;
	sEntry *pFirstDisplayed;
	fpWidgetCategorySearchCallback fWidgetCategorySearchCallback;
	fpWidgetCategorySearchCallbackDone fWidgetCategorySearchCallbackDone;

	sCategoryHeaders pCategoryHeaders[MAX_CATEGORY_HEADERS];
	sEntry *pDefaultHeader;

	HANDLE hLock;

	sCategorySearchInfo *pSearchInfo;
	HANDLE hSearch;

	int iRefreshTimer;

	HANDLE hScrV;
	int iMaxHeight;

	HANDLE hHashTable;
	char bShowNotSupported ;
} sCategory;

typedef struct sCategoryInterface
{
	char *ucEntryType;
	HRESULT (*Draw)(HANDLE hWnd, sEntry *pEntry);
	HRESULT (*OnMouse)(HANDLE hWnd, sEntry *pEntry, int iX, int iY, int bButton, int bPress, int bDbl, int bMotion);
	HRESULT (*Free)(HANDLE hWnd, sEntry *pEntry);
} sCategoryInterface;

HANDLE GI_WidgetCategoryCreate(HANDLE parent,
								char *name,
								int x, int y, int width, int height,
								int uiWindowFlags, unsigned int uiStyleFlags);

HRESULT GI_WidgetCategoryPropertySet(HANDLE hWnd, 
								  char bSet,
								  unsigned int uiProperty,
								  unsigned int uiValue);
HRESULT GI_WidgetCategoryRebuildLayout(HANDLE hWnd);
HRESULT GI_WidgetCategorySearchSetCallback(HANDLE hWnd, unsigned int uiCallbackReason, fpWidgetCategorySearchCallback *pCallback);
HRESULT GI_WidgetCategoryRemoveAll(HANDLE hWnd);
HRESULT GI_WidgetCategoryGetSelectedEntry(HANDLE hWnd, HANDLE *hEntry);
int GI_WidgetCategorySizeInProgress(HANDLE hWnd);
HRESULT GI_WidgetCategoryCollapseAll(HANDLE hWnd);
HRESULT GI_WidgetCategoryExpandAll(HANDLE hWnd);
HRESULT GI_WidgetCategoryNewEntry(sCategory *pCategory, int iWidth, int iHeight, sEntry **ppEntry);
HRESULT GI_WidgetCategoryLink(HANDLE hWnd, sEntry *pHeader, sEntry *pEntry, sEntry *pReference, int iWhere);
HRESULT GI_WidgetCategoryUnlink(HANDLE hWnd, sEntry *pEntry);
HRESULT GI_WidgetCategoryShowEntry(HANDLE hWnd, sEntry *pEntry, int bShow, int bIncludeChildren);
HRESULT GI_WidgetCategorySetSelected(HANDLE hWnd, HANDLE hEntry);
HRESULT GI_WidgetCategoryEntrySetCookie(HANDLE hWnd, HANDLE hEntry, void *pCookie);
HRESULT GI_WidgetCategoryEntrySetMenu(HANDLE hWnd, HANDLE hEntry, HANDLE hMenu);
HRESULT GI_WidgetCategoryEntryGetCookie(HANDLE hWnd, HANDLE hEntry, void **ppCookie);
HRESULT GI_WidgetCategoryEntryGetType(HANDLE hEntry,
															char **ppType);
HANDLE 	GI_WidgetCategoryCreateEntry(HANDLE hWnd, int iWidth, int iHeight, HANDLE *hEntry);
void *GI_WidgetCategoryEntryGetData(HANDLE hEntry);
HRESULT GI_WidgetCategoryEntrySetData(HANDLE hEntry, void *vpData);
HRESULT GI_WidgetCategoryEntrySetInterface(HANDLE hEntry, void *vpInterface);

HRESULT GI_WidgetCategoryEntrySetWindow(HANDLE hEntry, HANDLE hWnd);
HANDLE GI_WidgetCategoryEntryGetWindow(HANDLE hEntry);
HANDLE GI_WidgetCategoryEntrySetAccount(HANDLE hEntry, char bAccount);
HRESULT GI_WidgetCategoryDestroyEntry(HANDLE hWnd, sEntry *pEntry);
HRESULT GI_WidgetCategoryCreateFile(HANDLE hWnd, char *ucPath, HANDLE *hEntry);
HRESULT GI_WidgetCategoryCreateHeader(HANDLE hWnd, char *ucCaption, HANDLE *hEntry);
HRESULT GI_WidgetCategoryHeaderShowChildren(HANDLE hWnd, HANDLE hEntry, int bShowChildren);
HRESULT GI_WidgetCategoryCreateImage(HANDLE hWnd, char *ucPath, HANDLE *hEntry);
HRESULT GI_WidgetCategorySearchStart(HANDLE hWnd, 
													  HANDLE hSearch,
													  unsigned int uiFlags,
													  sCategorySearchInfo **ppInfo);
HRESULT GI_WidgetCategorySearchRunning(HANDLE hWnd, sCategorySearchInfo *pInfo);
HRESULT GI_WidgetCategorySearchAbort(HANDLE hWnd);
HRESULT GI_WidgetCategoryGetCategoryDescription(int iIndex, 
												sCategoryHeaders **ppDesc);
HRESULT GI_WidgetCategoryCreateSpace(HANDLE hWnd, int iSpace, HANDLE *hEntry);
HRESULT GI_WidgetCategoryGetGC(HANDLE hWnd, int bBack, GC **ppGC);
HRESULT GI_WidgetCategoryEntryGetBoundary(HANDLE hWnd, HANDLE hEntry, s_region *pRegion);
HRESULT GI_WidgetCategoryGetDefaultBackcolor(HANDLE hWnd, COLOR *puiColor);
HRESULT GI_WidgetCategoryGetFont(HANDLE hWnd, sFont **ppFont);
HRESULT GI_WidgetCategoryDrawEntryBackground(HANDLE hWnd, 
													HANDLE hEntry, 
													GC *pGC, 
													s_region *pRegion,
													unsigned int uiColorBack);

#ifdef __cplusplus
}
#endif

#endif
