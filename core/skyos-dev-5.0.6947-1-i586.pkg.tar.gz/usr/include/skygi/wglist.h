#ifndef _INC_wgList_
#define _INC_wgList_

#include "skygi/msg.h"

/*!
  \ingroup wglist

  This message is sent to the parent window of a listbox just before
  the column/row edit mode is activated.

  If the parent window function returns zero when sending this message with
  bValid set to zero, the edit control is opened
  and filled with the data returned from the parent in sWidgetListboxEditNotify.ucBuffer.

  If sWidgetListboxEditNotify.bValid is 1, this indicates that the user has edited
  the text and pressed the enter key. The parent may use this message to check/update
  the modified data.

  Attention: This message is sent only if WGF_LISTBOX_ENABLE_EDIT is set.

  \param uiType	WM_WG_LIST_EDIT_NOTIFY
  \param para1  Handle of the listbox
  \param para2  Pointer to a filled sWidgetListboxEditNotify structure
  \since 3.9.7
*/

#define CAPTION_HEIGHT 15

#define LIST_VIEW_ID_LIST				0
#define LIST_VIEW_ID_ICON				1

typedef int (*f_win_func)(s_window *win, s_gi_msg *msg);
typedef int (*f_mouse_pressed)(s_window *win, void *lb, int x, int y, int button, int dbl, int pressed);
typedef int (*f_draw_item)(s_window *win, void *lb, s_region *clip, int itemnr,
						void *draw_item);
typedef int (*f_draw)(s_window *win, void *lb, s_region *clip, GC *gc);
typedef int (*f_mouse_moved)(s_window *win, void *lb, int x, int y, int buttons);

int wgList_lv_win_func(s_window* win, s_gi_msg *m);
int wgList_iv_win_func(s_window* win, s_gi_msg *m);

int wgList_lv_ms_win_func(s_window* win, s_gi_msg *m);
int wgList_iv_ms_win_func(s_window* win, s_gi_msg *m);


enum
{
	LISTBOX_SET_COLUMN_PROPERTY_TITLE=1,
	LISTBOX_SET_COLUMN_PROPERTY_TYPE,
	LISTBOX_SET_COLUMN_PROPERTY_POS,
	LISTBOX_SET_COLUMN_PROPERTY_SORT_TYPE,
	LISTBOX_SET_COLUMN_PROPERTY_SORT_FUNCTION

};

enum
{
	LISTBOX_COLUMN_TYPE_TEXT=0,
	LISTBOX_COLUMN_TYPE_DIB,
	LISTBOX_COLUMN_TYPE_USER_DRAW
};


typedef struct sRequestMenu
{
	HANDLE hWnd;		// handle of listbox in our case
	HANDLE hMenu;		// must be set to zero from the listbox, and must be set to a valid handle from parent window;
} sRequestMenu;

typedef struct sWidgetListboxDragRequest
{
	HRESULT hr;
	
	struct widget_lb_item *hItem;
	void *pItemData;
} sWidgetListboxDragRequest;

typedef struct widget_lb_column
{
	int pos;
	char *title;
	unsigned int uiType;
	DIB *hDIB;
	unsigned int uiSortType;
	int bSortAscending;
	int (*fSortFunction)(HANDLE hWnd, HANDLE hItem1, HANDLE hItem2, int iSortColumn, int iAscending);
} widget_lb_column;

struct widget_lb_item;

typedef struct widget_lb_column_user_draw
{
	int (*UserDraw)(GC *pGC, HANDLE hWnd, struct widget_lb_item *pItem , void *vpListBoxItemData,  int iColumn, void *pPara, s_region *pRect);
	void* vpUserDrawParam;
} widget_lb_column_user_draw;

typedef struct widget_lb_column_item
{
	char *pText;
	DIB *hDIB;

	int (*UserDraw)(GC *pGC, HANDLE hWnd, struct widget_lb_item *pItem , void *vpListBoxItemData, int iColumn, void *pPara, s_region *pRect);
	void* vpUserDrawParam;
} widget_lb_column_item;

typedef struct widget_lb_item
{
	unsigned int hIcon;
	DIB *hDIB;
	DIB *hDIB_Big;
	unsigned int data;
	struct widget_lb_item *next;
	struct widget_lb_item *prev;
	widget_menu *menu;

	unsigned int fg;
	unsigned int bg;
	unsigned int fg_sel;
	unsigned int bg_sel;

	s_region pRect;

	char bOption;
	char bOptionFixed;

	widget_lb_column_item pColumnItem[LISTBOX_MAX_POSITIONS];

	HANDLE hTooltip;

	/* Multi-Select Support */
	char isSelected;

} widget_lb_item;

typedef struct widget_lb
{
	unsigned int focus;
	widget_lb_item *items;

	unsigned int update_on_add;
	unsigned int nr_items;
	unsigned int selected;
	unsigned int shift_first;
	widget_lb_item *first;
	unsigned int firstnr;
	widget_menu *menu;

	unsigned int style;
	unsigned int show_items;

	struct widget_sb *sb;

	int mouse_oldx;
	int mouse_oldy;
	int mouse_size;
	int mouse_pressed;
	char title[255];

	widget_lb_column pColumn[LISTBOX_MAX_POSITIONS];

	unsigned int uiEditColumn;
	sFont *hFont;

	unsigned int uiCaptionForeGround;
	unsigned int uiCaptionBackGround;

	unsigned int uiTextHeight;
	HANDLE hEditWnd;
	HANDLE hToNotify;
	HANDLE hWnd;


	f_mouse_moved func_mouse_moved;
	f_mouse_pressed func_mouse_pressed;
	f_draw func_draw;
	f_draw_item func_draw_item;
	f_win_func func_win_func;

	unsigned int uiIconsPerLine;
	unsigned int uiIconsPerPage;
	char bUseBackGround;
	DIB *hBack;
	DDB *hBackDDB;

	unsigned int uiVisibleHeight;
	unsigned int uiIconWidth;
	unsigned int uiIconHeight;

	unsigned int uiIconGapX;
	unsigned int uiIconGapY;

	unsigned int uiIconSpaceX;
	unsigned int uiIconSpaceY;

	unsigned int bDrag;
	int bSortColumn;
	char bDragActive;
	char bMouseLeftDown;

	DIB *hBackOriginal;

	unsigned int uiColorBack;

	unsigned int uiKeyLookupPos;
	char ucKeyLookupBuf[255];
	unsigned int focuscolor;

	int iForcedItemHeight;
	HANDLE hEnabledTooltip;

	unsigned int bSizeCursor;
	widget_lb_item* pLastInserted;

	COLOR colTwoColorMode[2];

}widget_lb;

typedef struct sWidgetListboxEditNotify
{
	//! 0 .. Request for data.  1 .. Column modified
	char bValid;

	//! Data for edit control or modified data if bValid == 1
	char *ucBuffer;

	//! Column to modify(ied)
	unsigned int  uiColumn;

	//! Row to modify(ied)
	unsigned int  uiRow;

	//! Handle of the listbox
	HANDLE hWnd;
} sWidgetListboxEditNotify;




int wgList_lv_draw(s_window *win, widget_lb *lb, s_region *clip, GC *pGC);
int wgList_lv_draw_item(s_window *win, widget_lb *lb, s_region *clip, int itemnr,
						widget_lb_item *draw_item);
int wgList_lv_mouse_pressed(s_window *win, widget_lb *lb, int x, int y, int button, int dbl, int pressed);
int wgList_lv_mouse_moved(s_window *win, widget_lb *lb, int x, int y, int buttons);


int wgList_iv_draw(s_window *win, widget_lb *lb, s_region *clip,  GC *pGC);
int wgList_iv_draw_item(s_window *win, widget_lb *lb, s_region *clip, int itemnr,
						widget_lb_item *draw_item);
int wgList_iv_mouse_pressed(s_window *win, widget_lb *lb, int x, int y, int button, int dbl, int pressed);
int wgList_iv_mouse_moved(s_window *win, widget_lb *lb, int x, int y, int buttons);

#endif


