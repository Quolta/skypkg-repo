#ifndef __INCLUDE_SKYGI_
#define __INCLUDE_SKYGI_

#ifndef KERNEL
#include "stdlib.h"
#endif

#include "skyos/pack.h"
#include "librsm/librsm.h"
#include "skygi/translation.h"
#include "skygi/fonts/fontman.h"
#include "atomic.h"

#ifdef __cplusplus
extern "C" {
#endif

#define LAYOUT_HINT_SAME_WIDTH						0x00000001
#define LAYOUT_HINT_SAME_HEIGHT						0x00000002
#define LAYOUT_HINT_CENTER_ON_RESOLUTION_CHANGE		0x00000004

#ifdef __SKYGI_CPP__
	class SkyGI::Window;
#endif

#ifndef __SKYGI_CPP__
#define MOUSE_BUTTON_LEFT			1
#define MOUSE_BUTTON_RIGHT			2
#define MOUSE_BUTTON_MIDDLE			3
#define MOUSE_BUTTON_KEY			64
#endif

#define MOUSE_STATE_BUTTON_MASK_LEFT   0x00000001
#define MOUSE_STATE_BUTTON_MASK_RIGHT  0x00000002
#define MOUSE_STATE_BUTTON_MASK_MIDDLE 0x00000004

#define TIMER_FLAG_SINGLESHOT		0x00000001
#define TIMER_FLAG_RESET			0x00000002

#define GI_GET_WINDOW_INFO_CREATION_TIME   0x00000001

#define GI_WINDOW_SET_ICON_SMALL	0x00000001
#define GI_WINDOW_SET_ICON_BIG		0x00000002
#define GI_WINDOW_SET_ICON_ALL	(GI_WINDOW_SET_ICON_SMALL | GI_WINDOW_SET_ICON_BIG)	

/*!
  \ingroup skygi
  Color constant
*/
#define cBlack			  MAKE_COLOR(0,0,0)  
/*!
  \ingroup skygi
  Color constant
*/
#define cBlue			  MAKE_COLOR(0,0,170) 
/*!
  \ingroup skygi
  Color constant
*/
#define cGreen			  MAKE_COLOR(0,170,0) 
/*!
  \ingroup skygi
  Color constant
*/
#define cCyan			  MAKE_COLOR(0,170,170) 
/*!
  \ingroup skygi
  Color constant
*/
#define cRed			  MAKE_COLOR(170,0,0) 
/*!
  \ingroup skygi
  Color constant
*/
#define cMagenta		  MAKE_COLOR(170,0,170) 
/*!
  \ingroup skygi
  Color constant
*/
#define cBrown		 	  MAKE_COLOR(150,120,15) 
/*!
  \ingroup skygi
  Color constant
*/
#define cLightGray		  MAKE_COLOR(170,170,170) 
/*!
  \ingroup skygi
  Color constant
*/
#define cGray			  MAKE_COLOR(127,127,127) 
/*!
  \ingroup skygi
  Color constant
*/
#define cLightBlue		  MAKE_COLOR(40,120,250) 
/*!
  \ingroup skygi
  Color constant
*/
#define cLightGreen		  MAKE_COLOR(0,0xFF, 5) 
/*!
  \ingroup skygi
  Color constant
*/
#define cLightCyan		  MAKE_COLOR(0, 170, 255) 
/*!
  \ingroup skygi
  Color constant
*/
#define cLightRed		  MAKE_COLOR(170,0,85) 
/*!
  \ingroup skygi
  Color constant
*/
#define cLightMagenta	  MAKE_COLOR(170,0,0xFF) 
/*!
  \ingroup skygi
  Color constant
*/
#define cYellow			  MAKE_COLOR(240,240,95) 
/*!
  \ingroup skygi
  Color constant
*/
#define cWhite			  MAKE_COLOR(255,255,255) 
/*!
  \ingroup skygi
  Color constant
*/

/*!
  \ingroup skygi
  Extract the red value of an RGB color value
*/
#define COLOR_RED(x)    ((x>>16) & 0xFF)
/*!
  \ingroup skygi
  Extract the green value of an RGB color value
*/
#define COLOR_GREEN(x)  ((x>>8 ) & 0xFF)
/*!
  \ingroup skygi
  Extract the blue value of an RGB color value
*/
#define COLOR_BLUE(x)   ((x    ) & 0xFF)

/*!
  \ingroup skygi
  Create a RGB value from seperate red, green and blue color values
*/
#define MAKE_COLOR(r,g,b) ((r)<<16)|((g)<<8)|((b))

enum COLOR_SPACE
{
    COLOR_SPACE_UNDEFINED,
    COLOR_SPACE_RGB_32,
    COLOR_SPACE_RGBA_32,
    COLOR_SPACE_RGB_24,
    COLOR_SPACE_RGB_16,
    COLOR_SPACE_RGB_15,
    COLOR_SPACE_RGBA_15,
    COLOR_SPACE_YUV_422,
    COLOR_SPACE_YUV_411,
    COLOR_SPACE_YUV_420,
    COLOR_SPACE_YUV_444,
    COLOR_SPACE_YUV_9,
    COLOR_SPACE_YUV_12,
    COLOR_SPACE_YUY_2,
    COLOR_SPACE_INDEXED_8,
    COLOR_SPACE_MONO_1,
	COLOR_SPACE_BGR_24,
}; 

typedef struct sGlobalAccelerator
{
	unsigned char cModifier;
	unsigned int  uiUniCode;
	unsigned int  uiVKey;
    unsigned int uiCommand;
	void *window;
} sGlobalAccelerator;

#define WINDOW_FLAG_HANDLE_TAB      0x00000001
#define MAX_GFX_SETUP_PARAM 32

#define GFX_SETUP_PARAM_HSYNCSTART  0
#define GFX_SETUP_PARAM_HSYNCEND    1
#define GFX_SETUP_PARAM_HBLANKSTART 2
#define GFX_SETUP_PARAM_HBLANKEND   3
#define GFX_SETUP_PARAM_VSYNCSTART  4
#define GFX_SETUP_PARAM_VSYNCEND    5
#define GFX_SETUP_PARAM_VBLANKSTART 6
#define GFX_SETUP_PARAM_VBLANKEND   7
#define GFX_SETUP_PARAM_HFREQ		8
#define GFX_SETUP_PARAM_VFREQ		9

#define MENU_FLAG_SORTED			  1
#define MENU_FLAG_UB				  2
#define MENU_FLAG_HANDLE_RIGHTCLICK   4
#define MENU_FLAG_CLOSE_ON_RIGHTCLICK 8



#define WIN_CAP_MOUSE_TRACKING		0x00000001
#define WIN_CAP_TRANSPARENT			0x00000002
#define WIN_CAP_FREEFORM_DRAG       0x00000004
#define WIN_CAP_OFFSCREEN           0x00000008
#define WIN_CAP_DRAG_AND_DROP_TARGET 0x00000010
#define WIN_CAP_FADE				  0x00000020
#define WIN_CAP_DRAW_INTO_TRANSPARENT 0x00000040

#define WIN_SET_VALUE_ALPHA			1
#define WIN_SET_FRAME_WIDTH_TOP	    2
#define WIN_SET_FRAME_WIDTH_BOTTOM  3
#define WIN_SET_FRAME_WIDTH_LEFT    4
#define WIN_SET_FRAME_WIDTH_RIGHT   5
#define WIN_SET_TITLE_HEIGHT        6
#define WIN_SET_TITLE_DRAG_LEFT     7
#define WIN_SET_TITLE_DRAG_RIGHT    8
#define WIN_SET_FRAME_MIN_WIDTH		9
#define WIN_SET_FRAME_MIN_HEIGHT	10
#define WIN_SET_FRAME_MAX_WIDTH		11
#define WIN_SET_FRAME_MAX_HEIGHT	12
#define WIN_SET_FLAGS				13
#define WIN_SET_RESIZE_POINTS		14

#define WIN_RESIZE_POINT_TL			0x00000001
#define WIN_RESIZE_POINT_T			0x00000002
#define WIN_RESIZE_POINT_TR			0x00000004
#define WIN_RESIZE_POINT_R			0x00000008
#define WIN_RESIZE_POINT_BR			0x00000010
#define WIN_RESIZE_POINT_B			0x00000020
#define WIN_RESIZE_POINT_BL			0x00000040
#define WIN_RESIZE_POINT_L			0x00000080

#define WIN_RESIZE_POINT_ALL		(WIN_RESIZE_POINT_TL | WIN_RESIZE_POINT_T | WIN_RESIZE_POINT_TR | \
									 WIN_RESIZE_POINT_R | WIN_RESIZE_POINT_L | \
									 WIN_RESIZE_POINT_BL | WIN_RESIZE_POINT_B |WIN_RESIZE_POINT_BR)

#define DEFAULT_SKYGI_FONT "sserife.fon"

#define MAX_RADIO_BUTTONS			20


#ifdef KERNEL
#include "skyos/types.h"
#include "skygi/resource.h"
#else
#include "skyos/types.h"
#include "skygi/resource.h"
#endif

extern sResFile *pSkyGIResFile;

#include "skyos/vkey.h"

#define LISTBOX_MAX_POSITIONS 36

/*!
  \ingroup skygi
  Create a ARGB value by specifying the alpha and RGB value
*/
#define MAKE_TRANSPARENT(col, value) \
	(col | (value << 24))

extern unsigned int GI_ColorSystemDepth;

/*!
  \ingroup skygi
  Returns TRUE is current color depth is less or equal than 8 bit
*/
#define IS_INDEXED_COLOR (GI_ColorSystemDepth <= 8)

/*!
  \ingroup skygi
  Returns TRUE is current color depth is greater than 8 bit
*/
#define IS_DIRECT_COLOR(x) (GI_ColorSystemDepth > 8)

#include "skygi/gi_keys.h"

#ifndef ID_OK
#define ID_OK		1
#endif
#ifndef ID_YES
#define ID_YES		2
#endif
#ifndef ID_NO
#define ID_NO		3
#endif
#ifndef ID_CANCEL
#define ID_CANCEL	4
#endif

#define LISTBOX_COLUMN_SORTTYPE_STRING	 	 0x00000001
#define LISTBOX_COLUMN_SORTTYPE_INTEGER     0x00000002
#define LISTBOX_COLUMN_SORTTYPE_DATA_FIRST	 0x00000004
#define LISTBOX_COLUMN_SORTTYPE_DATA_LAST	 0x00000008
#define LISTBOX_COLUMN_SORTTYPE_CASE		 0x00000010
#define LISTBOX_COLUMN_SORTTYPE_USER_DEFINED 0x00000020
#define LISTBOX_COLUMN_SORTTYPE_DISABLED	 0x00000040

#define WGF_PANELINFO_NO_SPACING 0x00000001

#define WGF_LAYOUT_VERTICAL		 0x00000001
#define WGF_LAYOUT_HORIZONTAL	 0x00000002

/*
  Align window centered in layout view
*/
#define WGF_LAYOUT_ALIGN_CENTER   0x00000001
#define WGF_LAYOUT_ALIGN_LEFT     0x00000002
#define WGF_LAYOUT_ALIGN_RIGHT    0x00000004
#define WGF_LAYOUT_ALIGN_TOP      0x00000008
#define WGF_LAYOUT_ALIGN_BOTTOM   0x00000010
#define WGF_LAYOUT_ALIGN_FIX      0x00000020
/*
  Automatically compute window size in layout view
*/
#define WGF_LAYOUT_FULLSIZE       0x00000040
#define WGF_LAYOUT_FIXSIZE        0x00000080

#define WGF_LAYOUT_ALIGN_SPACING  0x00000100


#define WF_APPLICATION_HAS_MENU					WF_HAS_MENU

#define WF_FRAME_NO_ROUND_EDGES_TOP				0x00000001
#define WF_FRAME_NO_ROUND_EDGES_BOTTOM			0x00000002
#define WF_FRAME_ROUND_EDGES_BACKGROUND_BLACK   0x00000004
#define WF_FRAME_NO_SHADOW						0x00000008
#define WF_FRAME_DONT_EREASE_BACKGROUND			0x00000010
#define WF_FRAME_NO_FRAME						0x00000020
#define WF_FRAME_ROUND_EDGES_BOTTOM				0x00000040
#define WF_FRAME_NOT_MOVEABLE					0x00100000
#define WF_FRAME_OWN_SHAPE						0x00000080
#define WF_FRAME_THIN                           0x08000000

#define WF_TITLE_NO_MAXIMIZE					0x00000001
#define WF_TITLE_NO_MINIMIZE					0x00000002
#define WF_TITLE_NO_CLOSE						0x00000004
#define WF_TITLE_SMALL_TITLE					0x00080000
#define WF_TITLE_NO_TITLE 						0x00200000
#define WF_TITLE_NO_BUTTONS						0x00800000
#define WF_NO_TITLE								WF_TITLE_NO_TITLE
#define WF_SMALL_TITLE							WF_TITLE_SMALL_TITLE 
#define WF_NO_TITLE								WF_TITLE_NO_TITLE
#define WF_NO_BUTTONS							WF_TITLE_NO_BUTTONS

/*!
  \ingroup skygi
*/
#define WF_NO_FOCUS		 0x10000000

/*!
  \ingroup skygi

  If set, a menu window is created when using GI_ApplicationCreateOld.
  \sa GI_ApplicationCreateOld
*/
#define WF_HAS_MENU      0x00001000

/*!
  \ingroup skygi

  If set, a statusbar window is created when using GI_ApplicationCreateOld.
  \sa GI_ApplicationCreateOld
*/
#define WF_HAS_STATUSBAR 0x00002000


/*!
  \ingroup skygi

  If set the window can get a focus.
*/
#define WF_FOCUSABLE     0x00010000

/*
   Not initial focus
*/
#define WF_NO_INIT_FOCUS 0x00000100

/*!
  \ingroup skygi
*/
#define WF_USER          0x20000000

/*!
  \ingroup skygi

  If set the window becomes a new desktop
*/
#define WF_DESKTOP       0x80000000

/*!
  \ingroup skygi

  If set, the window is created not visible  
*/
#define WF_HIDE          0x40000000

/*!
  \ingroup skygi

  If set, the window will not be moved by SkyGI.
*/
#define WF_NOT_MOVEABLE  0x00100000

/*!
  \ingroup skygi

  If set, the window will not be resized by SkyGI.
*/
#define WF_NOT_SIZEABLE  0x00040000

/*!
  \ingroup skygi

  If set, the window will not be resized by SkyGI.
*/
#define WF_FRAME_NOT_SIZEABLE	WF_NOT_SIZEABLE

/*!
  \ingroup skygi

  If set, no MSG_APPLICATION_CHANGED is sent when the window is created.
*/
#define WF_POPUP         0x00400000

/*!
  \ingroup skygi
*/
#define WF_TRANSPARENT   0x01000000

/*!
  \ingroup skygi

  If set, no clipping is done for child windows. This means that the parent window can draw into
  the window region of the child window
*/
#define	WF_NO_CLIP				0x00004000
/*!
  \ingroup skygi

  If set, no clipping is done for child windows. This means that the parent window can draw into
  the window region of the child window
*/
#define WF_DONT_CLIP_CHILDREN   WF_NO_CLIP
/*!
  \ingroup skygi

  If set, no clipping is done for sibling windows. 
*/
#define WF_DONT_CLIP_SIBLINGS   0x00000100
/*!
  \ingroup skygi
*/
#define WF_NO_INITIAL_DRAW 0x00008000

/*!
  \ingroup skygi
*/
#define WF_USE_BACKGROUND 0x20000000

/*!
  \ingroup skygi

  Client window doesn't draw background
*/
#define WF_DONT_EREASE_BACKGROUND 0x00000010
#define WF_DONT_ERASE_BACKGROUND  0x00000010
#define WF_NO_FRAME				  0x00000020

#define WF_NO_ACTIVATION   0x00020000

#define WGF_SELECT_FILE_FOLDER_ONLY 0x00000001

#define ICON_FOLDER 1
#define ICON_APP    2
#define ICON_DEVICE 3
#define ICON_TEXT   4
#define ICON_UNKNOWN 5
#define ICON_FOLDERUP 6
#define ICON_FOLDERNEXT 7
#define ICON_FOLDERPREV 8


#define WGF_MENU_ALIGN_BOTTOM		0x00000000
#define WGF_MENU_ALIGN_TOP			0x00000001


/*
  Button styles
*/
#define WGF_NO_BORDER				0x00000001
#define WGF_BORDER_ON_MOUSE_OVER    0x00000002
#define WGF_BUTTON_TOOL		        0x00000004
#define WGF_BUTTON_ALPHA_HOVER		0x00000008

#define WGF_ALIGN_LEFT				0x00000010
#define WGF_ALIGN_CENTER  		    0x00000020
#define WGF_ALIGN_RIGHT   		    0x00000040
#define WGF_ALIGN_VCENTER           0x00000080
#define GC_FLAG_FONT_3D             0x00000100
#define WGF_ALIGN_BASELINE          0x00000200

#define WGF_TEXTFIELD_SINGLELINE	0x00100000
#define WGF_TEXTFIELD_PASSWORD		0x00200000
#define WGF_TEXTFIELD_DISABLE_TAB	0x00400000
#define WGF_TEXTFIELD_HAS_VSCROLL	0x00800000
#define WGF_TEXTFIELD_HAS_HSCROLL	0x01000000
#define WGF_TEXTFIELD_DISABLE_INPUT 0x02000000
#define WGF_TEXTFIELD_SMALL_FRAME   0x04000000
#define WGF_TEXTFIELD_NO_FRAME      0x08000000


#define WGF_TEXTFIELD_INPUT_FLAG_NUMERIC 0x00000001
#define WGF_TEXTFIELD_INPUT_FLAG_ALPHA   0x00000002
#define WGF_TEXTFIELD_INPUT_FLAG_IP      0x00000004

#define WGF_BUTTON_AUTOCUT			0x00100000
#define WGF_BUTTON_DIB_AND_TEXT		0x00200000

enum
{
	TEXT_SYNTAX_WORD = 1,
    TEXT_SYNTAX_TO_END,
    TEXT_SYNTAX_SCOPE
};


/*
  Tree style
*/
#define WGF_TREE_HAS_ICON				0x00100000

/*!
  Creates a listbox with icons.
*/
#define WGF_LISTBOX_HAS_ICON			0x00000010
/*!
  Creates a listbox with has a caption.
*/
#define WGF_LISTBOX_SHOW_CAPTION		0x00000100

#define WGF_LISTBOX_ENABLE_INPUT        0x00000200

#define WGF_LISTBOX_VIEW_ICON			0x00000400
#define WGF_LISTBOX_MULTI_SELECT		0x00000800
#define WGF_LISTBOX_OPTION   			0x00001000
#define WGF_LISTBOX_TWO_COLOR_MODE		0x00002000

#define WGF_POPUP_USER_BACKGROUND       0x00100000
/*!
  Creates a messagebox with a STOP Icon
*/
#define WGF_MB_ICON_STOP				0x10000000
/*!
  Creates a messagebox with an ASK Icon
*/
#define WGF_MB_ICON_ASK 				0x01000000
/*!
  Creates a messagebox with an INFO Icon
*/
#define WGF_MB_ICON_INFO				0x00100000

/*!
  Creates a messagebox with a 'Yes' and a 'No' button
*/
#define WGF_MB_YESNO					0x00000001
#define WGF_MB_OK						0x00000010
#define WGF_MB_CANCEL					0x00000100
#define WGF_MB_USER						0x00000200

#define WGF_MB_FOCUS_OK					0x20000000
#define WGF_MB_FOCUS_CANCEL				0x40000000
#define WGF_MB_FOCUS_YES				0x80000000
#define WGF_MB_FOCUS_NO					0x02000000

#define WGF_MB_NOT_OWNED				0x00080000


#define WGF_STATIC_MULTILINE			0x10000000
#define WGF_STATIC_LINK					0x00000800

/*
  slider
*/
#define WGF_SLIDER_VERTI				0x00000001
#define WGF_SLIDER_HORIZ				0x00000002
#define WGF_SLIDER_VERTI_BAR			0x00000004
#define WGF_SLIDER_HORIZ_BAR			0x00000008

/*
	MENU_SEPERATOR is deprecated. Don't use anymore
*/
#define MENU_SEPERATOR					0x00000001	
#define MENU_SEPARATOR					0x00000001

#define MENU_CHECKED					0x00000002

#define WGF_SB_HORIZ					0x00000001
#define WGF_SB_VERT						0x00000000

typedef unsigned int HGD;

/*
   Color handling
*/
typedef unsigned int COLOR;

#define DIB_FLAG_ALLOCATED  0x00000001
#define DIB_FLAG_PERSISTANT 0x00000002


typedef struct hFont
{
   void *vpHandle;
   char family[255];
   char style[255];
   char filename[255];

   int iAscend;
   int iDescend;
   int iAdvance;
   int iLineGap;

   int iSize;
} hFont;

typedef struct DIB
{
   unsigned int color;
   int width;
   int height;
   unsigned char *data;

   unsigned int  palette_size;
   unsigned int transcolor;
   char trans;

   unsigned char *bAndMask;
   char bUseAndMask;
   unsigned int  uiAndMaskWidth;
   unsigned int  uiAndMaskHeight;
   unsigned int  uiFlags;
   COLOR *palette;
   int stride;
} DIB;

typedef struct DDB
{
   unsigned int color;
   int width;
   int height;
   unsigned char *data;
   unsigned int  palette_size;
   unsigned int transcolor;
   char trans;
   unsigned char *bAndMask;
   char bUseAndMask;
   unsigned int  uiAndMaskWidth;
   unsigned int  uiAndMaskHeight;
   COLOR *palette;
} DDB;


#define DRIVER_TYPE_GRAPHIC 1
#define DRIVER_TYPE_INPUT   2
#define DRIVER_TYPE_SOUND   3

#include "skygi/icons.h"

typedef struct region
{
  int x1;
  int y1;
  int x2;
  int y2;
} s_region;

typedef struct s_point
{
	int x;
	int y;
} s_point;

#include "gilayer.h"


typedef struct s_gi_msg
{
	HANDLE win;					
	unsigned int type;			//!< message type
	unsigned int para1;			//!< message defined parameter 1
	unsigned int para2;			//!< message defined parameter 2
	s_region rect;				//!< rectangle
	struct s_gi_msg *next;		//!< next message
    struct s_gi_msg *prev;
	unsigned long long timestamp;
} s_gi_msg;

#define MAX_WINDOW_PROPERTIES 16


#define MSG_CONSUME_FLAG_ALL  0xFFFFFFFF
typedef struct sPropTable
{
	unsigned int uiNextFreeProperty;
	unsigned int uiProperty[MAX_WINDOW_PROPERTIES];
} sPropTable;

#define INTERNAL_WINDOW_FLAG_NO_UPDATE_ON_REDRAW		0x00000001

typedef struct s_window
{
	char name[255];	//!< name of the window
	int x;				//!< always 0
	int y;				//!< always 0
	int height;		//!< height of the window
	int width;			//!< width of the window
	int orgx;			//!< relative x coordinate of the window
	int orgy;			//!< relative y coordinate of the window
	unsigned long (*fpWindowFunction)(HANDLE win, s_gi_msg *m); //!< window function for this window
	HANDLE handle;				//!< SkyGI Kernel window handle

	struct s_window *parent;	//!< Parent window
	struct s_window *child;		//!< First child window
	struct s_window *next;		//!< Next window in this level

	char focus;		//!< focus state
	struct s_window *pFocusChildWindow;	//!< window which has focus
#ifdef __SKYGI_CPP__
	SkyGI::Window *windowData;			//!< widget defined window Data
#else
	void *windowData;			//!< widget defined window Data
#endif
	unsigned int windowDataSize;//!<  widget defined window Data size

	unsigned int flags;			//!< window flags
    int origin_x;
	int origin_y;

	struct s_window *pFocusNext;
	struct s_window *pFocusPrev;
	unsigned int uiWindowFlags;
	sPropTable    *pPropTable;
	int (*fpProperty)(HANDLE hWnd, char bSet, unsigned int uiProperty, unsigned int uiData);
	unsigned int (*fpWindowFunctionOrg)(HANDLE hWnd, s_gi_msg *hMsg);

	struct GC *pGC;

	struct sInterface *pInterface;

	unsigned int bForeignWindow;
	unsigned int bParentDrawsBackground;
	atomic_t iRefCount;
	volatile int bDestroyed;
	struct GC *pGCScreen;
	unsigned int uiInternalWindowFlags;
	
	sGILayer *pLayer;

	volatile int bMarkedForDestroy;
	volatile int bDestroyInProgress;
	
	unsigned int uiLayoutHint;
	s_region rClientMargins;
} s_window;


typedef struct s_rectangle
{
	s_window *win;
	int x,y,width, height;
	unsigned int color, fill;
	unsigned int translevel;
	unsigned int rop;
} s_rectangle;

typedef struct s_fullscreen
{
	int uiWidth;
	int uiHeight;
	unsigned int uiFrameBuffer;
} s_fullscreen;

typedef struct s_copy_rect
{
	s_window *win;
	int x1,y1,x2,y2;
	int dx, dy;
	unsigned int res1;
	unsigned int res2;
	char bClip;
	int clipx1, clipy1, clipx2, clipy2;
} s_copy_rect;

typedef struct s_circle
{
	s_window *win;
	int midx,midy,radx,rady;
	unsigned int color, fillcolor;
	char fill;
	int clipx1,clipx2,clipy1,clipy2;
} s_circle;
/*!
*/
typedef struct s_line
{
	s_window *win;
	int x1, y1, x2, y2, color;
	unsigned int uiROP;
} s_line;

/*!
*/
typedef struct s_pixel
{
	s_window *win;
	int x, y, color;
} s_pixel;

/*!
*/
typedef struct s_blit
{
	s_window *win;
	unsigned char *buf;
	int x,y,w,h;
	unsigned int transflag;
	unsigned int transcolor;
	int clipx1,clipx2,clipy1,clipy2;
	unsigned int bpp;
	char bUseAndMask;
	unsigned char *bAndMask;
	int  uiAndMaskWidth;
	int  uiAndMaskHeight;
	char bGet;
	unsigned int  uiTransparentLevel;
	int uiSourceX;
	int uiSourceY;
	int uiSourceWidth;
	int uiSourceHeight;
	char bGlyph;
} s_blit;

/*!
*/
typedef struct s_text
{
	s_window *win;
	char text[255];
	int x,y,fc, bc;
} s_text;

typedef struct filevw_data
{
	char root[255];
} filevw_data;

typedef struct sBlit
{
	DIB *hDIB;								//!< DIB to Blit
	DDB *hDDB;								//!< DDB to Blit (optional)
	int iDestX;								//!< X position where to blit to
	int iDestY;								//!< Y position where to blit to
	int iSrcX;								//!< X position from where to blit from
	int iSrcY;								//!< Y position from where to blit from
	int iWidth;								//!< Width of the rectangle to blit
	int iHeight;							//!< Height of the rectangle to blit
	unsigned int uiFlags;

	unsigned int iSrcWidth;
	unsigned int iSrcHeight;
	unsigned int uiReserved2;
	unsigned int uiReserved3;
	unsigned int uiReserved4;
	unsigned int uiReserved5;
	unsigned int uiReserved6;
	unsigned int uiReserved7;
	unsigned int uiReserved8;
	unsigned int uiReserved9;
} sBlit;

/*!
  \ingroup wgtb

  empty
*/
#define WIDGET_TOOLBAR_ICON_SIZE_16		16 

/*!
  \ingroup wgtb

  empty
*/
#define WIDGET_TOOLBAR_ICON_SIZE_32		32

/*!
  \ingroup wgtb

  empty
*/
#define WIDGET_TOOLBAR_ICON_SIZE_48		48

#define WIDGET_TOOLBAR_FLAG_ALIGN_BOTTOM     0x00000001

typedef struct widget_filevw
{
  HANDLE hList;
  filevw_data *data;
  DIB *hIconFolder;
  unsigned int ulBackGrounColor;
  int bAllowDirectories;
} widget_filevw;


typedef struct widget_dynbmp_item
{
	DIB *hDib;
	unsigned char *rawData;
	struct widget_dynbmp_item *next;
} widget_dynbmp_item;


typedef struct widget_dynbmp
{
   unsigned int state;
   unsigned int trans;
   unsigned int transcolor;
   unsigned int thread_id;
   unsigned int timer_id;
   widget_dynbmp_item *first; 
   widget_dynbmp_item *selected; 
} widget_dynbmp;



typedef struct widget_button
{
	char bHover;
	char bOwnerDraw;
	void *pCookie;
	char pressed;
	unsigned int  focus;
	unsigned int  ID;
	unsigned int  enabled;
	unsigned int  style;
	unsigned int  mouse_over;
	void		  *hIcon;

	DIB *hDIB_Normal;
	DIB *hDIB_Pressed;

	HANDLE hTooltip;

	unsigned int uiTextColor;
/* Stylable data */
	unsigned int uiStyleTextColor;
	unsigned int uiStyleTextColorDis;
	unsigned int uiStyleBgColor;
	unsigned int uiStyleTextColorOver;
	unsigned int uiStyleTextColorOverDis;
	unsigned int uiStyleBgColorOver;
	unsigned int uiStyleColor1;
	unsigned int uiStyleColor2;
	unsigned int uiStyleColor3;

	sFont *pFont;
	
	HANDLE hMessageTarget;

	int uiDIBNormalX;
	int uiDIBNormalY;
	int uiDIBPressedX;
	int uiDIBPressedY;
	
	int uiDIBNormalWidth;
	int uiDIBNormalHeight;
	int uiDIBPressedWidth;
	int uiDIBPressedHeight;

	DIB *hDibText;
	DIB *hDibBackground;

	sBlit pBlitPressed;
	sBlit pBlitReleased;

	char bBut1Down;
	char bBut2Down;
} widget_button;

typedef struct widget_check
{
	char pressed;
	unsigned int  focus;
	unsigned int  ID;
	unsigned int  enabled;
	unsigned int  style;
	unsigned int  mouse_over;
	void		  *hIcon;
	unsigned int ulBackGround;

	HANDLE			hMessageTarget;
	HANDLE			hTooltip;
} widget_check;

typedef struct widget_radio_group
{
	unsigned int uiNextFreeIndex;
	HANDLE pRadioButtons[MAX_RADIO_BUTTONS];

} widget_radio_group;

typedef struct widget_radio
{
	char pressed;
	unsigned int focus;
	unsigned int ID;
	unsigned int enabled;
	unsigned int style;
	unsigned int mouse_over;
	void		 *hIcon;
	unsigned int ulBackGround;

	widget_radio_group *pRadioGroup;

	HANDLE		 hMessageTarget;
	HANDLE		 hTooltip;

} widget_radio;

typedef struct widget_splitter
{
	HANDLE hWnd;
	HANDLE hTopLeft;
	HANDLE hBottomRight;

	unsigned int uiSplitValue;
	char bVertical;

	unsigned int uiBarWidth;
	unsigned int bMoveInProgress;
	unsigned int uiOldX;
	unsigned int uiOldY;
	unsigned int uiBackGroundColor;
	unsigned int uiFlags;
	unsigned int uiDrawBackground;

} widget_splitter;

typedef struct widget_frame
{
	HANDLE title;
	HANDLE statusbar;
	HANDLE clientwindow;
	HANDLE menubar;
	unsigned int bActivated;
	unsigned int ulBackGround;
	unsigned int ulBackGroundCol;

	unsigned int ulColor1;
	unsigned int ulColor2;
	unsigned int ulColor3;

	unsigned int close_on_focus_lost;
	unsigned int close_sent;

	unsigned int uiStyle;
	unsigned int iShadowWidth;
	unsigned int iShadowHeight;

	int iMinWidth;
	int iMinHeight;
	int iMaxWidth;
	int iMaxHeight;

	unsigned int uiResizePoints;

	s_region rShadowBoundary;
	s_region rBoundary;
	s_region rFrameWidth;

	HANDLE hToolbars[4];
} widget_frame;

typedef struct widget_status
{
	unsigned int uiBackGroundColor;
	unsigned int uiTextColor;
	unsigned int uiLineColor;
	HANDLE hLayout;
	HANDLE hText;
	unsigned int (*tWndFunctionLayout)(HANDLE hWnd, s_gi_msg *hMsg);

} widget_status;

typedef struct widget_edit
{
	char focus;
	char text[255];
	unsigned int max_len;
	unsigned int cursor;

	unsigned int uiFont;
	unsigned int uiFontSize;
} widget_edit;

typedef struct widget_ce
{
	char text[255];
	unsigned int len;
	struct widget_ce *next;
    struct widget_ce *prev;
} widget_ce;

typedef struct widget_complexedit
{
	char update_after_add;
	char focus;
	unsigned int line_count;
	unsigned int cur_x;
	unsigned int cur_y;
	unsigned int cur_on;
	unsigned int over;
	unsigned int font, font_size;
    widget_ce *current;
	widget_ce *item;

	widget_ce *first_visible;
	unsigned int first_visible_count;
	unsigned int vis_lines;
	HANDLE     sb;

	unsigned int uiLineHeight;
} widget_complexedit;

typedef struct widget_static
{
	char *text;
	unsigned int style;
	unsigned int uiTextColor;
	unsigned int uiBackGroundColor;

	sFont *hFont;
	char bFixedFont;

	DIB *hDIB;
	DIB *hIcon;
	int iPosX;
	int iPosY;
	unsigned int uiHyperLink;
	char bColorFixed;
	HANDLE hTooltip;
	char bShowHyperlink;
	unsigned int uiFrameColor;
	char bShowFrame;
} widget_static;

typedef struct widget_gb
{
	char *text;
	unsigned int style;
	unsigned int uiBackGroundColor;
	unsigned int uiTextColor;	
	unsigned int uiCaptionColor;	

} widget_gb;

typedef struct widget_popup
{
	unsigned int uiItemHeight;
	unsigned int uiFlags;
	sFont *hFont;
	unsigned int uiFontFlags;

	unsigned int uiColorSelectedBack;
	unsigned int uiColorSelectedFore;
	unsigned int uiColorBack;
	unsigned int uiColorFore;
	unsigned int uiWindowBackColor;

	unsigned int uiSpacingX;
	unsigned int uiFrameSelected;
	unsigned int uiFrameSelectedColor;

	unsigned int uiFrameLeftWidth;

	unsigned int uiSpacingIconText;
	unsigned int uiSeperatorHeight;
	unsigned int uireserved[9];
} widget_popup;

typedef struct widget_user_menu_item
{
	HRESULT (*Create)(HANDLE hPopup, HANDLE hMenuItem, int x, int y, void **pData, HANDLE *hCreatedWindow);
	HRESULT (*Destroy)(HANDLE hPopup, HANDLE hMenuItem, void *pData);

	unsigned int pData;
	HANDLE hCreatedWindow;
} widget_user_menu_item;

typedef struct widget_menu_item
{
	char text[255];
	unsigned int  ID;
	unsigned int  flags;
	struct widget_menu_item *next;
    struct widget_menu *child;
	unsigned int focus;
	unsigned int enabled;
	unsigned int x;
    HANDLE icon;
	DIB *hDIB;
    unsigned int has_icon;
/*
    used if item has sub-items
*/
    unsigned int width;
	unsigned int count;
	unsigned int y_start;
	unsigned int y_end;
	unsigned int uireserved[10];

	unsigned int  uiAcceleratorMod;
	unsigned int  uiAcceleratorVKey;
	char ucAcceleratorDesc[16];

	unsigned int uiData;

	char bUser;
	widget_user_menu_item *pUserMenuItem;
} widget_menu_item;

typedef struct widget_menu
{
	char focus;
	unsigned int count;
	unsigned int width;
	unsigned int has_icons;
	widget_menu_item *items;
    widget_dynbmp *animation;
	widget_popup  *pPopUpData;
	unsigned int uiLineColor;
	unsigned int uiFlags;
	HANDLE hOpen;

} widget_menu;

typedef struct widget_title
{
	unsigned int ulIcon;
	unsigned int style;
	s_region pNormalWindowSize;
	int bHover;
	int bPressed;
	char bShowHelp;

} widget_title;



typedef struct widget_progress
{
	unsigned int min;
	unsigned int max;
	unsigned int value;

	unsigned int caption;
	unsigned int color;

	unsigned int uiStepWidth;
	unsigned int uiGap;
} widget_progress;

typedef struct widget_slider
{
	unsigned int min;
	unsigned int max;
	unsigned int value;

	unsigned int caption;
	unsigned int color;
	unsigned int style,x,y;
	HANDLE notify;
	unsigned int uiBackgroundColor;
} widget_slider;

typedef struct widget_sb
{
	 int min;
	 int max;
	 int value;
	 int steps;
	 int page;

	 int space;
	float        size;
	HANDLE       notify;
	char bHorizontal;

	unsigned int uiBackGround;
	unsigned int uiButtonBackGround;

	 int uiMouseMove;
	 int uiMouseOldX;
	 int uiMouseOldY;
	int iTimer;
	int iDelayTimer;
	int iTimerAction;

	char bMouseOn;
} widget_sb;

typedef struct app_para
{
	char cpName[255];
	unsigned int  ulX;
	unsigned int  ulY;
	unsigned int  ulWidth;
	unsigned int  ulHeight;

	void *win_func;
	unsigned int ulStyle;
	unsigned int ulBackGround;

	unsigned int ulAppIcon;
	widget_menu  *pMenu;
} app_para;

typedef struct sCreateApplication
{
	char ucApplicationName[255];
	int  uiX;
	int  uiY;
	int  uiWidth;
	int  uiHeight;

	void *fwndClient;
	unsigned int uiStyleApplication;
	unsigned int uiStyleFrame;
	unsigned int uiStyleTitle;
	unsigned int uiStyleMenu;
	unsigned int uiStyleBar;
	unsigned int uiStyleClient;
	unsigned int uiBackGroundColor;
	unsigned int uiApplicationIcon;
	HANDLE  pFrameMenu;

	unsigned int uiDefaultColor;
	unsigned int uiReserved[127];

	void (*PostCreateWindowBitmap)(HANDLE hWnd, void *pGCBuf);
} sCreateApplication;

typedef struct s_resolution
{
	unsigned int width;
	unsigned int height;
	unsigned int bpp;
}s_resolution;

typedef struct s_setup_gfx
{
	unsigned int driver_type;
	char driver[255];
	unsigned int  X;
	unsigned int  Y;
	unsigned int  BPP;
	char para[255];
	
	unsigned int mtrr_enable;
	unsigned int acceleration_enable;
	unsigned int uiUseOpenGL;
	unsigned int uiRefreshRate;
	unsigned int reserved4;
	unsigned int reserved5;
	unsigned int reserved6;
	unsigned int reserved7;
	unsigned int reserved8;
	unsigned int reserved9;

	unsigned int uiParamSize;
	unsigned char *pParam;
	unsigned int uiReserved[30];
} s_setup_gfx;

typedef struct s_window_info
{
	char ucWindowName[255];
	unsigned int  uiGIWMHandle;
	unsigned int  uiWindowFlags;
	unsigned int  uiGIWMParentHandle;
	char ucParentWindowName[255];
	char bFocused;
	unsigned int  bShow;
	unsigned int  uiReserved[39];
	int iX, iY, iWidth, iHeight;
	unsigned int  uiOwnerPID;
	unsigned long long ullCreationTime;
} s_window_info;

typedef struct s_get_handle
{
	unsigned int count;
	unsigned int handle;
	unsigned int parent;
	unsigned int uiPara;
	unsigned long long ullPara;
	unsigned int uiFlags;
}s_get_handle;


#define GI_GETWINDOW_TYPE_CHILD	   0x00000001		//!< Return handle of child window with specified name
#define GI_GETWINDOW_TYPE_DESKTOP  0x00000002
#define GI_GETWINDOW_TYPE_FOCUS    0x00000004

#define GI_FOREIGNWINDOW_FOCUSED   0x00000001

typedef struct sGetWindow
{
	unsigned int uiFlags;						//!< Flags
	char ucWindowName[255];			//!< Name of the window
	unsigned int vpHWND;						//!< Handle of found window
	unsigned int vpParentHWND;					//!< Handle of parent window
} sGetWindow;


typedef struct widget_sheet_item
{
	HANDLE widget;
	struct widget_sheet_item *next;
} widget_sheet_item;

typedef struct widget_prop_sheet
{
	char name[255];
	struct widget_prop_sheet *next;
	struct widget_prop_sheet *prev;
	char isVisible;
	unsigned int caption_start;
	unsigned int caption_end;
	unsigned int caption_top;
	unsigned int caption_bottom;
	int (*fpWindowFunction)(HANDLE win, s_gi_msg *m);

	widget_sheet_item *items;
	HANDLE win;
	HANDLE hPropertyWindow;
	unsigned int ulBackGround;
	unsigned int uiFont;
	unsigned int uiFontSize;

	void *pData;

} widget_prop_sheet;


typedef struct widget_prop
{
	widget_prop_sheet *sheets;
	widget_prop_sheet *active;
	widget_prop_sheet *first;		/* First Visible Tab -- Used when more tabs than available space */

	unsigned int ulActiveColor;
	unsigned int ulInActiveColor;
	unsigned int ulActiveColorText;
	unsigned int ulInActiveColorText;
	unsigned int ulBackGround;

	sFont *hFont;
	HANDLE hWnd;

	unsigned int uiTabsHeight;		/* Set when tabs are drawn */
	unsigned int uiStyle;

	/* Buttons for moving tabs */
	char buttonsVisible;
	unsigned int uiLeftScroll_Left;
	unsigned int uiLeftScroll_Top;
	unsigned int uiRightScroll_Left;
	unsigned int uiRightScroll_Top;

} widget_prop;
 
#define WGF_PROPERTY_TABS_MULTIROW		0x00000001
#define WGF_PROPERTY_TABS_ONBOTTOM		0x00000002
	
typedef struct widget_client
{
	int (*fpWindowFunction)(HANDLE win, s_gi_msg *m);
	void *privateWindowData;
	unsigned int ulBackGround;
	unsigned int uiStyle;
	DIB *hBackGroundImage;

} widget_client;

#define WIDGET_TREE_FLAG_EXPANDED		0x00000001

typedef struct widget_tree_item
{
	char name[255];
	unsigned int  index;
	
	unsigned int  flags;

	void *pUserData;

	HANDLE *hIcon;
	HANDLE hDIB;
	/*
	  list
	*/
	struct widget_tree_item *next;
	struct widget_tree_item *prev;
	struct widget_tree_item *child;
	struct widget_tree_item *parent;

	struct widget_tree_item *next_allocated;

} widget_tree_item;

typedef struct TREEITEMINFO
{
	char *name;
	unsigned int  index;
	HANDLE hIcon;
	HANDLE hDIB;
	void *pUserData;
} TREEITEMINFO;

typedef struct widget_tree
{
	COLOR color_selected_bar;
	COLOR color_selected_text;
	COLOR color_text;

	unsigned int item_height;
    unsigned int item_space;

	widget_tree_item *first;
	widget_tree_item *first_visible;
	widget_tree_item *selected;

	widget_sb *sb;
	char sb_show;
	unsigned int show_items;
	HANDLE *hDefaultIcon;
	HANDLE hDIB;

	unsigned int style;

	widget_tree_item *first_allocated;
	widget_tree_item *last_allocated;

	unsigned int autoupdate;

	unsigned int uiBackColor;

} widget_tree;

typedef struct sAdvTextStyle
{
	unsigned int uiVersion;
	unsigned int uiForeGround;
	unsigned int uiBackGround;
	int iLength;
	int iHeight;
	unsigned int uiReserved[4];
} sAdvTextStyle;

typedef struct sWidgetTextField_Style
{
	unsigned int  uiType;
	char *pToken;
	unsigned int uiForeColor;
	unsigned int uiBackColor;
	char *pTokenEnd;
} sWidgetTextField_Style;

#include "skygi/gc.h"

typedef struct sDrawParent
{
	HANDLE hChild;
	s_region pRegion;
	GC *pGC;
} sDrawParent;

#define WGF_SPLITTER_HORIZONTAL 0
#define WGF_SPLITTER_VERTICAL   1

#define WGF_SPLITTER_SMALL_TILE 2
#define WGF_SPLITTER_SMALL_TILE_DOUBLE 4


#define QUERY_MASK_WIN 		0x00000001
#define QUERY_MASK_TYPE		0x00000002
#define QUERY_MASK_PARA1	0x00000004
#define QUERY_MASK_PARA2	0x00000008

unsigned int 	GI_MessageBuildAndSend (HANDLE hWnd, unsigned int uiMsgType, unsigned int uiPara1, unsigned int uiPara2);;

#include "skyos/mouse.h"
#include "skygi/msg.h"

#ifndef MIN
#define MIN( a, b )  ( (a) < (b) ? (a) : (b) )
#endif

#ifndef MAX
#define MAX( a, b )  ( (a) > (b) ? (a) : (b) )
#endif

#ifndef ABS
#define ABS( a )     ( (a) < 0 ? -(a) : (a) )
#endif


typedef struct sSelectFileTypes
{
	char *ucExtension;
	char *ucDescription;
} sSelectFileTypes;



typedef struct sSelectFilePrivate
{
	HANDLE hButton;
	char bFavorite;
	char bThumbs;
	int iThumbsLoaderPid;
	int iThumbsLoaderWorking;
} sSelectFilePrivate;


typedef struct sSelectFile
{
	char bUseRegularExpression;
	char ucLocation[255];
	unsigned int  ret;
	unsigned int  uiFlags;
	char *ucFileName;
	char ucInitialDir[4096];
	char ucTitle[4096];
	char ucMatchPattern[1024];

	sSelectFileTypes *pFileTypes;

	HANDLE hFileTypes;

	sSelectFilePrivate *pPrivate;
	
} sSelectFile;

#define SELECTFILE_OPEN						0x00000000
#define SELECTFILE_SAVE						0x00000001
#define SELECTFILE_ALLOW_DIRECTORIES		0x00000002
#define SELECTFILE_FILETYPES				0x00000004
#define SELECTFILE_INITIAL_DIR				0x00000008
#define SELECTFILE_EXECUTE					0x00000010
#define SELECTFILE_TITLE					0x00000020
#define SELECTFILE_RETURN_DIR				0x00000040
#define SELECTFILE_ICONVIEW					0x00000080
#define SELECTFILE_THUMBVIEW				0x00000100
#define SELECTFILE_INITIAL_FILENAME			0x00000200
#define SELECTFILE_OPEN_FOLDER				0x00000400
#define SELECTFILE_NEW						0x00000800

#define GETFILEICON_FOLDER					0x00000001
#define GETFILEICON_DEVICE					0x00000002
#define GETFILEICON_GENERIC					0x00000000
#define GETFILEICON_UNKNOWN					0x00000004
#define GETFILEICON_FOLDER_MARKED			0x00000008

#define GETFILEICON_SMALL					0x00000000
#define GETFILEICON_BIG						0x00000001

#include "wgcombo.h"	 
#include "wglist.h"

typedef struct sMsgData
{
	unsigned int uiSize;
	unsigned int uiArea;
	void *vpData;
} sMsgData;

typedef struct sMsgTrayIconAdd
{
	unsigned int uiID;
	unsigned int uiPID;
	char ucToolTip[255];
	unsigned int uiAndMaskSizeInBytes;
	unsigned int uiGIWMHandle;
	DIB hDIB;
} sMsgTrayIconAdd;

typedef struct sTrayIconAdd
{
	unsigned int  uiID;
	unsigned int  uiPID;
	unsigned int uiGIWMHandle;
	char ucToolTip[255];
	DIB *hIcon;
} sTrayIconAdd;

#define GC_BLIT_FLAG_COPY       0x00000000
#define GC_BLIT_FLAG_STRETCH	0x00000001
#define GC_BLIT_FLAG_TILE		0x00000002

typedef struct sMessageDump
{
	unsigned int uiGIWMHandle __attribute__ ((packed));
	s_gi_msg hMsg __attribute__ ((packed));
} sMessageDump;

typedef struct sCursor
{
	DIB *hDIB;
	int iHotSpotX;
	int iHotSpotY;
} sCursor;

#define TITLE_ACTION_DONE     0
#define TITLE_ACTION_MAXIMIZE 1
#define TITLE_ACTION_MINIMIZE 2
#define TITLE_ACTION_HIDE     4
#define TITLE_ACTION_HELP	  5

typedef struct sMessageBoxNonModal
{
	HANDLE hText;
	HANDLE hButtonOk;
	HANDLE hButtonYes;
	HANDLE hButtonNo;
	HANDLE hWnd;
} sMessageBoxNonModal;

#ifndef KERNEL
#include "skygi/theme.h"
#endif

#define GI_FLAG_ADDTRANSPARENTREGION_CLEAR_ALL	0x00000001

typedef struct sAddTrans
{
	int x1;
	int y1;
	int x2;
	int y2;
	unsigned int uiFlags;
} sAddTrans;

#define GI_WINDOWBITMAP_COLOR_OPAQUE 0x00
#define GI_WINDOWBITMAP_COLOR_OWNER  0xFE
#define GI_WINDOWBITMAP_COLOR_BLACK  0xFD
#define GI_WINDOWBITMAP_COLOR_TRANS  0xFF

#define GI_ICON_EXTENSION_FOLDER		"FOLDER"
#define GI_ICON_EXTENSION_FOLDER_MARKED		"MARKEDFOLDER"
#define GI_ICON_EXTENSION_UNKNOWN		"UNKNOWN"

#define SYSTEM_FONT_GENERAL 0
#define SYSTEM_FONT_TITLE   1
#define SYSTEM_FONT_BOLD    2
#define SYSTEM_FONT_FIXED   3

#define MAX_SYSTEM_FONT		10

#define WIDGET_DEFAULT_HEIGHT -1
enum
{
	THEME_COLOR_ID_CLIENT_WINDOW_FRAME = 1,
	THEME_COLOR_ID_CLIENT_FRAME_WINDOW_FRAME,
	THEME_COLOR_ID_CLIENT_BACKGROUND,
	THEME_COLOR_ID_WINDOW_TEXT,
	THEME_COLOR_ID_WIDGET_TEXT,
	THEME_COLOR_ID_MENU_TEXT,
	THEME_COLOR_ID_MENU_BACKGROUND,
	THEME_COLOR_ID_MENU_TEXT_SELECTED,
	THEME_COLOR_ID_MENU_BACKGROUND_SELECTED,
	THEME_COLOR_ID_HIGHTLIGHT_BACKGROUND,
	THEME_COLOR_ID_HIGHTLIGHT_TEXT,
	THEME_COLOR_ID_LISTBOX_ROW_EVEN,
	THEME_COLOR_ID_LISTBOX_ROW_ODD
};

enum
{
	THEME_PROPERTY_PROGRESS_BAR_HEIGHT = 1,
	THEME_PROPERTY_COMBO_HEIGHT,
	THEME_PROPERTY_MENU_CHECKED_IMAGE,
	THEME_PROPERTY_PROP_MARGIN_LEFT,
	THEME_PROPERTY_PROP_MARGIN_TOP,
	THEME_PROPERTY_PROP_MARGIN_RIGHT,
	THEME_PROPERTY_PROP_MARGIN_BOTTOM,

};


#define THEME_ICON_ID_LISTBOX_ACTIVE			 1
#define THEME_ICON_ID_LISTBOX_INACTIVE			 2

typedef struct sWidgetButtonOwnerDraw
{
	void *pCookie;
	GC *gc;
	char bPressed;
	char bHover;
	char bDisabled;
	char bFocused;
	unsigned int uiReserved[31];
} sWidgetButtonOwnerDraw;

typedef struct sMessageBoxButtons
{
	char ucName[64];
	unsigned int  uiID;
	HANDLE hWnd;
} sMessageBoxButtons;



typedef struct widget_combo
{
	HANDLE hEdit;
	HANDLE hListBox;
	HANDLE hButton;

	s_region pRect;
	unsigned int uiEditWidth;
	unsigned int uiEditHeight;
	unsigned int uiID;

	unsigned int uiBackColor;
} widget_combo;

typedef struct sDragAndDropService
{
	unsigned int uiDragAndDropOperationID;

	int iMousePointerID;

	int iMousePointerCurrentID;

	char ucMimeType[255];
	unsigned char ucQueryType;

	struct pUser
	{
		void		*vpData;
		unsigned int iSize;
	} pUser;

	struct pKernel
	{
		void		*vpData;
		unsigned int iSize;
	} pKernel;

} sDragAndDropService;

enum
{
	DRAG_AND_DROP_QUERY_SIZE = 1,
	DRAG_AND_DROP_QUERY_DATA,
	DRAG_AND_DROP_QUERY_MIME_TYPE,
	DRAG_AND_DROP_QUERY_ID
};

#define DRAG_AND_DROP_CONTINUE 0x00000001

typedef unsigned int (*tWindowFunction)(HANDLE hWnd, s_gi_msg *hMsg);
typedef HRESULT (*tWidgetTooltipOnOpen)(HANDLE hTooltip, void *vpData);

#include "property.h"

/************************************** SkyGI Prototypes *******************************************/
#ifndef KERNEL

HRESULT 	GI_WindowHandlesTab (HANDLE hWnd, char bHandle);
HRESULT 	GI_FocusSetTo (HANDLE hWnd);
HANDLE 	GI_FocusSet (HANDLE hWnd);
HANDLE 	GI_FocusGet (HANDLE hParent);
HANDLE 	GI_FocusSwitchTo (HANDLE hWnd, char bDirection, char bInformWM);
HANDLE 	GI_FocusSwitchToNext (HANDLE hWnd);
HANDLE 	GI_FocusSwitchToPrev (HANDLE hWnd);
HANDLE 	GI_FocusOrderSet (HANDLE hWndFirst,...);
int 	GI_FontSystemInfo (int uiID, char *pFamily, char *pStyle, unsigned int *uiSize);
int 	GI_InitSystemFonts (void);
int 	GI_FontSystem (unsigned int uiID);
int 	GI_FontSystemSize (unsigned int uiID);
sFont*  GI_FontGetDefault (void);
int 	GI_FontSizeSet (hFont *pFont, unsigned int width, unsigned int height);
int 	GI_DrawTextIntern (GC *pGC, sFont *pFont, char *text, unsigned int x, unsigned int y, unsigned int mono, sAdvTextStyle *pStyle, int iBytes);
int 	GI_DrawText (GC *pGC, s_region *rect, char *text, sAdvTextStyle *ucStyle, int iBytes);
int 	GC_DrawTextMultilineStyle (GC *pGC, s_region *rect, char *text, sAdvTextStyle *ucStyle);
int 	GI_TextHeightMultiline (GC *pGC, s_region *rect, char *text);
int 	GI_TextWidthMultiline(GC *pGC, s_region *rect, char *text);
int 	GI_TextLength (sFont *pFont, char *pText);
int 	GI_TextLengthMax (sFont *pFont, char *pText, int iBytes);
int 	GI_TextHeight (sFont *pFont, char *pText);
int 	GI_FontsGetFamilyCount (void);
int 	GI_FontsGetStyleCount (char *ucFamily);
int 	GI_FontsEnumFamilies (int iIndex, char *ucFamily);
int 	GI_FontsEnumStyles (int iIndex, char *ucFamily, char *ucStyle);
int 	GI_FontsEnumFiles (int iIndex, char *ucFileName);
int 	GI_FontLoad (char *filename);
HRESULT 	GI_InterfaceAlloc (HANDLE hWnd, unsigned int uiSize, unsigned int uiFunction,...);
struct sInterface * 	GI_InterfaceGet (HANDLE hWnd);
HANDLE 	GI_WindowCreate (s_window *parent, char *name, int x, int y, int width, int height, unsigned int flags, unsigned long win_func, void *windowData, unsigned int windowDataSize);
int 	GI_WindowFlush (HANDLE win);
HANDLE 	GI_create_app_internal (sCreateApplication *pCreate);
HANDLE 	GI_ApplicationCreate (sCreateApplication *pCreateApplication);
int 	GI_ResolutionChanged (void);
int 	GI_TranslationChanged (void);
int 	GI_ColorSystemDepthGet (void);
void 	GI_Lock (void);
void 	GI_Unlock (void);
int 	GI_WindowScrollBy (HANDLE win, int direction, int scrollby);
int 	GI_WindowScrollTo (HANDLE win, int direction, int scrollto);
int 	GI_ScrollOffsetGetX (HANDLE win);
int 	GI_ScrollOffsetGetY (HANDLE win);
HRESULT 	GI_request_fullscreen (unsigned int uiWidth, unsigned int uiHeight, unsigned int *pFrameBuffer);
tWindowFunction 	GI_WindowGetFunction (HANDLE hWnd);
HRESULT 	GI_WindowSetFunction (HANDLE hWnd, tWindowFunction hFunction);
tWindowFunction 	GI_OverloadWindowFunction (HANDLE hWnd, tWindowFunction hNewFunction);
tWindowFunction 	GI_GetOverloadedWndFunc (HANDLE hWnd);
void 	GI_SystemBusy (void);
void 	GI_SystemIdle (void);
HRESULT 	GI_MessageDumperRegister (HANDLE hWnd);
sCreateApplication * 	GI_ApplicationStructCreate (void);
void 	GI_FontUpdate (void);
int GI_AdjustWindowDimension(HANDLE hWnd, int bNotify, int x, int y, int width, int height);
int 	GI_CheckAndMask (unsigned char *pAndMask, unsigned int x, unsigned int y, unsigned int uiAndMaskWidth, unsigned int uiAndMaskHeight);
unsigned int 	GetSystemLanguage (void);
unsigned int 	SetSystemLanguage (unsigned int uiID);
int GI_MessageDispatch(s_window *win, s_gi_msg *m);
HRESULT GI_ConvertPosToWindow(HANDLE hWnd, int *x, int *y);
HRESULT GI_ConvertPosToScreen(HANDLE hWnd, int *x, int *y);
sTheme * 	GI_ThemeGetActive (void);

HRESULT 	GI_MousePositionSet (int x, int y);
int 	GI_InjectMouseAction (char ucButton, char bPressed);
int 	GI_InjectKeyAction (unsigned int uiVKey, unsigned int uiModifier, char bPressed);
unsigned int GI_KeyStateGet(void);
unsigned int 	GI_MessageGetTimeOfLast (void);
HRESULT 	MultipleObjectWaitSet (sMultipleObjectWaitItem *pFirst, int iType, unsigned int uiData1, unsigned int uiData2);
HRESULT 	MultipleObjectWait (sMultipleObjectWaitItem *pFirst, int iObjects, int uiTimeOutInMsecs);
unsigned int 	GI_MessageRedrawWait (s_gi_msg *m, s_window *w);
int 	GI_MessagePending (void);
int 	GI_MessagePendingWait (void);
int 	GI_MessageSend (HANDLE win, s_gi_msg *msg);
unsigned int 	SkyGI_SendMessage (HANDLE win, unsigned int uiMsgType, unsigned int uiPara1, unsigned int uiPara2);
unsigned int 	SkyGI_PostMessage (HANDLE win, unsigned int uiMsgType, unsigned int uiPara1, unsigned int uiPara2);
int 	GI_MessageCommandPost (HANDLE win, unsigned int ID);
int 	GI_post_command_data (HANDLE win, unsigned int ID, unsigned int uiData);
unsigned int 	GI_MessageWait (s_gi_msg *m, s_window *w);
int 	GI_MessageDispatchToChildren (s_window *win, s_gi_msg *m);
char * 	GI_WindowGetTitle (s_window *win);
s_window * 	GI_WindowGetStatusbar (s_window *win);
HANDLE 	GI_WindowGetTopLevel (HANDLE hWnd);
s_window * 	GI_WindowGetMenubar (s_window *win);
s_window * 	GI_WindowGetTitlewindow (s_window *win);
s_window * 	window_get_client (s_window *win);
s_window * 	window_get_frame (s_window *win);
int 	GI_IsChildWindow (s_window *parent, s_window *child);
unsigned int 	GI_TimerSet (HANDLE hWnd, int ui500Msecs);
unsigned int 	GI_TimerAdd (HANDLE hWnd, unsigned int uiMSecs, unsigned int uiPara, unsigned int uiFlags);
unsigned int 	GI_TimerSetHighPrecision (HANDLE hWnd, unsigned int msec);
int 	GI_TimerDestroy (unsigned int uiID);
int GI_MessageQuery(s_gi_msg *m, s_window *w, unsigned int type);
void 	GI_MessageQuitPostWithState (HANDLE win, unsigned int uiState);
void 	GI_MessageQuitPost (HANDLE hWnd);
void 	SkyGI_PostQuit (HANDLE win);
void 	SkyGI_PostDestroy (HANDLE win);
void 	GI_MessageDestroyPost (s_window *win);
void 	GI_MessageDestroyApplicationPost (s_window *win);
int 	GI_destroy_child_windows (s_window *win);
int 	GI_WindowDestroy (HANDLE hWnd);
int 	GI_MousePointerSet (int id);
int 	GI_ResolutionGet (s_resolution *res);
int 	GI_ConvertToScreenCoordinates (HANDLE hWnd, int *x, int *y);
int 	GI_WindowHandleGet (s_get_handle *s);
int 	GI_WindowHandleGetFirst (HANDLE parent, s_get_handle *s);
int 	GI_WindowHandleGetNext (s_get_handle *s);
int 	GI_WindowInfoGet (HANDLE handle, s_window_info *info);
int 	GI_WindowSetState (HANDLE win, unsigned int state);
int 	GI_WindowShow (HANDLE hWnd);
int 	GI_WindowHide (HANDLE hWnd);
int 	GI_ApplicationDestroy (HANDLE hWnd);
HRESULT 	GI_ApplicationWindowShow (HANDLE hWnd);
HRESULT 	GI_ApplicationWindowHide (HANDLE hWnd);
int 	GI_WindowDimensionSetNotifyDo (s_window *win, int notify, int x1, int y1, int width, int height, int dx, int dy);
int 	GI_WindowDimensionSetNotify (HANDLE hWnd, int notify, int x1, int y1, int width, int height);
int 	GI_WindowRedraw (HANDLE hWnd);
HRESULT 	GI_RegionRedraw (HANDLE hWnd, s_region *region);
s_window * 	GI_ApplicationColorSet (s_window *win, unsigned int color);
int 	GI_MousePositionGetInWindow (HANDLE win, unsigned int *x, unsigned int *y);
int 	GI_MouseStateGet (unsigned int *uiState);
int 	GI_WindowDimensionGet (s_window *win, s_region *rect);
HANDLE 	GI_WindowGetParent (HANDLE win);
HANDLE 	GI_GetFrameWindow (HANDLE win);
HRESULT 	EnableWindow (HANDLE hWnd, char bEnable);
int 	GI_WindowGetX (HANDLE hWnd);
int 	GI_WindowGetXAbsolute (HANDLE hWnd);
int 	GI_WindowGetYAbsolute (HANDLE hWnd);
int 	GI_WindowGetY (HANDLE hWnd);
int 	GI_WindowGetWidth (HANDLE hWnd);
int 	GI_WindowGetHeight (HANDLE hWnd);
unsigned int 	SkyGI_NotifyWindow (HANDLE hToNotify, HANDLE hWnd, unsigned int uiMsgTypeToNotify, unsigned int uiPara);
int 	SkyGI_ClipValid (s_region *pRect);
int 	SkyGI_SetCapture (HANDLE hWnd);
int 	GI_GetDefaultWheelAmount (void);
int 	GI_WindowCapSet (HANDLE hWnd, unsigned int uiFlag, char bSet);
int 	GI_MouseTrackingEnable (HANDLE hWnd);
int 	GI_MouseTrackingDisable (HANDLE hWnd);
int 	GI_DragAndDropTarget (HANDLE hWnd, int bSet);
DIB * 	GI_ApplicationGetBackground (HANDLE hWnd);
HRESULT 	GI_WindowGet (sGetWindow *pGetWindow);
HRESULT 	GI_MessageSendRemote (HANDLE hGIWMHandle, s_gi_msg *hMsg);
HANDLE 	GI_WindowGetGIWMHandle (HANDLE hWnd);
HRESULT 	GI_SendDataMessageInternal (HANDLE hWnd, unsigned int uiDataSize, void *vpData, unsigned int uiMsgPara2, char bRemote);
HRESULT 	GI_MessageSendDataRemote (HANDLE hGIWMHandle, unsigned int uiDataSize, void *vpData, unsigned int uiMsgPara2);
HRESULT 	GI_WindowValueSet (HANDLE hWnd, unsigned int uiType, unsigned int uiValue);
HRESULT 	GI_WindowSetBitmap (HANDLE hWnd, unsigned int uiWidth, unsigned int uiHeight, void *pWindowBitmap);
HRESULT 	GI_AddTransparentRegion (HANDLE hWnd, int x1, int y1, int x2, int y2, unsigned int uiFlag);
HRESULT 	GI_WindowPositionGetSerialized (char *ucApplicationName, unsigned int uiApplicationID, int *uiX, int *uiY, int *uiWidth, int *uiHeight, int uiDefaultX, int uiDefaultY, int uiDefaultWidth, int uiDefaultHeight);
HRESULT 	GI_WindowPositionSerialize (char *ucApplicationName, unsigned int uiApplicationID, HANDLE hWnd);
HRESULT 	GI_WidgetSetBackgroundImage (HANDLE hWidget, DIB *hDIB);
HRESULT 	GI_WindowBitmapCreate (s_window *hWnd, GC **ppGC);
HRESULT 	GI_WindowBitmapApplyFull (s_window *hWnd, GC *pGC);
int 	GI_GetMainWindowShadowWidth (HANDLE hFrameWindow);
void 	GetSizeString (unsigned long long ullSize, char *pStr);
HRESULT 	GI_WindowSetFlag (HANDLE hWnd, unsigned int uiFlag);
HRESULT 	GI_WindowClearFlag (HANDLE hWnd, unsigned int uiFlag);
HANDLE * 	GI_GetWindowAt (HANDLE hWindow, int *x, int *y);
HRESULT 	GI_ApplicationSetSize (HANDLE hWnd, int iWidth, int iHeight);
HRESULT 	GI_WindowSetSize (HANDLE hWnd, int iWidth, int iHeight);
HRESULT 	GI_WindowSetPos (HANDLE hWnd, int iX, int iY);
HRESULT 	GI_WindowSetSizeAndPos (HANDLE hWnd, int iX, int iY, int iWidth, int iHeight);
HRESULT 	GI_ApplicationSetPos (HANDLE hWnd, int iX, int iY);
HRESULT 	GI_ApplicationSetSizeAndPos (HANDLE hWnd, int iX, int iY, int iWidth, int iHeight);
HRESULT 	GI_WindowCenter (HANDLE hWnd);
HRESULT 	GI_WindowDimensionSet (HANDLE hWnd, int iX, int iY, int iWidth, int iHeight);
unsigned int 	GI_MouseGetState (void);
int 	GI_WindowRaiseToTop (HANDLE hWnd);
int 	GI_WindowRaiseForeignToTop (HANDLE hGIWMWnd);
void * 	GI_WindowDataGet (HANDLE hWnd);
int 	GI_ForeignDraw (HANDLE hForeignWindow, HANDLE hThis, GC *pGC, int x, int y, int width, int height);
HRESULT 	GI_WidgetSetProperty (HANDLE hWnd, fpProperty func, unsigned int uiProperty,...);
HRESULT 	GI_MousePositionGet (int *puiX, int *puiY);
HRESULT 	GI_MouseGetPositionInWindow (HANDLE hWnd, int *puiX, int *puiY);
int 	GI_MouseGetX (void);
int 	GI_MouseGetY (void);
HRESULT 	GI_HelpOpen (char *ucPath);
HRESULT 	GI_AllocWindowProperty (HANDLE hWnd);
HRESULT 	GI_WindowGetProperty (HANDLE hWnd, unsigned int uiPropertyIndex, unsigned int *uiPropertyValue);
HRESULT 	GI_WindowSetProperty (HANDLE hWnd, unsigned int uiPropertyIndex, unsigned int uiPropertyValue);
HRESULT 	GI_SetAttentionWindow (HANDLE hAttentionWindow, HANDLE hAttentionWindowSource);
HRESULT 	GI_WidgetSetPropertyFunction (HANDLE hWnd, void *fpFunction);
HRESULT 	GI_GetGCFromWindow (HANDLE hWnd, GC **ppGC);
HRESULT 	GI_WindowMaximize (HANDLE hWnd);
HRESULT 	GI_GetLastInputActivity (unsigned long long *pullTime);
int 	GI_PointInWindow (HANDLE hWnd, int x, int y);
HRESULT 	GI_WindowSetResizePoints (HANDLE hWnd, unsigned int uiPoints);
DDB* GI_DIBConvertToDDB(DIB *dib);
unsigned int GI_StyleGetValue(char *pKey,unsigned int uiDefaultValue);
void GI_StyleGetText(char *pKey,char *pData,char *pDefaultText);
sCursor *GI_CursorLoad(char *ucFilename, unsigned int uiWidth,unsigned int uiHeight,unsigned char ucBpp,unsigned int ImageIndex);
int GI_ColorDepthGet(void);
char* GI_IconGet(unsigned int h);
void GI_BitmapEffectBlurBoxDo(unsigned char *src, int src_w, int src_h, unsigned char *dst, unsigned long *p, int boxw, int boxh);
HRESULT GI_Swap(HANDLE hWnd, s_region *pDirty);

inline int utf8_to_unicode( const char* source );
inline int utf8_char_length( unsigned char  ucFirst);

HRESULT 	GI_FontInit (void);
HRESULT 	GI_FontDestroy (sFont *pFont);
sFont * 	GI_FontCreateHandle (void);
sFont * 	GI_FontDuplicate (sFont *pFont);
sFont * 	GI_FontSet (sFont *pNew, sFont *pFont);
void*       GI_FontGetFace(sFont *pFont);
HRESULT 	GI_FontCreate (char *pFamily, char *pStyle, char *pFileName, unsigned int uiFlags, sFont **ppFont);
HRESULT 	GI_FontCreateSystem (unsigned int uiID, sFont **ppFont);
HRESULT 	GI_FontSetSize (sFont *pFont, int iSize);
sFont * 	GI_FontGetDefault (void);
int 	GI_TextHeight (sFont *pFont, char *pText);
int 	GI_TextLengthGetIntern (sFont *pFont, char *pText, int iMaxBytes);
int 	GI_TextLength (sFont *pFont, char *pText);
int 	GI_TextLengthMax (sFont *pFont, char *pText, int iMaxBytes);
int 	GI_GetCharPosition (sFont *pFont, int iLength, char *pText);
HRESULT 	GI_FontSystemInit (unsigned int uiID, char *pType, char *pFile);
HRESULT 	GI_FontSystemInitFonts (void);
sFont * 	GI_FontSystemGet (int uiID, sFont **ppFont);
HRESULT		GI_FontInfo(sFont *pFont, sFontInfo *pInfo);
HRESULT GI_FontGetMetrics(sFont *pFont, sFontMetrics *pMetrics);
#endif



/*********************************** Widget Prototypes ************************************/
/* 
   Widget textfield
*/


#define INSERT_POS_HEAD		0
#define INSERT_POS_CURSOR   1
#define INSERT_POS_TAIL     2
#define INSERT_POS_TAIL_NL  3

#define WIDGET_TEXT_SET_CURSOR_FLAG_TO_END			0x00000001
#define WIDGET_TEXT_SET_CURSOR_FLAG_TO_BEGIN		0x00000002
#define WIDGET_TEXT_SET_CURSOR_FLAG_TO_POS			0x00000004
#define WIDGET_TEXT_SET_CURSOR_FLAG_TO_LINE			0x00000008
#define WIDGET_TEXT_SET_CURSOR_FLAG_ENSURE_VISIBLE	0x10000000

HRESULT GI_WidgetTextFieldSelectAll(HANDLE hWnd);
HRESULT GI_WidgetTextFieldSelectOnFocus(HANDLE hWnd, int bSelect);
HANDLE 		GI_WidgetTextfieldCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style);
HRESULT 	GI_WidgetTextfieldAddLine (HANDLE hWnd, char *cLine);
HRESULT 	GI_WidgetTextfieldAddLineAutocut (HANDLE hWnd, char *cLine);
HRESULT 	GI_WidgetTextfieldAdd (HANDLE hWnd, char *cLine);
HRESULT 	GI_WidgetTextfieldRedraw (HANDLE hWnd);
HRESULT 	GI_WidgetTextfieldSetStyle (HANDLE hWnd, sWidgetTextField_Style *pStyle);
HRESULT 	GI_WidgetTextfieldPasswordMode (HANDLE hWnd, char bEnable);
HRESULT 	GI_WidgetTextfieldDeleteText (HANDLE hWnd);
HRESULT 	GI_WidgetTextfieldSetFont (HANDLE hWnd, sFont *pFont);
HANDLE 		GI_WidgetTextfieldGetLine (HANDLE hWnd, HANDLE hIter, char *cLine, unsigned int uiMaxSize);
HRESULT		GI_WidgetTextfieldSetSingleLine (HANDLE hWnd, char bSingle);
HRESULT 	GI_WidgetTextfieldGetSelection (HANDLE hWnd, char bDeleteSelection, char **cBuffer);
HRESULT 	GI_WidgetTextfieldReadonlyMode (HANDLE hWnd, char bReadOnly);
HRESULT 	GI_WidgetTextfieldGetCurrentLine (HANDLE hWnd, unsigned int *uiLineNumber, char *ucLine, unsigned int uiMaxSize);
HRESULT 	GI_WidgetTextfieldSetLineBackgroundColor (HANDLE hWnd, unsigned int uiLineIndex, COLOR col);
int 		GI_WidgetTextfieldSetEditLine (HANDLE hWnd, unsigned int uiIndex);
HRESULT 	GI_WidgetTextfieldAddFile (HANDLE hWnd, char *cFileName);
HRESULT 	GI_WidgetTextfieldSetColor (HANDLE hWnd, COLOR colFore, COLOR colBack);
HRESULT 	GI_WidgetTextfieldSetMenu (HANDLE hWnd, HANDLE hMenu, char bAddDefault);
HRESULT 	GI_WidgetTextfieldUndo (HANDLE hWnd);
HRESULT		GI_WidgetTextfieldUndoReset ( HANDLE hWnd );
HRESULT 	GI_WidgetTextfieldAddCursorFollows (HANDLE hWnd, char *cLine);
HRESULT		GI_WidgetTextfieldSetCursorTo(HANDLE hWnd,
									  int x,
									  int y,
									  HANDLE hLine,
									  unsigned int uiFlags);

HRESULT 	GI_WidgetTextfieldGetCursor (HANDLE hWnd, int *x, int *y);
HRESULT 	GI_WidgetTextFieldSetSelection (HANDLE hWnd, HANDLE pLine, int iStart, int iEnd);
int 		GI_WidgetTextfieldScrollDown (HANDLE hWnd);
HRESULT 	GI_WidgetTextfieldUndoAvailable (HANDLE hWnd);
HRESULT 	GI_WidgetTextfieldSetAutoTab (HANDLE hWnd, char bEnable);
HRESULT 	GI_WidgetTextfieldGetAutoTab (HANDLE hWnd, char *pbEnable);

/* 
   Toolbar
*/
HANDLE 		GI_WidgetToolbarCreate(HANDLE parent,
							char *name,
							int uiReserved0, 
							int uiReserved1, 
							unsigned int uiFlags, 
							int enumToolbarIconSize,
							int style);
HRESULT 	GI_WidgetToolbarAdd (HANDLE hWnd, char *pIconFile, HANDLE hDIB, unsigned int uiID, HANDLE *hButton);

/*
   Widget form
*/
HANDLE 		GI_WidgetFormCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int uiFlags);
HRESULT 	GI_WidgetFormUseParentBackground (HANDLE hWnd, char bUse);

/*
   Widget scrollbar
*/
HANDLE		GI_WidgetScrollbarCreate(HANDLE parent, HANDLE tonotify, 
							char *name,
							int x, int y, int width, int height,
							unsigned int style);
int			GI_WidgetScrollbarSetMax(s_window *win, unsigned int max);
int			GI_WidgetScrollbarSetPos(s_window *win,  int pos);
int			GI_WidgetScrollbarSetSteps(s_window *win,  int steps);
int			GI_WidgetScrollbarSetPage(s_window *win,  int steps);

/*
   Combo
*/
HANDLE 		GI_WidgetComboCreate (HANDLE parent, char *name, int x, int y, int width, int height, int uiEditWidth, int uiEditHeight, int style, unsigned int uiID);
int 		GI_widget_combo_set (HANDLE w, char *str);
HRESULT 	GI_WidgetComboGet (HANDLE w, char *str);


/*
   Dynbmp
*/
int			GI_WidgetDynbmpSetTransparent(HANDLE h, unsigned int trans, unsigned int color);
int			GI_WidgetDynbmpSetState(HANDLE h, unsigned int state);
int			GI_WidgetDynbmpAddFile(HANDLE h, char *file);
HRESULT		GI_WidgetDynbmpSetUpdateTask(HANDLE hWnd, unsigned int msec);
HANDLE		GI_WidgetDynbmpCreate(HANDLE parent,
							char *name,
							int x, int y, int width, int height,
							int style, unsigned int ID);

/*
  Widget Listbox
*/
HANDLE 		GI_WidgetListboxAdd (s_window *win, char *str, unsigned int data, unsigned int hIcon);
HANDLE 		GI_WidgetListboxAddDIB (s_window *win, char *str, unsigned int data, DIB *hDIB);
HANDLE 		GI_WidgetListboxAddExt (s_window *win, char *str, unsigned int data, unsigned int hIcon, widget_menu *menu);
HANDLE		GI_WidgetListboxAddDIBExt (s_window *win, char *str, unsigned int data, DIB *hDIB, widget_menu *menu);
HANDLE 		GI_WidgetListboxAddDIBExt2 (s_window *win, char *str, unsigned int data, DIB *hDIB, DIB *hDIB_Big, widget_menu *menu);
void 		GI_WidgetListboxSetItemColor (HANDLE hWnd, s_window *hListbox, widget_lb_item *item, unsigned int fg, unsigned int bg, unsigned int fg_sel, unsigned int bg_sel);
unsigned int 	GI_WidgetListboxGetSelectedText (s_window *win, char *str, unsigned int *data);
HANDLE 		GI_WidgetListboxGetSelectedItem (s_window *win);
HANDLE 		GI_WidgetListboxCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int ID);
HANDLE 		GI_WidgetListboxCreateExt (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int ID, sFont *pFont);
int 		GI_WidgetListboxRemoveAll (s_window *win);
int 		GI_WidgetListboxSetMenu (s_window *win, widget_menu *menu);
int 		GI_WidgetListboxSetStyle (s_window *win, unsigned int style);
int 		GI_WidgetListboxUpdate (s_window *win, unsigned int autoupdate);
int 		GI_WidgetListboxDraw (s_window *win);
int 		GI_WidgetListboxSetColumn (s_window *win, int column_nr, int xpos, char *name);
int 		GI_WidgetListboxDeleteColumn (s_window *win, int column_nr);
int 		GI_WidgetListboxColumnSetPos (HANDLE hWnd, unsigned int iColumnIndex, unsigned int xpos);
int 		GI_WidgetListboxColumnGetPos (HANDLE hWnd, unsigned int iColumnIndex);
int 		GI_WidgetListboxColumnSetType (HANDLE hWnd, unsigned int iColumnIndex, unsigned int uiType);
int 		GI_WidgetListboxColumnSetSortType (HANDLE hWnd, unsigned int iColumnIndex, unsigned int uiType);
int 		GI_WidgetListboxColumnSetTitle (HANDLE hWnd, unsigned int iColumnIndex, char *pTitle);
HRESULT 	GI_WidgetListboxSetColumnProperty (HANDLE hWnd, int iColumnIndex, unsigned int uiProperty,...);
HANDLE 		GI_WidgetListboxGetItemByData (s_window *win, unsigned int data);
int 		GI_WidgetListboxShow (s_window *win, char bShow);
int 		GI_WidgetListboxGetItem (HANDLE hListBox, unsigned int uiIndex, char *pStr, unsigned int *data, unsigned int uiMaxLength);
int 		GI_WidgetListboxGetItemNr (HANDLE hListBox, unsigned int uiIndex, char *pStr, unsigned int *data, unsigned int uiMaxLength, widget_lb_item **ppItem);
int 		GI_WidgetListboxGetItemPtr (HANDLE hListBox, unsigned int uiIndex, widget_lb_item **ppItem);
HRESULT 	GI_WidgetListboxDelete (HANDLE hWnd, HANDLE hItem);
HRESULT 	GI_WidgetListboxSetNotifier (HANDLE hWnd, HANDLE hToNotify);
HRESULT 	GI_WidgetListboxEnableView (HANDLE hWnd, char ucViewType);
HRESULT 	GI_WidgetListboxSetDraw (HANDLE hWnd, int bDragSupport);
HRESULT 	GI_WidgetListboxRedrawItem (HANDLE hWnd, widget_lb_item *hItem);
int 		GI_WidgetListboxSetItemDIB (HANDLE hWnd, HANDLE hItem, DIB *hDIB, char bBig);
int 		GI_WidgetListboxSelectWithName (HANDLE hListbox, char *ucName);
HRESULT 	GI_WidgetListboxSetSelected (HANDLE hWnd, HANDLE hItem);
HRESULT 	GI_WidgetListboxSetOption (HANDLE hWnd, unsigned int uiItemIndex, char bSet);
HRESULT 	GI_WidgetListboxSetItemOption (HANDLE hWnd, HANDLE hItem, char bSet);
HRESULT 	GI_WidgetListboxOptionItemFixed (HANDLE hWnd, HANDLE hItem, char bFixed);
HRESULT 	GI_WidgetListboxGetOption (HANDLE hWnd, unsigned int uiItemIndex, char *bSet);
int 		GI_WidgetListboxOptionIsSet (HANDLE hWnd, HANDLE hItem);
HANDLE		GI_WidgetListboxGetNextItem (HANDLE hWnd, HANDLE hItem);
HANDLE		GI_WidgetListboxGetPrevItem (HANDLE hWnd, HANDLE hItem);
void * 		GI_WidgetListboxGetItemData (HANDLE hWnd, HANDLE hItem);
HRESULT 	GI_WidgetListboxPropertySet (HANDLE hWnd, char bSet, unsigned int uiProperty, unsigned int uiValue);
HRESULT 	GI_WidgetListboxSelected (HANDLE hWnd);
HANDLE 		GI_WidgetListboxNewItem (HANDLE hWnd);
HRESULT 	GI_WidgetListboxAddItem (HANDLE hWnd, HANDLE hItem);
int 		GI_WidgetListboxGetIndexOfItem (HANDLE hListBox, HANDLE hListBoxItem);
HRESULT 	GI_WidgetGetVisibleItemRegion (HANDLE hListBox, int iItemIndex, int iColumnIndex, s_region *pRegion);
HRESULT 	GI_WidgetListboxSetAtColumn (HANDLE hListBox, HANDLE hListBoxItem, unsigned int uiItemIndex, unsigned int uiColumnIndex, void *vpData);
HRESULT 	GI_WidgetListboxGetAtColumn (HANDLE hListBox, HANDLE hListBoxItem, unsigned int uiItemIndex, unsigned int uiColumnIndex, void *vpData, unsigned int uiMaxSize);
HRESULT 	GI_WidgetListboxSetItemData (HANDLE hListBox, HANDLE hListBoxItem, unsigned int uiItemIndex, unsigned int uiData);
HANDLE 		GI_WidgetListboxGetSelected (HANDLE hListBox);
HRESULT 	GI_WidgetListboxDeleteItem (HANDLE hWnd, HANDLE hItem);
HRESULT 	GI_WidgetListboxDeleteAll (HANDLE hWnd);
HRESULT 	GI_WidgetListboxSetTooltipItem (HANDLE hWnd, HANDLE hListBoxItem, char *pText, unsigned int uiPopupTimeMilliseconds);
int 		GI_WidgetListbox_GetItemPosition (HANDLE hWnd, HANDLE item);
int 		GI_WidgetListbox_ItemCount (HANDLE hWnd);
int 		GI_WidgetListboxRedrawHeader (HANDLE hWnd);
int 		GI_WidgetListboxSort (HANDLE hWnd, int iColumn, int iAscending);;

/* 
  Widget Static
*/
int 		GI_WidgetStaticWndFunc (HANDLE win, s_gi_msg *m);
HANDLE		GI_WidgetStaticCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, char *str);
HANDLE		GI_WidgetStaticCreateExt (HANDLE parent, char *name, int x, int y, int width, int height, int style, char *str, unsigned int uiBackColor, unsigned int uiColor);
int 		GI_WidgetStaticSet (HANDLE w, char *str);
void 		GI_WidgetStaticSetFont (HANDLE hWnd, sFont *pFont);
void 		GI_widget_static_style (widget_static *s);
HRESULT 	GI_WidgetStaticUseClientBackground (HANDLE hWnd, char bEnable);
HRESULT 	GI_WidgetStaticSetHyperlink (HANDLE hWnd, unsigned int uiID);
HRESULT 	GI_WidgetStaticSetTooltip (HANDLE hWnd, char *pText, unsigned int uiPopupTimeMilliseconds);
HRESULT 	GI_WidgetStaticSetStyle (HANDLE hWnd, unsigned int uiStyle);
HRESULT 	GI_WidgetStaticUseParentBackground (HANDLE hWnd, char bUse);
HRESULT 	GI_WidgetStaticSetDIB (HANDLE hWnd, DIB *hDIB);
HRESULT 	GI_WidgetStaticPropertySet (HANDLE hWnd, char bSet, unsigned int uiProperty, unsigned int uiValue);

/* 
  Widget button
*/
HANDLE 		GI_WidgetToolbuttonCreate (HANDLE parent, int x, int y, unsigned int ID, s_gi_icon *hIcon);
HANDLE 		GI_WidgetToolbuttonCreateDIB (HANDLE parent, int x, int y, unsigned int ID, DIB *hDIB);
HANDLE 		GI_WidgetToolbuttonCreateDIBExt (HANDLE parent, int x, int y, unsigned int ID, DIB *hDIB, unsigned int uiFlags, char *pCaption);
HANDLE 		GI_WidgetButtonCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int ID);
int 		GI_WidgetButtonSet (HANDLE hWnd, char *str);
int 		GI_WidgetButtonSetState (HANDLE hWnd, int state);
int 		GI_WidgetButtonDisable (HANDLE hWnd);
int 		GI_WidgetButtonEnable (HANDLE hWnd);
int 		GI_WidgetButtonSetIcon (HANDLE hWnd, s_gi_icon *icon);
int 		GI_WidgetButtonSetDIB (HANDLE hWnd, DIB* hDIB);
int 		GI_WidgetButtonSetPressedDIB (HANDLE hWnd, DIB* hDIB);
HRESULT 	GI_WidgetButtonSetTooltip (HANDLE hWnd, char *pText, unsigned int uiPopupTimeMilliseconds);
int 		GI_WidgetButtonSetStyle (HANDLE hWnd, unsigned int uiFlags);
int 		GI_WidgetButtonSetDIBText (HANDLE hWnd, DIB *hDIB, char *pText);
int 		GI_WidgetButtonSetBackground (HANDLE hWnd, DIB *hDIB);
int 		GI_WidgetButtonSetBackgroundBlit (HANDLE hWnd, int bPressed, sBlit *pBlit);
int 		GI_WidgetButtonSetTextColor (HANDLE hWnd, unsigned int uiColor);
int 		GI_WidgetButtonOwnerDraw (HANDLE hWnd, char bOwnerDraw, void *pCookie);
HRESULT 	GI_WidgetButtonUseParentBackground (HANDLE hWnd, char bUse);

/* 
  Widget predefined dialogs
*/
int			GI_Prompt(HANDLE hWnd, int x, int y, unsigned int flags, char *title, char *data, char *fmt, ...);
int			GI_Messagebox(HANDLE hWnd, unsigned int flags, char *title, char *fmt, ...);
int			GI_DialogSelectFileExt(HANDLE hWnd, unsigned int flags, char *title, char *initial_dir, char *filename);
HRESULT     GI_DialogSelectFont(HANDLE hWnd, unsigned int flags, sFont **ppFont);


/* 
  Widget edit
*/
HANDLE		GI_WidgetEditCreate(HANDLE parent, char *name, int x, int y, int width, int height, int style);
int			GI_WidgetEditSet(s_window *w, char *buf);
int			GI_WidgetEditGet(s_window *w, char *buf);


/* 
  Widget checkbox
*/
HANDLE 		GI_WidgetToolcheckCreate (HANDLE parent, int x, int y, unsigned int ID, s_gi_icon *hIcon);
HANDLE		GI_WidgetCheckboxCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int ID);
HRESULT		GI_WidgetCheckboxSetText (HANDLE win, char *str);
HRESULT		GI_WidgetCheckboxSetNoMessageSend (HANDLE win, int state);
HRESULT		GI_WidgetCheckboxSet (HANDLE win, int state);
HRESULT		GI_WidgetCheckboxSetState (HANDLE win, int state);
HRESULT 	GI_WidgetCheckboxDisable (HANDLE win);
HRESULT 	GI_WidgetCheckboxEnable (HANDLE win);
int 		GI_WidgetCheckboxGet (HANDLE win);
HRESULT 	GI_WidgetCheckboxSetTooltip (HANDLE hWnd, char *pText, unsigned int uiPopupTimeMilliseconds);

/*
  Widget radiobutton
*/
HANDLE 		GI_WidgetRadioCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int ID, HANDLE pRadioGroup);
int 		GI_WidgetRadioSetText (HANDLE win, char *str);
int 		GI_WidgetRadioSet (HANDLE win, int state);
int 		GI_WidgetRadioSetState (HANDLE win, int state);
int 		GI_WidgetRadioDisable (HANDLE win);
int 		GI_WidgetRadioEnable (HANDLE win);
int 		GI_WidgetRadioGet (HANDLE win);
HRESULT 	GI_WidgetRadioSetTooltip (HANDLE hWnd, char *pText, unsigned int uiPopupTimeMilliseconds);
HANDLE 		GI_WidgetRadioGroupCreate (char *ucCaption);
void 		GI_WidgetRadioGroupSet (HANDLE item);
HANDLE		GI_WidgetRadioGroupGetSelectedItem (widget_radio_group *pGroup);
void 		GI_WidgetRadioGroupSetState (widget_radio_group *pGroup, int state);

/*
   Tooltip
*/
HANDLE		GI_WidgetTooltipCreate (HANDLE hParentWnd, HANDLE hParentOwnerWnd, char *pText, unsigned int uiPopupTime);
HRESULT 	GI_WidgetTooltipEnable (HANDLE hToolTip);
HRESULT     GI_WidgetTooltipTestAndPopup (HANDLE hToolTip, unsigned int uiTimerID);
HRESULT		GI_WidgetTooltipDisable (HANDLE hToolTip);
HRESULT		GI_WidgetTooltipSetCallback (HANDLE hTooltip, tWidgetTooltipOnOpen fpOnOpen);
HRESULT		GI_WidgetTooltipSet (HANDLE hTooltip, char *pText, unsigned int uiPopupTime);

/* 
  Widget dialog
*/
s_window*	GI_DialogCreate(HANDLE hWnd, app_para *para);
int			GI_DialogRun(HANDLE hWnd, HANDLE win);
unsigned int 	GI_DialogHandle (HANDLE hParentWnd, HANDLE hDialog);
unsigned int 	GI_HandleDialogAndWindows (HANDLE hParentWnd, HANDLE hDialog, HANDLE *hWindows);
/* 
  Widget framewindow
*/
HANDLE		GI_WidgetFrameCreate (HANDLE parent, char *name, int x, int y, int width, int height, unsigned int ulBackGround, int style, sCreateApplication *pCreate);
HANDLE		GI_GetClientWindow (s_window *win);
HRESULT 	GI_SetMinimumApplicationWindowSize (HANDLE hWnd, int width, int height);
HRESULT 	GI_SetMaximumApplicationWindowSize (HANDLE hWnd, int width, int height);
HRESULT 	GI_WidgetFrameSetResizePoints (HANDLE hWnd, unsigned int uiPoints);

/*
  Widget clientwindow
*/
HANDLE 		GI_WidgetClientCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, void *win_func);
unsigned int 	GI_WidgetClientGetColor (s_window *hWnd);
HRESULT 	GI_WidgetClientSetBackgroundDIB (HANDLE hWnd, DIB *hDIB);
HRESULT 	GI_WidgetClientStyleSet (HANDLE hWnd, unsigned int uiStyle);
HRESULT 	GI_WidgetClientStyleClear (HANDLE hWnd, unsigned int uiStyle);
void *		GI_WidgetClientGetPrivate (HANDLE hWnd);
HRESULT 	GI_WidgetClientSetPrivate (HANDLE hWnd, void *pData);

/* 
  Widget Groupbox
*/
HANDLE 		GI_WidgetGroupboxCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, char *str);
int 		GI_WidgetGroupboxSet (HANDLE win, char *str);

/* 
  Widget Statusbar
*/
HANDLE 		GI_WidgetStatusbarCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style);
int 		GI_WidgetStatusSet (s_window *win, char *text);
HANDLE 		GI_WidgetStatusbarGetLayout (s_window *win);

/* 
  Widget Title
*/
HANDLE	 	GI_WidgetTitleCreate (HANDLE parent, char *name, int x, int y, int width, int height, unsigned int ulIcon, unsigned int style);
int 		GI_WidgetTitleSet (HANDLE win, char *name);
void 		GI_HelpIconShow (HANDLE hWnd);
void 		GI_HelpIconHide (HANDLE hWnd);

/*
  Menu
*/
HANDLE				GI_WidgetMenuCreate	(HANDLE	parent,	char *name, int x,	int	y, int width, int height, int style, widget_menu *menu);
widget_menu	*		GI_MenuCreate (HANDLE win);
int					GI_MenuUseIcons	(widget_menu *menu,	int	icons);
int					GI_MenuItemAddDIB (widget_menu_item	*i,	DIB	*hDIB);
widget_menu_item *	GI_MenuItemCreate (char *text,	unsigned int ID, unsigned int flags, unsigned int enabled);
widget_menu_item *	GI_MenuItemDataCreate (char *text,	unsigned int ID, unsigned int flags, unsigned int enabled, unsigned	int	uiData);
widget_menu_item *	GI_MenuItemIconCreate (char *text,	unsigned int ID, unsigned int flags, unsigned int enabled, s_gi_icon *icon);
widget_menu_item *	GI_MenuItemDIBCreate (char	*text, unsigned	int	ID,	unsigned int flags,	unsigned int enabled, DIB *hDIB);
int					GI_MenuAddItem (widget_menu	*menu, widget_menu_item	*item);
int					GI_MenuAddSub (widget_menu *menu, widget_menu_item *item, widget_menu *sub);
int					GI_MenuAddSubDIB (widget_menu *menu, widget_menu_item *item, widget_menu *sub, DIB *hDIB);
int					GI_MenuDataSet (widget_menu	*hMenu,	widget_popup *pData);
int					GI_WidgetMenuSorted	(widget_menu *pMenu, char bSorted);
int					GI_WidgetMenuUserBackground	(widget_menu *pMenu, char bEnabled);
widget_menu_item *	GI_WidgetMenuGetItemByIndex	(widget_menu *pMenu, unsigned int uiIndex);
widget_menu_item *	GI_WidgetMenuGetItemByID (widget_menu *pMenu, unsigned int ID);
HRESULT				GI_MenuItemSetAccelerator (HANDLE hMenu, unsigned int uiModKey,	unsigned int uiVKey, char *pDesc);
HRESULT				GI_WidgetMenuItemEnable	(HANDLE	hMenuItem, char	bEnable);
int					GI_MenuSetData (HANDLE hMenuItem, unsigned int uiData);
HRESULT				GI_WidgetMenuGetPopupData (HANDLE hMenu, widget_popup **ppData);
HRESULT				GI_WidgetMenuSetFlag (HANDLE hMenu,	unsigned int uiFlags);
HRESULT				GI_WidgetMenuItemChecked (HANDLE hItem,	int	bChecked);
HANDLE				GI_MenuItemUserCreate (char	*ucText, unsigned int uiID,	unsigned int uiFlags, widget_user_menu_item	*pUserMenuItem,	unsigned int uiData, DIB *hDIB);

/*
   Popup
*/
unsigned int 	GI_PopupExt (HANDLE hWnd, int x, int y, widget_menu *menu);
unsigned int 	GI_Popup (HANDLE hWnd, int x, int y, widget_menu *menu);
unsigned int 	GI_PopupAlign (HANDLE hWnd, int x, int y, widget_menu *menu, unsigned int align);
HRESULT 		GI_PopupGetData (HANDLE hWnd, widget_popup **pPopupData);

/*
  Widget property sheet
*/
int 		GI_WidgetPropertyChangeSheet (widget_prop *prop, widget_prop_sheet *o, widget_prop_sheet *n);
int			GI_WidgetPropertySwitch(s_window *win, widget_prop *prop, int x, int y, int iButton, int iPressed);
HANDLE		GI_WidgetPropertyCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style);
int 		GI_WidgetPropertyAddSheet (HANDLE win, HANDLE winsheet);
HRESULT		GI_WidgetPropertyRemoveSheet(HANDLE hWnd, HANDLE hSheet);
HRESULT     GI_WidgetPropertyGetActiveSheet(HANDLE hWnd, HANDLE *phSheet);
HRESULT     GI_WidgetPropertySheetGetData(HANDLE hWnd, void **ppData);
HANDLE 		GI_WidgetPropertySheetCreate (HANDLE parent, char *name, int(*window_func)(HANDLE, s_gi_msg *));
HRESULT		GI_WidgetPropertySwitchSheet(HANDLE hWnd, int bNext);

HRESULT 	GI_WidgetPropertySheetSetName (HANDLE hWnd, char *pName);
HRESULT 	GI_WidgetPropertySheetSetData (HANDLE hWnd, void *pData);
int 		GI_WidgetPropertySheetAdd (s_window *sheet, HANDLE widget);
HRESULT 	GI_WidgetPropertySheetAddFromResource (HANDLE hPropertyWindow, sResFile *pResFile, unsigned int uiDialogID, sDialogTemplate **ppDialog);
HRESULT 	GI_WidgetPropertyAddSheetFromResourceWndFunc (HANDLE hPropertyWindow, sResFile *pResFile, unsigned int uiDialogID, sDialogTemplate **ppDialog, void *win_func);
HRESULT 	GI_WidhetPropertySheetSetWndFunc (HANDLE hSheet, void *win_func);
HRESULT 	GI_WidgetPropertySheetSet (HANDLE hSheet);

/*
  InfoPanel
*/
HANDLE 		GI_WidgetPanelCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int uiFlags);
HANDLE 		GI_WidgetPanelItemCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int uiFlags);
HRESULT 	GI_WidgetPanelPropertySet (HANDLE hWnd, char bSet, unsigned int uiProperty, unsigned int uiValue);
int 		GI_WidgetPanelItemCollapsed (HANDLE hWnd);
HRESULT 	GI_WidgetPanelItemCollapse (HANDLE hWnd, int bCollapse);

/*
   Tree
*/
#if 0

/*
    Deprecated. Use WidgetTreeView from libwgtree.dll instead
*/
	HANDLE 		GI_WidgetTreeCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int ID);
	HANDLE 		GI_WidgetTreeAdd (HANDLE hTreeHandle, HANDLE hParentItemHandle, TREEITEMINFO *hTreeInfo);
	HRESULT 	GI_WidgetTreeSetIcon (HANDLE hTree, HANDLE hIcon);
	HRESULT 	GI_WidgetTreeSetDIB (HANDLE hTree, HANDLE hDIB);
	HRESULT 	GI_WidgetTreeRemoveAll (HANDLE hTree);
	HRESULT 	GI_WidgetTreeSetUpdate (HANDLE hTree, unsigned int update);
	HRESULT 	GI_WidgetTreeDraw (HANDLE hTree);
	HRESULT 	GI_WidgetTreeGetItem (HANDLE win, unsigned int flags, widget_tree_item *pItem, widget_tree_item **ppItem);
#endif

/*
   Layout
*/
HANDLE 		GI_WidgetLayoutCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int uiFlags);
HANDLE 		GI_WidgetLayoutAddSpace (HANDLE hLayoutWindow, int iSize);
HRESULT 	GI_WidgetLayoutAdd (HANDLE hLayoutWindow, HANDLE hWnd, int iWeight, unsigned int uiFlags, unsigned int uiAlignV, unsigned int uiAlignH);
HANDLE      GI_WidgetLayoutAddSpaceAt(HANDLE hLayoutWindow, int iSize, int iWeight, unsigned int uiAlignV, unsigned int uiAlignH);
HRESULT 	GI_WidgetLayoutSetItemSize (HANDLE hLayoutWindow, HANDLE hWnd, int iSize);
HRESULT 	GI_LayoutSetItemWeight (HANDLE hLayoutWindow, HANDLE hWnd, int iWeigth);
HRESULT 	GI_LayoutGetItemWeight (HANDLE hLayoutWindow, HANDLE hWnd, int *iWeigth);
HRESULT 	GI_WidgetLayoutReLayout (HANDLE hLayoutWindow);
HRESULT 	GI_WidgetLayoutResize (HANDLE hLayoutWindow);
void * 		GI_LayoutGetPrivateData (HANDLE hLayoutWindow);
HRESULT 	GI_LayoutSetPrivateData (HANDLE hLayoutWindow, void *vpData);
HRESULT 	GI_WidgetLayoutRemove (HANDLE hLayoutWindow, HANDLE hWnd, HANDLE hItem);
HRESULT GI_WidgetLayoutSetFlags(HANDLE hLayoutWindow, unsigned int uiFlags);
HRESULT GI_WidgetLayoutSetItemWeight(HANDLE hLayoutWindow, HANDLE hWnd, int iWeigth);

/*
   Splitter
*/
HANDLE		GI_WidgetSplitterCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style, unsigned int uiFlags);
HRESULT 	GI_WidgetSplitterAddWindow (HANDLE hSplitterWnd, unsigned int pos, HANDLE hWnd);
HRESULT 	GI_WidgetSplitterSetWidth (HANDLE hSplitterWnd, unsigned int uiPercent);
HRESULT 	GI_WidgetSplitterSetPixel (HANDLE hSplitterWnd, unsigned int uiPos);
HRESULT 	GI_WidgetSplitterGetPixel (HANDLE hSplitterWnd, unsigned int *uiPos);
HRESULT 	GI_WidgetSplitterGetWidth (HANDLE hSplitterWnd, unsigned int *iPercent);
HRESULT 	GI_WidgetSplitterSetBarWidth (HANDLE hSplitterWnd, unsigned int uiWidth);

/*
   Slider
*/
HANDLE		GI_WidgetSliderCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style);
int 		GI_WidgetSliderSet (HANDLE hWnd, int value);
int 		GI_WidgetSliderGet (HANDLE hWnd);
int 		GI_WidgetSliderSetMax (HANDLE hWnd, int value);
int			GI_WidgetSliderGetMax(HANDLE hWnd);

/* 
   Progress widget
*/
HANDLE		GI_WidgetProgressCreate (HANDLE parent, char *name, int x, int y, int width, int height, int style);
int 		GI_WidgetProgressSetColor (HANDLE w, COLOR color);
int 		GI_WidgetProgressSet (HANDLE w, int value);
int 		GI_WidgetProgressSetMax (HANDLE w, int value);
int 		GI_WidgetProgressForceRedraw (HANDLE hWnd);

/*
   Accelerator
*/
int 		GI_AcceleratorAdd (unsigned char cModifier, unsigned int uiCode, unsigned int uiAscii, unsigned int uiMsgType, unsigned int uiCommand, HANDLE hWnd);
int 		GI_AcceleratorRegisterGlobal (unsigned char cModifier, unsigned int uiUniCode, unsigned int uiVKey, unsigned int uiCommand, HANDLE hWnd);
int 		GI_AcceleratorUnRegisterGlobal (unsigned char cModifier, unsigned int uiUniCode, unsigned int uiVKey, unsigned int uiCommand, HANDLE hWnd);

/*
   Cursor
*/

HRESULT GI_MousePointerImageCreateFormCursor(sCursor *pCursor,
											 sMousePointer **ppPointer);
HRESULT GI_MousePointerImageFree(sMousePointer *pPointer);
HRESULT 	GI_WindowHideMouseCursor (HANDLE hWnd);
HRESULT 	GI_WindowShowMouseCursor (HANDLE hWnd);
HRESULT 	GI_MousePointerImageSet (unsigned int uiID, sCursor *pCursor);
int GI_WindowSetMousePointer(HANDLE hWnd, unsigned int uiID, sMousePointer *pPointer);

/*
   Clipboard
*/
HRESULT		GI_ClipBoardAdd(char *ucType,
						 void *vpData,
						 unsigned int uiSize);
HRESULT		GI_ClipBoardGet(char *ucType,
						 void **vpData,
						 unsigned int *puiSize);

/*
  Misc
*/
HRESULT GI_HelpOpen(char *ucPath);
HRESULT GI_WindowGetIcon(HANDLE hWnd, HANDLE hGIWMHandle, int bBig, DIB **hIcon);
HRESULT GI_WindowSetIcon(HANDLE hWnd, HANDLE hGIWMHandle, int bBig,  DIB *hIcon);
unsigned int GI_ThemeGetColor(unsigned int uiID);

HRESULT GI_WindowSetParent(HANDLE hWnd,HANDLE hParent,int x,int y);
HRESULT GI_WindowSetParentBackgroundDraw ( HANDLE hWnd,int bParentDrawsBackground);
int GI_WindowDestroyed (HANDLE hWnd);
HRESULT GI_WindowDimensionSet(HANDLE hWnd, int iX, int iY, int iWidth, int iHeight);

unsigned int GI_MessageGetTimeOfLast(void);

typedef struct sMessageTable
{
	unsigned int uiMessage;
	int (*fp)(HANDLE hWnd, s_gi_msg *hMsg);
} sMessageTable;

#define DECLARE_MESSAGE_TABLE(x) \
sMessageTable mtMainWindow[] = {
	
#define MESSAGE_FUNCTION(MESSAGE, FUNCTION) \
	{MESSAGE, FUNCTION},

#define END_MESSAGE_TABLE \
{0,0} \
};

#ifndef KERNEL
HRESULT MultipleObjectWait(sMultipleObjectWaitItem *pFirst,
						   int iObjects,
						   int uiTimeOutInMsecs);

HRESULT MultipleObjectWaitSet(sMultipleObjectWaitItem *pFirst,
							  int iType,
							  unsigned int uiData1, unsigned int uiData2);
#endif

int GI_WindowScroll(HANDLE hWnd, s_region *pRegion, int dx, int dy, char bInvalidate, char bScrollChilds);
int GI_WindowRaiseToTop(HANDLE hWnd);

int GI_FontsGetFamilyCount(void);
int GI_FontsGetStyleCount(char *ucFamily);
int GI_FontsEnumFamilies(int iIndex, char *ucFamily);
int GI_FontsEnumStyles(int iIndex, char *ucFamily, char *ucStyle);
int GI_FontsEnumFiles(int iIndex, char *ucFileName);
int GI_FontSystem(unsigned int uiID);
int GI_GetDefaultWheelAmount(void);
HRESULT GC_DrawRectInvert(GC *pGC, int x, int y, int w, int h);

int GI_dispatch_message_direct(HANDLE hWnd, tWindowFunction fpWindowFunction, s_gi_msg* m);

#define GC_FROM_MSG(hMsg) (GC*)(hMsg.para1)

#ifndef KERNEL

static inline unsigned int DIB_get_inline(GC *gc, DIB *hDIB, int iX, int iY) 
{
	if (hDIB->color == 32) 
	   return ((unsigned int*)hDIB->data)[iY * hDIB->width + iX];
	else if (hDIB->color == 16) 
	   return ((unsigned short*)hDIB->data)[iY * hDIB->width + iX];
	else if (hDIB->color == 8) 
	   return ((unsigned char*)hDIB->data)[iY * hDIB->width + iX];
	return 0;
}

static inline void DIB_set_inline(GC *gc, DIB *hDIB, int iX, int iY, unsigned int uiColor) 
{
	sRGBColor pRGBColorSource;
	sRGBColor pRGBColorDest;
	sRGBColor pRGBNewColor;
	unsigned int ch;

	if ((gc->flags & GC_FLAG_TRANSPARENT_ALPHA) ||
		(gc->flags & GC_FLAG_TRANSPARENT_LEVEL))
	{
		CONVERT_32_TO_COLOR(uiColor, &pRGBColorSource);

		pRGBColorSource.cAlpha = (uiColor & 0xFF000000) >> 24;
						
		if (gc->flags & GC_FLAG_TRANSPARENT_LEVEL)
			pRGBColorSource.cAlpha = gc->uiTransparentLevel;

		if ((pRGBColorSource.cAlpha == 255) || (
			(!(gc->flags & GC_FLAG_TRANSPARENT_ALPHA)) &&
			(!(gc->flags & GC_FLAG_TRANSPARENT_LEVEL))))
		{
		}
		else if (pRGBColorSource.cAlpha != 0)
		{
			//ch = DIB_get_inline(gc, hDIB, iX, iY)
			{
					unsigned int nAlpha = pRGBColorSource.cAlpha;
					unsigned int nDstColor = DIB_get_inline(gc, hDIB, iX, iY);
					unsigned int nSrcColor = uiColor & 0x00FFFFFF;
					unsigned int nSrc1 = nSrcColor & 0xff00ff;
					unsigned int nDst1 = nDstColor & 0xff00ff;
					
					nDst1 = ( nDst1 + ( ( nSrc1 - nDst1 ) * nAlpha >> 8 ) ) & 0xff00ff;
					nSrcColor &= 0xff00;
					nDstColor &= 0xff00;
					nDstColor = ( nDstColor + ( ( nSrcColor - nDstColor ) * nAlpha >> 8 ) ) & 0xff00;
					uiColor = nDst1 | nDstColor;
					uiColor |= pRGBColorSource.cAlpha  << 24;
			}

/*			CONVERT_32_TO_COLOR(
						ch,
					 	&pRGBColorDest);

			pRGBNewColor.red = pRGBColorDest.red * (256-pRGBColorSource.cAlpha) / 256 +
							pRGBColorSource.red * pRGBColorSource.cAlpha / 256;
			pRGBNewColor.green = pRGBColorDest.green * (256-pRGBColorSource.cAlpha) / 256 +
							pRGBColorSource.green * pRGBColorSource.cAlpha / 256;
			pRGBNewColor.blue = pRGBColorDest.blue * (256-pRGBColorSource.cAlpha) / 256 +
							pRGBColorSource.blue * pRGBColorSource.cAlpha / 256;

			uiColor = MAKE_COLOR(pRGBNewColor.red, pRGBNewColor.green, pRGBNewColor.blue); 
			uiColor |= (pRGBColorSource.cAlpha  << 24);
*/
		}
		else 
			return; // fully transparent
	}

	if (gc->flags & GC_FLAG_ROP)
	{
		unsigned int ucAlpha;

		switch (gc->uiROP)
		{
			case GC_ROP_COPY  :	 break;
			
			case GC_ROP_INVERT:  ch = DIB_get_inline(gc, hDIB, iX, iY);
								 ucAlpha = (ch >> 24) & 0xFF;

								 ch = ~ch;
								 ch = ch & 0x00FFFFFF;
								 ch = ch | (ucAlpha << 24);

								 uiColor = ch;

								 break;

			case GC_ROP_XOR   :  ch = DIB_get_inline(gc, hDIB, iX, iY);
								ch = ch ^ uiColor;
								uiColor = ch;
								break;

			default: 
				printd("Invalid ROP %d in GC_DIBSet", gc->uiROP);
		}
	}
	
	if (hDIB->color == 32) 
	   ((unsigned int*)hDIB->data)[iY * hDIB->stride + iX] = uiColor;
	else if (hDIB->color == 16) 
	   ((unsigned short*)hDIB->data)[iY * hDIB->stride + iX] = (unsigned short)uiColor;
	else if (hDIB->color == 8) 
	   ((unsigned char*)hDIB->data)[iY * hDIB->stride + iX] = (unsigned char)uiColor;

}
#endif

#include "skygi_interface.h"

HRESULT GI_AllocInterface(HANDLE hWnd, unsigned int uiSize, 
						  unsigned int uiFunction, ...);
sInterface *GI_InterfaceGet(HANDLE hWnd);

#define MAX_INPUT_SOURCES 5

#define MESSAGE_INPUTSOURCE_TYPE_UNUSED 0
#define MESSAGE_INPUTSOURCE_TYPE_DEP    1
#define MESSAGE_INPUTSOURCE_TYPE_IDLE   2

#include "libdcs/libdcs.h"

typedef unsigned int (*tInputSourceCallbackFunction)(void *vpData, void *vpCookie);

HRESULT GI_MessageWaitInputSourceAdd(unsigned int uiType,
								 void *vpData,
								 void *fpCallback,
								 void *vpCookie,
								 HANDLE *phSource);
HRESULT GI_MessageWaitInputSourceSetCookie(HANDLE hSource, void *vpCookie);

#ifdef __cplusplus
}
#endif

#endif


