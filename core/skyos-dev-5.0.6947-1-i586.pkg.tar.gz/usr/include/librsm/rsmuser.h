#ifndef _INC_REG_USER_
#define _INC_REG_USER_

#ifdef __cplusplus
extern "C" {
#endif


#ifndef KERNEL
#include "skyos/types.h"
#endif
#define RSM_TYPE_DWORD     0
#define RSM_TYPE_TEXT      1
#define RSM_TYPE_DATA      2
#define RSM_TYPE_DIRECTORY 3

#define REGISTRY_FLAG_USER_LOCAL  0x00000001
#define REGISTRY_FLAG_USE_DEFAULT 0x00000002

typedef struct RSMUserTypeDWORD
{
	unsigned int type;
	unsigned int  uiSize;
	unsigned int uiValue;
} RSMUserTypeDWORD;


typedef struct RSMUserTypeTEXT
{
	unsigned int type;
	unsigned int  uiSize;
	char ucData[0];
} RSMUserTypeTEXT;

#ifndef KERNEL

int RSMSetEntry(char *path, unsigned int type, unsigned int size, void *vpData);
int RegistryIterEntry(char *path, char *u_name,  unsigned int uiIndex);
int RegistryGetEntry(char *path, unsigned int *size, unsigned int *type,
					 void *vpData);
int RegistryGetDefaultText(char *path, unsigned int *size, char *def, void *vpData);
int RegistryGetDefaultValue(char *path, unsigned int def, void *vpData);
int RegistryGetOrSetDefaultValue(char *path, unsigned int def, void *vpData);
int RegistryGetOrSetDefaultText(char *path, char *def, char *data, unsigned int maxsize);
int RegistryGetText(char *ucPath, 
					char *ucDefaultKey, 
					char *ucKey, 
					unsigned int maxsize,
					unsigned int uiFlags);
int RegistrySetText(char *ucPath, char *ucKey, unsigned int uiFlags);
int RegistryGetValue(char *ucPath, 
					unsigned int uiDefaultValue, 
					unsigned int *puiValue, 
					unsigned int uiFlags);
int RegistrySetValue(char *ucPath, unsigned int uiValue, unsigned int uiFlags);
int RegistryLoad(char *filename);
int RegistrySave(void);
int RegistrySetKey(char *path, unsigned int type, unsigned int size, void *vpData);
HRESULT RegistrySetKeyText(char *ucKey, char *ucText);

#endif

#ifdef __cplusplus
}
#endif


#endif

