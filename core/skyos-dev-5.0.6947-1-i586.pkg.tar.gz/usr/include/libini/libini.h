#ifndef _PARSE_H
#define _PARSE_H

#ifdef __cplusplus
extern "C" {
#endif


typedef struct sConfiguration
{
	char *pBuffer;
	unsigned int uiOffset;
} sConfiguration;

typedef sConfiguration *CP_HANDLE;

HRESULT CP_Seek(CP_HANDLE handle, unsigned int pos);
HRESULT  CP_Tell(CP_HANDLE handle, unsigned int *pPos);
HRESULT  CP_GetLine(CP_HANDLE handle, char *pLine, unsigned int uiSize);
HRESULT  CP_Create(char *lpAddress, CP_HANDLE *pHandle);
HRESULT  CP_FindSection(CP_HANDLE handle, char *pSectionName);
HRESULT  CP_GetKey(CP_HANDLE handle, char *pKey, char *pLine,  unsigned int  uiMaxSize);
HRESULT  CP_GetKeyText(CP_HANDLE handle, char *pKey,	  char *pText,  unsigned int uiMaxSize);
HRESULT  CP_GetKeyValue(CP_HANDLE handle, char *pKey,  unsigned int *uiValue);
int LibIni_ParseFile(char *ucFileName, int *piFd,char *ucLine);
int LibIni_ParseFileMax(char *ucFileName, int *piFd, char *ucLine, unsigned int uiMax);
HRESULT CP_GetNextLine(CP_HANDLE handle, 
					   char *pStopToken, 
					   char *ucLine, unsigned int uiMaxSize);

#ifdef __cplusplus
}
#endif

#endif

