#ifndef _INC_LIBDCS_
#define _INC_LIBDCS_

#ifdef __cplusplus
extern "C" {
#endif

#include "skygi/skygi.h"


#define USER_LOCAL_SETTINGS			0x00000001
#define USER_OWN_SETTINGS			0x00000002
#define DATACOLLECTION_MUST_EXIST	0x00000004
typedef struct sDataCollectionItem
{
	int iSizeOfStructureOnDisk;
	int uiType;
	int iSize;

	char ucKey[255];

	union									// This must come last in structure
	{
		char *pString;
		unsigned int uiValue;
		double dDouble;
		s_region pRegion;
		unsigned long long ullValue;
	} Type;
} sDataCollectionItem;


typedef struct sDataCollection
{
	unsigned int uiMagic;					// Header start
	int iHeaderSize;						// Header end
	int iItems;

	/*
	   Add future data here. All coming members right below this line my be uninitialized after
	   loading a datacollection from disk.
    */
	unsigned int uiVersion;

	sDataCollectionItem **pItems;			// This must come last in structure
} sDataCollection;

enum
{
	ITEM_TYPE_UNUSED = 0,
	ITEM_TYPE_ANY,
	ITEM_TYPE_STRING,
	ITEM_TYPE_INT,
	ITEM_TYPE_DOUBLE,
	ITEM_TYPE_REGION,
	ITEM_TYPE_DATA,
	ITEM_TYPE_INT64,

};


enum
{
	DCS_MESSAGE_TYPE_INVALID = 0,
	DCS_MESSAGE_TYPE_DATACOLLECTION,
	DCS_MESSAGE_TYPE_KERNEL
};

typedef struct sDCSMessage
{
	unsigned int uiMessageType;
	char bWantReply;
	char ucSourceInterfacePath[255];
	sDataCollection *pCollection;
	void *pRawKernelData;
} sDCSMessage;

typedef struct sDCSInterface
{
	int uiDataExchangePort;
	char ucInterfacePath[255];
	char bBlocking;

	int iListenerThread;
	void *fpFunction;
	void *pCookie;
} sDCSInterface;

typedef struct sDCSRawMessage
{
	char ucSourceInterface[255];
	unsigned int uiSize;
	char bWantReply;
	unsigned int uiMessageType;
	unsigned int uiReserved[7];
	char pData[0];
} sDCSRawMessage;

HRESULT 	DataCollectionCreate(sDataCollection **ppDataCollection);
HRESULT 	DataCollectionFree (sDataCollection *pDataCollection);
HRESULT 	DataCollectionAddString (sDataCollection *pDataCollection, char *ucKey, char *ucString);
HRESULT 	DataCollectionAddInt32 (sDataCollection *pDataCollection, char *ucKey, unsigned int uiValue);
HRESULT     DataCollectionAddInt64(sDataCollection *pDataCollection,char *ucKey,unsigned long long ullValue);
HRESULT 	DataCollectionSetString (sDataCollection *pDataCollection, char *ucKey, char *ucString);
HRESULT 	DataCollectionSetInt32 (sDataCollection *pDataCollection, char *ucKey, unsigned int uiValue);
HRESULT DataCollectionSetInt64(sDataCollection *pDataCollection,
							  char *ucKey,
							  unsigned int ullValue);
HRESULT 	DataCollectionGetString (sDataCollection *pDataCollection, char *ucKey, int iIndex, char *ucString, int iMaxSize, char *ucDefaultString);
char* DataCollectionGetStringPtr(sDataCollection *pDataCollection,
						 								 char *ucKey,
													     int iIndex,
						  							     char *ucDefaultString);
int DataCollectionHas(sDataCollection *pDataCollection,char *ucKey, int iIndex);

HRESULT 	DataCollectionGetInt32 (sDataCollection *pDataCollection, char *ucKey, int iIndex, unsigned int *puiValue, unsigned int uiDefaultValue);
HRESULT		DataCollectionGetInt64(sDataCollection *pDataCollection,char *ucKey,int iIndex,unsigned long long *pullValue,unsigned long long ullDefaultValue);
HRESULT 	DataCollectionRemove (sDataCollection *pDataCollection, char *ucKey, int iIndex);
HRESULT 	DataCollectionOpen (char *ucVendorName, char *ucApplicationName, char *ucSettingsFileName, unsigned int uiFlags, sDataCollection **ppDataCollection);
HRESULT 	DataCollectionWrite (char *ucVendorName, char *ucApplicationName, char *ucSettingsFileName, unsigned int uiFlags, sDataCollection *pDataCollection);
HRESULT 	DataCollectionGetWindowPosition (sDataCollection *pDataCollection, char *ucWindowName, int *puiX, int *puiY, int *puiWidth, int *puiHeight, int uiDefaultX, int uiDefaultY, int uiDefaultWidth, int uiDefaultHeight);
HRESULT 	DataCollectionSetWindowPosition (sDataCollection *pDataCollection, char *ucWindowName, HANDLE hWnd);
HRESULT		DataCollectionPack(sDataCollection *pDataCollection, void **ppData, unsigned int *puiSize);
HRESULT		DataCollectionUnpack(char *pData, sDataCollection **ppDataCollection);
char * 	DataCollectionGetItemType (sDataCollectionItem *pItem);
void * 	DataCollectionGetItemNumber (sDataCollection *pDataCollection, int iNumber);
char * 	DataCollectionGetKeyOfItem (sDataCollectionItem *pItem);
void * 	DataCollectionGetItemData (sDataCollectionItem *pItem);
unsigned int 	DataCollectionGetVersion (sDataCollection *pDataCollection);
unsigned int 	DataCollectionGetNumberOfItems (sDataCollection *pDataCollection);
HRESULT 	DCS_FreeMessage (sDCSMessage *pMessage);
HRESULT 	DCS_AllocMessage (sDCSMessage **ppMessage, char *ucType);
HRESULT 	DCS_AddMessageString (sDCSMessage *pMessage, char *pKey, char *pString);
HRESULT 	DCS_AddMessageInteger (sDCSMessage *pMessage, char *pKey, unsigned int uiValue);
HRESULT     DCS_AddMessage64Bit(sDCSMessage *pMessage, char *pKey, unsigned long long ullValue);
HRESULT 	DCS_InterfaceSetBlocking (sDCSInterface *pInterface, int bBlocking);
HRESULT 	DCS_MessageSetReply (sDCSMessage *pMessage, int bWantReply);
HRESULT 	DCS_MessageWantReply (sDCSMessage *pMessage);
HRESULT 	DCS_RegisterInterface (char *ucInterfacePath, sDCSInterface **ppInterface);
HRESULT 	DCS_RegisterThreadPrivateInterface (char *ucInterfacePath, sDCSInterface **ppInterface);
#ifdef KERNEL
HRESULT DCS_SendMessage(char *pKernelSourceInterface, char *ucDestinationInterface, sDCSMessage *pMessage);
#else
HRESULT 	DCS_SendMessage (sDCSInterface *pSourceInterface, char *ucDestinationInterface, sDCSMessage *pMessage);
#endif
HRESULT 	DCS_WaitForMessageInternal (sDCSInterface *pInterface, char *ucFromInterface, unsigned int uiTimeOutInMsecs, sDCSMessage **ppMessage);
HRESULT 	DCS_WaitForMessage (sDCSInterface *pInterface, char *ucFromInterface, sDCSMessage **ppMessage);
HRESULT 	DCS_WaitForMessageTimeout (sDCSInterface *pInterface, char *ucFromInterface, unsigned int uiTimeOutInMsecs, sDCSMessage **ppMessage);
HRESULT 	DCS_IsMessageWaiting (sDCSInterface *pInterface);
HRESULT 	DCS_MessageGetType (sDCSMessage *pMessage, char *ucType, int iMaxSize, int *piSize);
HRESULT 	DCS_MessageGetString (sDCSMessage *pMessage, char *pKey, char  *ucData, int iMaxSize, int *piSize);
HRESULT 	DCS_MessageGetStringIndex (sDCSMessage *pMessage, char *pKey, int iIndex, char  *ucData, int iMaxSize, int *piSize);
char * 	DCS_MessageGetStringPtr (sDCSMessage *pMessage, char *pKey);
HRESULT 	DCS_MessageGetIntegerIndex (sDCSMessage *pMessage, char *pcKey, int iIndex,unsigned int *uiValue);
HRESULT DCS_MessageGet64BitIndex(sDCSMessage *pMessage,
								   char *pKey,
								   int iIndex,
								   unsigned long long *pullValue);
HRESULT 	DCS_MessageGetInteger (sDCSMessage *pMessage, char *pcKey, unsigned int *uiValue);
HRESULT DCS_MessageGet64Bit(sDCSMessage *pMessage,
								   char *pKey,
								   unsigned long long *pullValue);
HRESULT DCS_Clear(sDCSInterface *pInterface);
int 	DCS_GetDEPFromInterface (sDCSInterface *pInterface);
HRESULT 	DCS_GetDEPNameFromInterface (sDCSInterface *pInterface, char *pName);
HRESULT 	DCS_FreeInterface (sDCSInterface *pInterface);
HRESULT 	DCS_GetDataCollectionFromMessage (sDCSMessage *pMessage, sDataCollection **ppDataCollection);
unsigned int 	DCS_GetMessageType (sDCSMessage *pMessage);
char * 	DCS_GetSender (sDCSMessage *pMessage);
void 	DCS_DumpMessage (sDCSMessage *pMessage);
void 	DCS_DumpMessageToStdout (sDCSMessage *pMessage);


typedef unsigned int (*tDCSAsynchronousListenerFunction)(sDCSInterface *pInterface , sDCSMessage *pMessage, void *pCookie);
HRESULT DCS_RegisterAsynchronousListener(char *ucInterfacePath,
												char bThreadPrivate,
												tDCSAsynchronousListenerFunction pFunction,
												void *pCookie,
												sDCSInterface **ppInterface);

enum
{
	REMOTE_INTERFACE_PARAMETER_INT32,
	REMOTE_INTERFACE_PARAMETER_INT64,
	REMOTE_INTERFACE_PARAMETER_STRING,
	REMOTE_INTERFACE_PARAMETER_DATA,
	REMOTE_INTERFACE_PARAMETER_NONE
};

typedef unsigned int (*tRemoteInterfaceCallbackFunction)(HANDLE hInterface, sDCSInterface *pDCSInterface, sDCSMessage *pMessage,
													   void *p1, void *p2, void *p3, void *p4, void *p5, void *p6, void *p7, void *p8, void *p9, void *p10,
													   void *p11, void *p12, void *p13, void *p14, void *p15, void *p16);


HRESULT RemoteInterface_Create(char *szInterfaceName,
							   void *fpFunction,
							   HANDLE *hpInterface);
HRESULT RemoteInterface_Enable(HANDLE hInterface);
HRESULT RemoteInterface_AddParameter(HANDLE hInterface,
								   char *pParameterName,
								   unsigned int uiParameterType,
								   ...);
sDataCollectionItem *DataCollectionFind(sDataCollection *pDataCollection,
											 char *ucKey,
											 unsigned int uiType,
											 int iIndex);

#ifdef __cplusplus
}
#endif

#endif

