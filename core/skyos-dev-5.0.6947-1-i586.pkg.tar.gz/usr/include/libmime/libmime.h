#ifndef _INC_LIBMIME_H_
#define _INC_LIBMIME_H_

#ifdef __cplusplus
extern "C" {
#endif

#define MIME_FILETYPE_GET_ICON_FOLDER			0x00000001	//!< Get the icon for folders
#define MIME_FILETYPE_GET_ICON_FOLDER_MARKED	0x00000002  //!< Get the icon for marked folders
#define MIME_FILETYPE_GET_ICON_UNKNOWN			0x00000004	//!< Get the icon for 'unknown file'
#define MIME_FILETYPE_GET_ICON_BIG				0x00000008	//!< Get a big icon (32x32)
#define MIME_FILETYPE_GET_ICON_DEVICE			0x00000010	//!< Get the icon for device files

#define MIME_FILE_ICON_SET_SMALL				0x00000001
#define MIME_FILE_ICON_SET_BIG  				0x00000002
#define MIME_FILE_ICON_SET_ALL					(MIME_FILE_ICON_SET_SMALL | MIME_FILE_ICON_SET_BIG)				

typedef HRESULT *(fIndexCallback)(void* pCookie, char *ucWord, unsigned int uiFlags);

typedef struct sMimeTypeAttribute
{
	char *ucAttribute;
	unsigned int uiAttributeType;
	unsigned int uiAttributeLength;
	void *pAttributeData;
} sMimeTypeAttribute;

typedef struct sIndexingParameters
{
	int iMaxFileSize;
	int iMaxKBPerFile;
} sIndexingParameters;



HRESULT Mime_GetMimeType(char *ucExtension,
											   char *pFile,
											   char *ucMimeType);
HRESULT Mime_GetAttributes(char *pFile,
											     sMimeTypeAttribute **ppAttributes);
HRESULT Mime_IndexContent(char *pFile,
											    void *pCookie,
												fIndexCallback *pICallback);
HRESULT Mime_GetAttributesList(unsigned int uiIndex,
													 char *ucType,
													 sMimeTypeAttribute **ppAttributes);

void* Mime_FileTypeIconGetPath(char *ucExtension,
									 char *ucFileName,
								     unsigned int uiFlags,
									 char *ucIconPath);
#ifdef __cplusplus
}
#endif


#endif
