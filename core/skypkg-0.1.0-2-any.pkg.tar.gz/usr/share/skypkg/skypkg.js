/**
 * skypkg-lite — Arch-style package manager for SkyOS
 * Kept small to fit within SkyOS QuickJS memory limits.
 */
import * as std from 'std';
import { downloadFile } from 'net';

var CONF="/etc/skypkg.conf",DB="/var/lib/skypkg/",LOCAL=DB+"local/",SYNC=DB+"sync/",CACHE=DB+"cache/",TAR="busybox tar",BB="busybox ";
function run(c){var p=std.popen(c,"r");if(!p)return"";var o=p.readAsString();p.close();return o||"";}
function mkdirp(p){run(BB+"mkdir -p "+p);}
function msg(t){std.out.puts(":: "+t+"\n");}
function err(t){std.err.puts("error: "+t+"\n");}
function readF(p){return std.loadFile(p)||"";}
function writeF(p,c){var f=std.open(p,"w");if(!f)return;f.puts(c);f.close();}
function exists(p){var f=std.open(p,"r");if(f){f.close();return true;}return false;}

function parsePkginfo(t){var o={},ls=t.split("\n");for(var i=0;i<ls.length;i++){var l=ls[i].trim();if(!l||l[0]==="#")continue;var e=l.indexOf("=");if(e<0)continue;var k=l.substring(0,e).trim(),v=l.substring(e+1).trim();if(k==="depend"){if(!o.depend)o.depend=[];o.depend.push(v);}else o[k]=v;}return o;}
function parseDesc(t){var o={},ls=t.split("\n"),k=null,vs=[];function fl(){if(k)o[k]=vs.length===1?vs[0]:vs;}for(var i=0;i<ls.length;i++){var m=ls[i].match(/^%([A-Z]+)%$/);if(m){fl();k=m[1].toLowerCase();vs=[];}else if(ls[i].trim())vs.push(ls[i].trim());}fl();return o;}

function loadConf(){var c={repos:[]};if(!exists(CONF))return c;var ls=readF(CONF).split("\n"),r=null;for(var i=0;i<ls.length;i++){var l=ls[i].trim();if(!l||l[0]==="#")continue;var s=l.match(/^\[(\w+)\]$/);if(s){r=s[1]!=="options"?{name:s[1],server:""}:null;if(r)c.repos.push(r);continue;}var e=l.indexOf("=");if(e>0&&r){var k=l.substring(0,e).trim(),v=l.substring(e+1).trim();if(k==="Server")r.server=v;}}return c;}

function getLocal(){var l=run(BB+"ls "+LOCAL+" 2>/dev/null").trim();return l?l.split("\n").filter(function(s){return s!=="";}):[];}
function findLocal(n){var ds=getLocal();for(var i=0;i<ds.length;i++){var d=parseDesc(readF(LOCAL+ds[i]+"/desc"));if(d.name===n)return ds[i];}return null;}

function installLocal(f){
msg("Installing "+f);var tmp="/tmp/skypkg-"+Date.now();mkdirp(tmp);
run(TAR+" xzf "+f+" -C "+tmp+" .PKGINFO 2>/dev/null");
var info=parsePkginfo(readF(tmp+"/.PKGINFO"));
if(!info.pkgname){err("No .PKGINFO");return false;}
var ver=info.pkgver+"-"+(info.pkgrel||"1");
msg("Package: "+info.pkgname+" "+ver);
var old=findLocal(info.pkgname);if(old){msg("Replacing "+old);removeP(info.pkgname,true);}
msg("Extracting...");
run(TAR+" xzf "+f+" -C / --exclude=.PKGINFO --exclude=.INSTALL --exclude=.FILELIST --exclude=.MTREE 2>/dev/null");
var dbDir=LOCAL+info.pkgname+"-"+ver+"/";mkdirp(dbDir);
writeF(dbDir+"desc","%NAME%\n"+info.pkgname+"\n\n%VERSION%\n"+ver+"\n\n%DESC%\n"+(info.pkgdesc||"")+"\n\n%ARCH%\n"+(info.arch||"i586")+"\n\n%URL%\n"+(info.url||"")+"\n\n"+(info.depend?"%DEPENDS%\n"+info.depend.join("\n")+"\n\n":""));
var files=run(TAR+" tzf "+f+" 2>/dev/null").split("\n").filter(function(x){return x&&x[0]!==".";}).join("\n");
writeF(dbDir+"files","%FILES%\n"+files+"\n");
run(BB+"rm -rf "+tmp);msg(info.pkgname+" "+ver+" installed");return true;}

function removeP(n,q){var dir=findLocal(n);if(!dir){if(!q)err("Not installed: "+n);return;}if(!q)msg("Removing "+n+"...");var ls=readF(LOCAL+dir+"/files").split("\n").filter(function(s){return s&&s!=="%FILES%"&&s[s.length-1]!=="/";});for(var i=ls.length-1;i>=0;i--)run(BB+"rm -f /"+ls[i]);run(BB+"rm -rf "+LOCAL+dir);if(!q)msg(n+" removed");}

function syncDB(conf){
msg("Synchronizing package databases...");
for(var i=0;i<conf.repos.length;i++){var r=conf.repos[i];if(!r.server)continue;
var url=r.server+"/"+r.name+".db.tar.gz",tmp="/tmp/"+r.name+".db.tar.gz";
msg("Downloading "+r.name+"...");
try{var resp=downloadFile(url,tmp);if(resp.status!==200){err("HTTP "+resp.status);continue;}}catch(e){err("Download: "+e);continue;}
var dbDir=SYNC+r.name+"/";mkdirp(dbDir);run(BB+"rm -rf "+dbDir+"*");
run(TAR+" xzf "+tmp+" -C "+dbDir+" 2>/dev/null");run(BB+"rm -f "+tmp);
msg(r.name+" synced ("+resp.size+" bytes)");}}

function installRepo(conf,n){
for(var i=0;i<conf.repos.length;i++){var r=conf.repos[i];
var pkgs=run(BB+"ls "+SYNC+r.name+"/ 2>/dev/null").trim().split("\n");
for(var j=0;j<pkgs.length;j++){var d=parseDesc(readF(SYNC+r.name+"/"+pkgs[j]+"/desc"));
if(d.name===n){var fn=d.filename||(pkgs[j]+"-i586.pkg.tar.gz");mkdirp(CACHE);
msg("Downloading "+fn+"...");
try{var resp=downloadFile(r.server+"/"+fn,CACHE+fn);if(resp.status!==200){err("HTTP "+resp.status);return;}}catch(e){err("Download: "+e);return;}
installLocal(CACHE+fn);return;}}}err("Not found: "+n);}

function searchRepo(conf,q){var f=false;for(var i=0;i<conf.repos.length;i++){var r=conf.repos[i];var pkgs=run(BB+"ls "+SYNC+r.name+"/ 2>/dev/null").trim().split("\n");for(var j=0;j<pkgs.length;j++){if(!pkgs[j])continue;var d=parseDesc(readF(SYNC+r.name+"/"+pkgs[j]+"/desc"));var nm=d.name||pkgs[j],de=d.desc||"";if(nm.indexOf(q)>=0||de.toLowerCase().indexOf(q.toLowerCase())>=0){std.out.puts(r.name+"/"+nm+" "+(d.version||"")+"\n    "+de+"\n");f=true;}}}if(!f)msg("No results for: "+q);}

var args=scriptArgs.slice(1);
if(!args.length){std.out.puts("skypkg — package manager for SkyOS\n  -S <pkg>  Install from repo\n  -Sy       Sync databases\n  -Ss <q>   Search\n  -U <file> Install local\n  -R <pkg>  Remove\n  -Q        List installed\n  -Qi <pkg> Info\n  -Ql <pkg> Files\n");}
else{mkdirp(LOCAL);mkdirp(SYNC);mkdirp(CACHE);
var op=args[0],a=args[1]||null,conf=loadConf();
if(op==="-U"&&a)installLocal(a);
else if(op==="-R"&&a)removeP(a);
else if(op==="-Q"){var d=getLocal();if(!d.length)msg("No packages installed.");else d.forEach(function(x){std.out.puts(x+"\n");});}
else if(op==="-Qi"&&a){var dir=findLocal(a);if(!dir)err("Not installed: "+a);else{var d=parseDesc(readF(LOCAL+dir+"/desc"));for(var k in d)std.out.puts(k+": "+(Array.isArray(d[k])?d[k].join(", "):d[k])+"\n");}}
else if(op==="-Ql"&&a){var dir=findLocal(a);if(!dir)err("Not installed: "+a);else std.out.puts(readF(LOCAL+dir+"/files"));}
else if(op==="-Sy")syncDB(conf);
else if(op==="-S"&&a)installRepo(conf,a);
else if(op==="-Ss"&&a)searchRepo(conf,a);
else err("Unknown: "+op);}
