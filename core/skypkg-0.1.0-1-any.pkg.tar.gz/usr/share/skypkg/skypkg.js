/**
 * skypkg-lite — Arch-style package manager for SkyOS
 * Kept under 10KB to avoid QuickJS compilation limit on SkyOS.
 * Usage:
 *   skyjs skypkg-lite.js -U <file>     Install local package
 *   skyjs skypkg-lite.js -Q            List installed
 *   skyjs skypkg-lite.js -Qi <pkg>     Package info
 *   skyjs skypkg-lite.js -Ql <pkg>     List package files
 *   skyjs skypkg-lite.js -R <pkg>      Remove package
 *   skyjs skypkg-lite.js -Sy           Sync repo database
 *   skyjs skypkg-lite.js -S <pkg>      Install from repo
 *   skyjs skypkg-lite.js -Ss <q>       Search remote
 */
import * as std from 'std';
import { downloadFile } from 'net';

var CONF = "/etc/skypkg.conf";
var DB = "/var/lib/skypkg/";
var LOCAL = DB + "local/";
var SYNC = DB + "sync/";
var CACHE = DB + "cache/";
var TAR = "busybox tar";
var BB = "busybox ";

function run(c) { var p = std.popen(c, "r"); if (!p) return ""; var o = p.readAsString(); p.close(); return o || ""; }
function mkdirp(p) { run(BB + "mkdir -p " + p); }
function msg(t) { std.out.puts(":: " + t + "\n"); }
function err(t) { std.err.puts("error: " + t + "\n"); }
function readF(p) { return std.loadFile(p) || ""; }
function writeF(p, c) { var f = std.open(p, "w"); if (!f) return; f.puts(c); f.close(); }
function exists(p) { var f = std.open(p, "r"); if (f) { f.close(); return true; } return false; }

function parsePkginfo(text) {
    var o = {}; var lines = text.split("\n");
    for (var i = 0; i < lines.length; i++) {
        var l = lines[i].trim();
        if (!l || l[0] === "#") continue;
        var eq = l.indexOf("=");
        if (eq < 0) continue;
        var k = l.substring(0, eq).trim(), v = l.substring(eq + 1).trim();
        if (k === "depend") { if (!o.depend) o.depend = []; o.depend.push(v); }
        else o[k] = v;
    }
    return o;
}

function parseDesc(text) {
    var o = {}, lines = text.split("\n"), key = null, vals = [];
    function flush() { if (key) o[key] = vals.length === 1 ? vals[0] : vals; }
    for (var i = 0; i < lines.length; i++) {
        var m = lines[i].match(/^%([A-Z]+)%$/);
        if (m) { flush(); key = m[1].toLowerCase(); vals = []; }
        else if (lines[i].trim()) vals.push(lines[i].trim());
    }
    flush(); return o;
}

function loadConf() {
    var conf = { repos: [] };
    if (!exists(CONF)) return conf;
    var lines = readF(CONF).split("\n"), repo = null;
    for (var i = 0; i < lines.length; i++) {
        var l = lines[i].trim();
        if (!l || l[0] === "#") continue;
        var sec = l.match(/^\[(\w+)\]$/);
        if (sec) { if (sec[1] !== "options") { repo = { name: sec[1], server: "" }; conf.repos.push(repo); } else repo = null; continue; }
        var eq = l.indexOf("=");
        if (eq > 0 && repo) { var k = l.substring(0, eq).trim(), v = l.substring(eq + 1).trim(); if (k === "Server") repo.server = v; }
    }
    return conf;
}

function getLocal() {
    var l = run(BB + "ls " + LOCAL + " 2>/dev/null").trim();
    return l ? l.split("\n").filter(function(s) { return s !== ""; }) : [];
}

function findLocal(name) {
    var dirs = getLocal();
    for (var i = 0; i < dirs.length; i++) {
        var desc = readF(LOCAL + dirs[i] + "/desc");
        if (desc) { var d = parseDesc(desc); if (d.name === name) return dirs[i]; }
    }
    return null;
}

// -U: Install local package
function installLocal(pkgFile) {
    msg("Installing " + pkgFile);
    var tmp = "/tmp/skypkg-" + Date.now();
    mkdirp(tmp);
    run(TAR + " xzf " + pkgFile + " -C " + tmp + " .PKGINFO 2>/dev/null");
    var info = parsePkginfo(readF(tmp + "/.PKGINFO"));
    if (!info.pkgname) { err("No .PKGINFO"); return false; }
    var ver = info.pkgver + "-" + (info.pkgrel || "1");
    msg("Package: " + info.pkgname + " " + ver);

    // Check existing
    var old = findLocal(info.pkgname);
    if (old) { msg("Replacing " + old); removeP(info.pkgname, true); }

    // Extract to root, excluding metadata files
    msg("Extracting...");
    run(TAR + " xzf " + pkgFile + " -C / --exclude=.PKGINFO --exclude=.INSTALL --exclude=.FILELIST --exclude=.MTREE 2>/dev/null");

    // Register in DB
    var dbDir = LOCAL + info.pkgname + "-" + ver + "/";
    mkdirp(dbDir);
    var desc = "%NAME%\n" + info.pkgname + "\n\n%VERSION%\n" + ver + "\n\n%DESC%\n" + (info.pkgdesc || "") + "\n\n%ARCH%\n" + (info.arch || "i586") + "\n\n%URL%\n" + (info.url || "") + "\n\n";
    if (info.depend) desc += "%DEPENDS%\n" + info.depend.join("\n") + "\n\n";
    writeF(dbDir + "desc", desc);
    var files = run(TAR + " tzf " + pkgFile + " 2>/dev/null").split("\n").filter(function(f) { return f && f[0] !== "."; }).join("\n");
    writeF(dbDir + "files", "%FILES%\n" + files + "\n");

    // Run .INSTALL if present
    if (exists(tmp + "/.INSTALL")) {
        msg("Running post_install...");
        run(BB + "sh -c '. " + tmp + "/.INSTALL && post_install " + ver + "' 2>/dev/null");
    }

    run(BB + "rm -rf " + tmp);
    msg(info.pkgname + " " + ver + " installed");
    return true;
}

// -R: Remove package
function removeP(name, quiet) {
    var dir = findLocal(name);
    if (!dir) { if (!quiet) err("Not installed: " + name); return; }
    if (!quiet) msg("Removing " + name + "...");
    var fdata = readF(LOCAL + dir + "/files");
    var lines = fdata.split("\n").filter(function(s) { return s && s !== "%FILES%" && s[s.length - 1] !== "/"; });
    for (var i = lines.length - 1; i >= 0; i--) run(BB + "rm -f /" + lines[i]);
    run(BB + "rm -rf " + LOCAL + dir);
    if (!quiet) msg(name + " removed");
}

// -Sy: Sync databases
function syncDB(conf) {
    msg("Synchronizing package databases...");
    for (var i = 0; i < conf.repos.length; i++) {
        var r = conf.repos[i];
        if (!r.server) continue;
        var url = r.server + "/" + r.name + ".db.tar.gz";
        var tmp = "/tmp/" + r.name + ".db.tar.gz";
        msg("Downloading " + r.name + "...");
        try {
            var resp = downloadFile(url, tmp);
            if (resp.status !== 200) { err("HTTP " + resp.status); continue; }
        } catch (e) { err("Download failed: " + e); continue; }
        var dbDir = SYNC + r.name + "/";
        mkdirp(dbDir);
        run(BB + "rm -rf " + dbDir + "*");
        run(TAR + " xzf " + tmp + " -C " + dbDir + " 2>/dev/null");
        run(BB + "rm -f " + tmp);
        msg(" " + r.name + " synced (" + resp.size + " bytes)");
    }
}

// -S: Install from repo
function installRepo(conf, name) {
    for (var i = 0; i < conf.repos.length; i++) {
        var r = conf.repos[i];
        var pkgs = run(BB + "ls " + SYNC + r.name + "/ 2>/dev/null").trim().split("\n");
        for (var j = 0; j < pkgs.length; j++) {
            var desc = readF(SYNC + r.name + "/" + pkgs[j] + "/desc");
            if (!desc) continue;
            var d = parseDesc(desc);
            if (d.name === name) {
                var fn = d.filename || (pkgs[j] + "-i586.pkg.tar.gz");
                var url = r.server + "/" + fn;
                var cache = CACHE + fn;
                mkdirp(CACHE);
                msg("Downloading " + fn + "...");
                try {
                    var resp = downloadFile(url, cache);
                    if (resp.status !== 200) { err("HTTP " + resp.status); return; }
                } catch (e) { err("Download: " + e); return; }
                installLocal(cache);
                return;
            }
        }
    }
    err("Package not found: " + name);
}

// -Ss: Search remote
function searchRepo(conf, q) {
    var found = false;
    for (var i = 0; i < conf.repos.length; i++) {
        var r = conf.repos[i];
        var pkgs = run(BB + "ls " + SYNC + r.name + "/ 2>/dev/null").trim().split("\n");
        for (var j = 0; j < pkgs.length; j++) {
            if (!pkgs[j]) continue;
            var d = parseDesc(readF(SYNC + r.name + "/" + pkgs[j] + "/desc"));
            var n = d.name || pkgs[j], de = d.desc || "";
            if (n.indexOf(q) >= 0 || de.toLowerCase().indexOf(q.toLowerCase()) >= 0) {
                std.out.puts(r.name + "/" + n + " " + (d.version || "") + "\n    " + de + "\n");
                found = true;
            }
        }
    }
    if (!found) msg("No results for: " + q);
}

// Main
var args = scriptArgs.slice(1);
if (!args.length) {
    std.out.puts("skypkg-lite: Arch-style package manager for SkyOS\n");
    std.out.puts("  -S <pkg>    Install from repo\n  -Sy         Sync databases\n");
    std.out.puts("  -Ss <q>     Search remote\n  -U <file>   Install local\n");
    std.out.puts("  -R <pkg>    Remove\n  -Q          List installed\n");
    std.out.puts("  -Qi <pkg>   Info\n  -Ql <pkg>   Files\n");
} else {
    mkdirp(LOCAL); mkdirp(SYNC); mkdirp(CACHE);
    var op = args[0], a = args[1] || null, conf = loadConf();
    if (op === "-U" && a) installLocal(a);
    else if (op === "-R" && a) removeP(a);
    else if (op === "-Q") { var d = getLocal(); if (!d.length) msg("No packages installed."); else d.forEach(function(x) { std.out.puts(x + "\n"); }); }
    else if (op === "-Qi" && a) { var dir = findLocal(a); if (!dir) err("Not installed: " + a); else { var d = parseDesc(readF(LOCAL + dir + "/desc")); for (var k in d) std.out.puts(k + ": " + (Array.isArray(d[k]) ? d[k].join(", ") : d[k]) + "\n"); } }
    else if (op === "-Ql" && a) { var dir = findLocal(a); if (!dir) err("Not installed: " + a); else std.out.puts(readF(LOCAL + dir + "/files")); }
    else if (op === "-Sy") syncDB(conf);
    else if (op === "-S" && a) installRepo(conf, a);
    else if (op === "-Ss" && a) searchRepo(conf, a);
    else err("Unknown: " + op);
}
